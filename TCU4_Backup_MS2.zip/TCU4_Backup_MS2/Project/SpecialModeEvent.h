#ifndef SPECIALMODEEVENT_H
#define SPECIALMODEEVENT_H

enum  SpecialModeEvent {
    SpecialMode_PROVISIONING_E = 1,
    SpecialMode_UNPROVISIONING_E = 2
};

#endif // SPECIALMODEEVENT_H
