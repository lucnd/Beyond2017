#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_btnDecode_clicked();
    void on_pushButton_clicked();

    bool isRawMsgValid(std::vector<uint8_t> buf);
    std::string toDecodeString(std::vector<uint8_t> buf);

    std::string toLoginStr(std::vector<uint8_t> buf);
    std::string toRealtimeReportStr(std::vector<uint8_t> buf);
    std::string toSupplementStr(std::vector<uint8_t> buf);
    std::string toLogoutStr(std::vector<uint8_t> buf);
    std::string toHeatbeatStr(std::vector<uint8_t> buf);
    std::string toTerminalTimingStr(std::vector<uint8_t> buf);
    std::string toQueryDataStr(std::vector<uint8_t> buf);
    std::string toSettingDataStr(std::vector<uint8_t> buf);
    std::string toTerminalControlStr(std::vector<uint8_t> buf);



private:
    Ui::MainWindow *ui;
};


enum MessageType
{
    LOGIN_MESSAGE = 0x01,
    REALTIME_REPORT_MESSAGE = 0x02,
    SUPLEMENTARY_MESSAGE = 0x03,
    LOGOUT_MESSAGE = 0x04,
    HEARTBEAT_MESSAGE = 0x07,
    TERMINAL_TIMING = 0x08,
    NETWORK_MESSAGE = 0x09,
    QUERY_MESSAGE = 0x80,
    SETTING_MESSAGE = 0x81,
    TERMINAL_CONTROL = 0x82,
    UPLINK_MESSAGE = 0xFE
};

#endif // MAINWINDOW_H
