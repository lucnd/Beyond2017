#ifndef GBTTYPEDEF_H
#define GBTTYPEDEF_H

#include <stdint.h>
#include <string>
#include "../interface/ISerializable.h"
#include "../Utils/GBTUtil.h"
#include <cstring>

//N is number of bytes (uint8_t is 1 byte data)
template <int N>
class GBTBaseType : public ISerializable
{
public:
    GBTBaseType();
    bool serialize(std::vector<uint8_t> &buf, uint32_t offsetPos);
    bool deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos);
    std::string toString();
    std::string toHexString();
    std::string toCharString();
    uint32_t getCurSize();
    GBTBaseType &operator=(const uint8_t &t);
    GBTBaseType &operator=(const uint16_t &t);
    GBTBaseType &operator=(const uint32_t &t);
    GBTBaseType &operator=(const uint64_t &t);
    GBTBaseType &operator=(const int &t);
    GBTBaseType &operator=(const GBTBaseType &t);
    bool operator==(const GBTBaseType &t) const;
    bool operator!=(const GBTBaseType &t) const;
    operator uint64_t();

private:
    uint64_t value;
    uint8_t data[N];
};

#include "GBTTypedef.cpp"

#endif // GBTTYPEDEF_H
