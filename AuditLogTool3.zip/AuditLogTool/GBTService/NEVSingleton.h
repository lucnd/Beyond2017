#ifndef _NEVSINGLETON_H_
#define _NEVSINGLETON_H_

template <class T>
class NEVSingleton
{
public:
    static T *GetInstance();
    static void destroy();

private:
    NEVSingleton(NEVSingleton const &){};
    NEVSingleton &operator=(NEVSingleton const &){};

protected:
    NEVSingleton(){};
    virtual ~NEVSingleton(){};
};

template <class T>
T *NEVSingleton<T>::GetInstance()
{
    static T m_instance;

    return &m_instance;
}

#endif // _EVT_SINGLETON_H_
