#ifndef NEVINTERNALDATA_H
#define NEVINTERNALDATA_H
#include "NEVSingleton.h"
#include <string>

#include <memory>

class NEVInternalData : public NEVSingleton<NEVInternalData>
{
public:
    NEVInternalData();

    int getCnevDnsLength() const;
    void setCnevDnsLength(int value);

    int getBitDnsLength() const;
    void setBitDnsLength(int value);

private:

    int cnevDnsLength;
    int bitDnsLength;
};

#endif // NEVINTERNALDATA_H
