#define LOG_TAG "[NEV]GBTSerializable"
//#include <Log.h>

#include "GBTSerializable.h"
#include <cstring>

GBTSerializable::GBTSerializable()
{
}

bool GBTSerializable::serialize(std::vector<uint8_t> &buf, uint32_t offsetPos)
{
    if (fieldList.size() > 0)
    {
        for (auto field : fieldList)
        {
            if (field != nullptr)
            {
                bool ret = field->serialize(buf, offsetPos);
                if (ret)
                {
                    offsetPos += field->getCurSize();
                }
                else
                {
                    return false;
                }
            }
        }
    }
    return true;
}

bool GBTSerializable::deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos)
{
    //printf("%s()", __func__);
    if (fieldList.size() > 0)
    {
        for (auto field : fieldList)
        {
            if (field != nullptr)
            {
                bool ret = field->deserialize(buf, offsetPos);
                if (ret)
                {
                    offsetPos += field->getCurSize();
                }
                else
                {
                    return false;
                }
            }
        }
    }
    return true;
}

void GBTSerializable::makeSerializeStruct()
{
    resetField();
    addChildField();
}

uint32_t GBTSerializable::getCurSize()
{
    uint32_t bufsize = 0;
    for (auto field : fieldList)
    {
        if (field != nullptr)
        {
            bufsize += field->getCurSize();
        }
    }
    return bufsize;
}

void GBTSerializable::resetField()
{
    fieldList.clear();
}

void GBTSerializable::addField(std::shared_ptr<ISerializable> field)
{
    fieldList.push_back(field);
    field->makeSerializeStruct();
}
