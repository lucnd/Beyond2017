#ifndef GBTListOfItem_H
#define GBTListOfItem_H
#include <vector>

template <typename T>
class GBTListOfItem : public GBTSerializable
{
public:
    GBTListOfItem();
    void addChildField();
    std::string toString();
    std::string toHexString();
    std::string toValueArrString();
    std::string toValueDataString();
    std::shared_ptr<T> operator[](int index);
    std::shared_ptr<T> getItem(int index);

    bool deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos);

    void prepend(const std::shared_ptr<T> &item);
    void removeItem(int index);
    int getListSize() const;
    void setListSize(int value);

private:
    std::vector<std::shared_ptr<T>> listOfItem;
    int listSize;
};

#include "GBTListOfItem.cpp"

#endif // GBTGBTListOfItem_H
