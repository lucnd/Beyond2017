#ifndef GBTTRANSPORTSTOREAGECONVERSION_H
#define GBTTRANSPORTSTOREAGECONVERSION_H

#include "GBTDataPackaging.h"

class GBTTransportStoreageConversion
{
public:
    GBTTransportStoreageConversion();

    void sampleGBTStorageDataFromVehicleRealtimeDataPackage(std::shared_ptr<GBTStorageData> storeData, std::shared_ptr<VehicleRealtimeDataPackage> realtimeData);
    void sampleVehicleRealtimeDataPackageFromGBTStorageData(std::shared_ptr<VehicleRealtimeDataPackage> realtimeData, std::shared_ptr<GBTStorageData> storeData);

    std::shared_ptr<CellVoltageStorageData> getCellVoltageStorageData(std::shared_ptr<VoltageDataOfChargeableEnergyStoreSubsystem> rtCellData);
    std::shared_ptr<TemperatureStorageData> getTemperatureStorageData(std::shared_ptr<TemperatureDataOfChargeableEnergyStoreSubsystem> rtProbeData);

    std::shared_ptr<RealTimeReportingPacket> getRealTimeReportingPacket(std::shared_ptr<GBTStorageData> storeData);
    std::shared_ptr<VoltageDataOfChargeableEnergyStoreSubsystem> getVoltageDataOfChargeableEnergyStoreSubsystem(std::shared_ptr<CellVoltageStorageData> stCellData);
    std::shared_ptr<ListOfVoltageInformationOfChargeableEnergyStoreSubsystem> getListOfVoltageInformationOfChargeableEnergyStoreSubsystem(std::shared_ptr<CellVoltageStorageData> stCellData);
    std::shared_ptr<TemperatureDataOfChargeableEnergyStoreSubsystem> getTemperatureDataOfChargeableEnergyStoreSubsystem(std::shared_ptr<TemperatureStorageData> stProbeData);
    std::shared_ptr<ListOfTemperatureInformationOfChargeableEnergyStoreSubsystem> getListOfTemperatureInformationOfChargeableEnergyStoreSubsystem(std::shared_ptr<TemperatureStorageData> stProbeData);
};

#endif // GBTTRANSPORTSTOREAGECONVERSION_H
