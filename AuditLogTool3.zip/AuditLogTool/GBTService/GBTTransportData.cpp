#define LOG_TAG "[NEV]GBTTransportData"
//#include <Log.h>

#include "GBTTransportData.h"
#include <ctime>
#include <sstream>
#include "NEVInternalData.h"

ChinaTimePacket::ChinaTimePacket()
{
    //printf("%s()", __func__);
    year = std::make_shared<BYTE_GBT>();
    month = std::make_shared<BYTE_GBT>();
    day = std::make_shared<BYTE_GBT>();
    hour = std::make_shared<BYTE_GBT>();
    minute = std::make_shared<BYTE_GBT>();
    second = std::make_shared<BYTE_GBT>();
}

void ChinaTimePacket::addChildField()
{
    addField(year);
    addField(month);
    addField(day);
    addField(hour);
    addField(minute);
    addField(second);
}

std::string ChinaTimePacket::toString()
{
    //printf("%s()", __func__);
    std::string str("");
    str += "ChinaTimePacket\n{\n";
    str += "year: " + year->toString() + "\n";
    str += "month: " + month->toString() + "\n";
    str += "day: " + day->toString() + "\n";
    str += "hour: " + hour->toString() + "\n";
    str += "minute: " + minute->toString() + "\n";
    str += "second: " + second->toString() + "\n";
    str += "}";
    return str;
}

uint8_t ChinaTimePacket::getYear() const
{
    return *year;
}

void ChinaTimePacket::setYear(const uint8_t &value)
{
    *year = value;
}

uint8_t ChinaTimePacket::getMonth() const
{
    return *month;
}

void ChinaTimePacket::setMonth(const uint8_t &value)
{
    *month = value;
}

uint8_t ChinaTimePacket::getDay() const
{
    return *day;
}

void ChinaTimePacket::setDay(const uint8_t &value)
{
    *day = value;
}

uint8_t ChinaTimePacket::getHour() const
{
    return *hour;
}

void ChinaTimePacket::setHour(const uint8_t &value)
{
    *hour = value;
}

uint8_t ChinaTimePacket::getMinute() const
{
    return *minute;
}

void ChinaTimePacket::setMinute(const uint8_t &value)
{
    *minute = value;
}

uint8_t ChinaTimePacket::getSecond() const
{
    return *second;
}

void ChinaTimePacket::setSecond(const uint8_t &value)
{
    *second = value;
}

VehicleLoginPacket::VehicleLoginPacket()
{
    //printf("%s()", __func__);
    dataAcquisitionTime = std::make_shared<ChinaTimePacket>();
    loginSerialNumber = std::make_shared<WORD_GBT>();
    iccid = std::make_shared<GBTListOfItem<BYTE_GBT>>();
    iccid->setListSize(20);
    quantityOfChargeableEnergyStorageSubsystem = std::make_shared<BYTE_GBT>();
    codeLengthOfChargeableEnergyStorageSystem = std::make_shared<BYTE_GBT>();
    codeOfChargeableEnergyStorageSystem = std::make_shared<CodeOfChargeableEnergyStorageSystem>();

    *quantityOfChargeableEnergyStorageSubsystem = 1;
    *codeLengthOfChargeableEnergyStorageSystem = 24;
}

void VehicleLoginPacket::addChildField()
{
    addField(dataAcquisitionTime);
    addField(loginSerialNumber);
    addField(iccid);
    addField(quantityOfChargeableEnergyStorageSubsystem);
    addField(codeLengthOfChargeableEnergyStorageSystem);
    addField(codeOfChargeableEnergyStorageSystem);
}

std::string VehicleLoginPacket::toString()
{
    //printf("%s()", __func__);
    std::string str("");
    str += "VehicleLoginPacket\n{\n";
    str += dataAcquisitionTime->toString() + "\n";
    str += "loginSerialNumber :" + loginSerialNumber->toString() + "\n";
    str += "iccid : " + iccid->toHexString() + "\n";
    str += "quantityOfChargeableEnergyStorageSubsystem :" + quantityOfChargeableEnergyStorageSubsystem->toString() + "\n";
    str += "codeLengthOfChargeableEnergyStorageSystem :" + codeLengthOfChargeableEnergyStorageSystem->toString() + "\n";
    str += codeOfChargeableEnergyStorageSystem->toString() + "\n";
    str += "}";
    return str;
}

uint8_t VehicleLoginPacket::getCodeLengthOfChargeableEnergyStorageSystem() const
{
    return *codeLengthOfChargeableEnergyStorageSystem;
}

void VehicleLoginPacket::setCodeLengthOfChargeableEnergyStorageSystem(const uint8_t &value)
{
    *codeLengthOfChargeableEnergyStorageSystem = value;
}

std::shared_ptr<CodeOfChargeableEnergyStorageSystem> VehicleLoginPacket::getCodeOfChargeableEnergyStorageSystem() const
{
    return codeOfChargeableEnergyStorageSystem;
}

uint8_t VehicleLoginPacket::getQuantityOfChargeableEnergyStorageSubsystem() const
{
    return *quantityOfChargeableEnergyStorageSubsystem;
}

void VehicleLoginPacket::setQuantityOfChargeableEnergyStorageSubsystem(const uint8_t &value)
{
    *quantityOfChargeableEnergyStorageSubsystem = value;
}

uint16_t VehicleLoginPacket::getLoginSerialNumber() const
{
    return *loginSerialNumber;
}

void VehicleLoginPacket::setLoginSerialNumber(const uint16_t &value)
{
    *loginSerialNumber = value;
}

std::string VehicleLoginPacket::getIccid() const
{
    return iccid->toString();
}

void VehicleLoginPacket::setIccid(const std::string &value)
{
    for (int i = 0; i < 20; i++)
    {
        *iccid->getItem(i) = value[i];
    }
}

std::shared_ptr<ChinaTimePacket> VehicleLoginPacket::getDataAcquisitionTime() const
{
    return dataAcquisitionTime;
}

RealTimeReportingPacket::RealTimeReportingPacket()
{
    //printf("%s()", __func__);
    dataAcquisitionTime = std::make_shared<ChinaTimePacket>();
    completeVehicleDataTypeMark = std::make_shared<BYTE_GBT>();
    completeVehicleDataPacket = std::make_shared<CompleteVehicleDataPacket>();
    electricMachineDataTypeMark = std::make_shared<BYTE_GBT>();
    electricMachineDataPacket = std::make_shared<ElectricMachineDataPacket>();
    fuelCellDataTypeMark = std::make_shared<BYTE_GBT>();
    fuelCellDataPacket = std::make_shared<FuelCellDataPacket>();
    dataOfEngineTypeMark = std::make_shared<BYTE_GBT>();
    dataOfEnginePacket = std::make_shared<DataOfEnginePacket>();
    gpsDataTypeMark = std::make_shared<BYTE_GBT>();
    gpsDataPacket = std::make_shared<GPSDataPacket>();
    limitValueDataTypeMark = std::make_shared<BYTE_GBT>();
    limitValueDataPacket = std::make_shared<LimitValueDataPacket>();
    warningDataTypeMark = std::make_shared<BYTE_GBT>();
    warningDataPacket = std::make_shared<WarningDataPacket>();
    voltageDataOfChargeableEnergyStoreSubsystemTypeMark = std::make_shared<BYTE_GBT>();
    voltageDataOfChargeableEnergyStoreSubsystem = std::make_shared<VoltageDataOfChargeableEnergyStoreSubsystem>();
    temperatureDataOfChargeableEnergyStoreSubsystemTypeMark = std::make_shared<BYTE_GBT>();
    temperatureDataOfChargeableEnergyStoreSubsystem = std::make_shared<TemperatureDataOfChargeableEnergyStoreSubsystem>();

    *completeVehicleDataTypeMark = 1;
    *electricMachineDataTypeMark = 2;
    *fuelCellDataTypeMark = 3;
    *dataOfEngineTypeMark = 4;
    *gpsDataTypeMark = 5;
    *limitValueDataTypeMark = 6;
    *warningDataTypeMark = 7;
    *voltageDataOfChargeableEnergyStoreSubsystemTypeMark = 8;
    *temperatureDataOfChargeableEnergyStoreSubsystemTypeMark = 9;
}

void RealTimeReportingPacket::addChildField()
{
    addField(dataAcquisitionTime);
    addField(completeVehicleDataTypeMark);
    addField(completeVehicleDataPacket);
    addField(electricMachineDataTypeMark);
    addField(electricMachineDataPacket);
    addField(fuelCellDataTypeMark);
    addField(fuelCellDataPacket);
    addField(dataOfEngineTypeMark);
    addField(dataOfEnginePacket);
    addField(gpsDataTypeMark);
    addField(gpsDataPacket);
    addField(limitValueDataTypeMark);
    addField(limitValueDataPacket);
    addField(warningDataTypeMark);
    addField(warningDataPacket);
    addField(voltageDataOfChargeableEnergyStoreSubsystemTypeMark);
    addField(voltageDataOfChargeableEnergyStoreSubsystem);
    addField(temperatureDataOfChargeableEnergyStoreSubsystemTypeMark);
    addField(temperatureDataOfChargeableEnergyStoreSubsystem);
}

std::string RealTimeReportingPacket::toString()
{
    //printf("%s()", __func__);
    std::string str("");
    str += "RealTimeReportingData\n{\n";
    str += "dataAcquisitionTime :" + dataAcquisitionTime->toString() + "\n";
    str += "completeVehicleDataTypeMark :" + completeVehicleDataTypeMark->toString() + "\n";
    str += completeVehicleDataPacket->toString() + "\n";
    str += "electricMachineDataTypeMark :" + electricMachineDataTypeMark->toString() + "\n";
    str += electricMachineDataPacket->toString() + "\n";
    str += "fuelCellDataTypeMark :" + fuelCellDataTypeMark->toString() + "\n";
    str += fuelCellDataPacket->toString() + "\n";
    str += "dataOfEngineTypeMark :" + dataOfEngineTypeMark->toString() + "\n";
    str += dataOfEnginePacket->toString() + "\n";
    str += "gpsDataTypeMark :" + gpsDataTypeMark->toString() + "\n";
    str += gpsDataPacket->toString() + "\n";
    str += "limitValueDataTypeMark :" + limitValueDataTypeMark->toString() + "\n";
    str += limitValueDataPacket->toString() + "\n";
    str += "warningDataTypeMark :" + warningDataTypeMark->toString() + "\n";
    str += warningDataPacket->toString() + "\n";
    str += "voltageDataOfChargeableEnergyStoreSubsystemTypeMark :" + voltageDataOfChargeableEnergyStoreSubsystemTypeMark->toString() + "\n";
    str += voltageDataOfChargeableEnergyStoreSubsystem->toString() + "\n";
    str += "temperatureDataOfChargeableEnergyStoreSubsystemTypeMark :" + temperatureDataOfChargeableEnergyStoreSubsystemTypeMark->toString() + "\n";
    str += temperatureDataOfChargeableEnergyStoreSubsystem->toString() + "\n";
    str += "}";
    return str;
}

std::shared_ptr<ChinaTimePacket> RealTimeReportingPacket::getDataAcquisitionTime() const
{
    return dataAcquisitionTime;
}

uint8_t RealTimeReportingPacket::getCompleteVehicleDataTypeMark() const
{
    return *completeVehicleDataTypeMark;
}

void RealTimeReportingPacket::setCompleteVehicleDataTypeMark(const uint8_t &value)
{
    *completeVehicleDataTypeMark = value;
}

std::shared_ptr<CompleteVehicleDataPacket> RealTimeReportingPacket::getCompleteVehicleDataPacket() const
{
    return completeVehicleDataPacket;
}

uint8_t RealTimeReportingPacket::getElectricMachineDataTypeMark() const
{
    return *electricMachineDataTypeMark;
}

void RealTimeReportingPacket::setElectricMachineDataTypeMark(const uint8_t &value)
{
    *electricMachineDataTypeMark = value;
}

std::shared_ptr<ElectricMachineDataPacket> RealTimeReportingPacket::getElectricMachineDataPacket() const
{
    return electricMachineDataPacket;
}

uint8_t RealTimeReportingPacket::getFuelCellDataTypeMark() const
{
    return *fuelCellDataTypeMark;
}

void RealTimeReportingPacket::setFuelCellDataTypeMark(const uint8_t &value)
{
    *fuelCellDataTypeMark = value;
}

std::shared_ptr<FuelCellDataPacket> RealTimeReportingPacket::getFuelCellDataPacket() const
{
    return fuelCellDataPacket;
}

uint8_t RealTimeReportingPacket::getDataOfEngineTypeMark() const
{
    return *dataOfEngineTypeMark;
}

void RealTimeReportingPacket::setDataOfEngineTypeMark(const uint8_t &value)
{
    *dataOfEngineTypeMark = value;
}

std::shared_ptr<DataOfEnginePacket> RealTimeReportingPacket::getDataOfEnginePacket() const
{
    return dataOfEnginePacket;
}

uint8_t RealTimeReportingPacket::getGPSDataTypeMark() const
{
    return *gpsDataTypeMark;
}

void RealTimeReportingPacket::setGPSDataTypeMark(const uint8_t &value)
{
    *gpsDataTypeMark = value;
}

std::shared_ptr<GPSDataPacket> RealTimeReportingPacket::getGpsDataPacket() const
{
    return gpsDataPacket;
}

uint8_t RealTimeReportingPacket::getLimitValueDataTypeMark() const
{
    return *limitValueDataTypeMark;
}

void RealTimeReportingPacket::setLimitValueDataTypeMark(const uint8_t &value)
{
    *limitValueDataTypeMark = value;
}

std::shared_ptr<LimitValueDataPacket> RealTimeReportingPacket::getLimitValueDataPacket() const
{
    return limitValueDataPacket;
}

uint8_t RealTimeReportingPacket::getWarningDataTypeMark() const
{
    return *warningDataTypeMark;
}

void RealTimeReportingPacket::setWarningDataTypeMark(const uint8_t &value)
{
    *warningDataTypeMark = value;
}

std::shared_ptr<WarningDataPacket> RealTimeReportingPacket::getWarningDataPacket() const
{
    return warningDataPacket;
}

std::shared_ptr<VoltageDataOfChargeableEnergyStoreSubsystem> RealTimeReportingPacket::getVoltageDataOfChargeableEnergyStoreSubsystem() const
{
    return voltageDataOfChargeableEnergyStoreSubsystem;
}

uint8_t RealTimeReportingPacket::getVoltageDataOfChargeableEnergyStoreSubsystemTypeMark() const
{
    return *voltageDataOfChargeableEnergyStoreSubsystemTypeMark;
}

void RealTimeReportingPacket::setVoltageDataOfChargeableEnergyStoreSubsystemTypeMark(const uint8_t &value)
{
    *voltageDataOfChargeableEnergyStoreSubsystemTypeMark = value;
}

uint8_t RealTimeReportingPacket::getTemperatureDataOfChargeableEnergyStoreSubsystemTypeMark() const
{
    return *temperatureDataOfChargeableEnergyStoreSubsystemTypeMark;
}

void RealTimeReportingPacket::setTemperatureDataOfChargeableEnergyStoreSubsystemTypeMark(const uint8_t &value)
{
    *temperatureDataOfChargeableEnergyStoreSubsystemTypeMark = value;
}

std::shared_ptr<TemperatureDataOfChargeableEnergyStoreSubsystem> RealTimeReportingPacket::getTemperatureDataOfChargeableEnergyStoreSubsystem() const
{
    return temperatureDataOfChargeableEnergyStoreSubsystem;
}

void RealTimeReportingPacket::setCompleteVehicleDataPacket(const std::shared_ptr<CompleteVehicleDataPacket> &value)
{
    completeVehicleDataPacket = value;
}

void RealTimeReportingPacket::setElectricMachineDataPacket(const std::shared_ptr<ElectricMachineDataPacket> &value)
{
    electricMachineDataPacket = value;
}

void RealTimeReportingPacket::setFuelCellDataPacket(const std::shared_ptr<FuelCellDataPacket> &value)
{
    fuelCellDataPacket = value;
}

void RealTimeReportingPacket::setDataOfEnginePacket(const std::shared_ptr<DataOfEnginePacket> &value)
{
    dataOfEnginePacket = value;
}

void RealTimeReportingPacket::setGpsDataPacket(const std::shared_ptr<GPSDataPacket> &value)
{
    gpsDataPacket = value;
}

void RealTimeReportingPacket::setLimitValueDataPacket(const std::shared_ptr<LimitValueDataPacket> &value)
{
    limitValueDataPacket = value;
}

void RealTimeReportingPacket::setWarningDataPacket(const std::shared_ptr<WarningDataPacket> &value)
{
    warningDataPacket = value;
}

void RealTimeReportingPacket::setVoltageDataOfChargeableEnergyStoreSubsystem(const std::shared_ptr<VoltageDataOfChargeableEnergyStoreSubsystem> &value)
{
    voltageDataOfChargeableEnergyStoreSubsystem = value;
}

void RealTimeReportingPacket::setTemperatureDataOfChargeableEnergyStoreSubsystem(const std::shared_ptr<TemperatureDataOfChargeableEnergyStoreSubsystem> &value)
{
    temperatureDataOfChargeableEnergyStoreSubsystem = value;
}

void RealTimeReportingPacket::setDataAcquisitionTime(const std::shared_ptr<ChinaTimePacket> &value)
{
    dataAcquisitionTime = value;
}

CompleteVehicleDataPacket::CompleteVehicleDataPacket()
{
    //printf("%s()", __func__);
    vehicleState = std::make_shared<BYTE_GBT>();
    chargingState = std::make_shared<BYTE_GBT>();
    operationMode = std::make_shared<BYTE_GBT>();
    vehicleSpeed = std::make_shared<WORD_GBT>();
    accumulatedMileage = std::make_shared<DWORD_GBT>();
    totalVoltage = std::make_shared<WORD_GBT>();
    totalCurrent = std::make_shared<WORD_GBT>();
    soc = std::make_shared<BYTE_GBT>();
    dcdcState = std::make_shared<BYTE_GBT>();
    gearPosition = std::make_shared<BYTE_GBT>();
    insulationResistance = std::make_shared<WORD_GBT>();
    strokeOfAcceratorPedal = std::make_shared<BYTE_GBT>();
    brakePedalState = std::make_shared<BYTE_GBT>();
}

void CompleteVehicleDataPacket::addChildField()
{
    addField(vehicleState);
    addField(chargingState);
    addField(operationMode);
    addField(vehicleSpeed);
    addField(accumulatedMileage);
    addField(totalVoltage);
    addField(totalCurrent);
    addField(soc);
    addField(dcdcState);
    addField(gearPosition);
    addField(insulationResistance);
    addField(strokeOfAcceratorPedal);
    addField(brakePedalState);
}

std::string CompleteVehicleDataPacket::toString()
{
    //printf("%s()", __func__);
    std::string str("");
    str += "CompleteVehicleDataPacket\n{\n";
    str += "vehicleState :" + vehicleState->toString() + "\n";
    str += "chargingState :" + chargingState->toString() + "\n";
    str += "operationMode :" + operationMode->toString() + "\n";
    str += "vehicleSpeed :" + vehicleSpeed->toString() + "\n";
    str += "accumulatedMileage :" + accumulatedMileage->toString() + "\n";
    str += "totalVoltage :" + totalVoltage->toString() + "\n";
    str += "totalCurrent :" + totalCurrent->toString() + "\n";
    str += "soc :" + soc->toString() + "\n";
    str += "dcdcState :" + dcdcState->toString() + "\n";
    str += "gearPosition :" + gearPosition->toString() + "\n";
    str += "insulationResistance :" + insulationResistance->toString() + "\n";
    str += "strokeOfAcceratorPedal :" + strokeOfAcceratorPedal->toString() + "\n";
    str += "brakePedalState :" + brakePedalState->toString() + "\n";
    str += "}";
    return str;
}

uint8_t CompleteVehicleDataPacket::getVehicleState() const
{
    return *vehicleState;
}

void CompleteVehicleDataPacket::setVehicleState(const uint8_t &value)
{
    *vehicleState = value;
}

uint8_t CompleteVehicleDataPacket::getChargingState() const
{
    return *chargingState;
}

void CompleteVehicleDataPacket::setChargingState(const uint8_t &value)
{
    *chargingState = value;
}

uint8_t CompleteVehicleDataPacket::getOperationMode() const
{
    return *operationMode;
}

void CompleteVehicleDataPacket::setOperationMode(const uint8_t &value)
{
    *operationMode = value;
}

uint16_t CompleteVehicleDataPacket::getVehicleSpeed() const
{
    return *vehicleSpeed;
}

void CompleteVehicleDataPacket::setVehicleSpeed(const uint16_t &value)
{
    *vehicleSpeed = value;
}

uint32_t CompleteVehicleDataPacket::getAccumulatedMileage() const
{
    return *accumulatedMileage;
}

void CompleteVehicleDataPacket::setAccumulatedMileage(const uint32_t &value)
{
    *accumulatedMileage = value;
}

uint16_t CompleteVehicleDataPacket::getTotalVoltage() const
{
    return *totalVoltage;
}

void CompleteVehicleDataPacket::setTotalVoltage(const uint16_t &value)
{
    *totalVoltage = value;
}

uint16_t CompleteVehicleDataPacket::getTotalCurrent() const
{
    return *totalCurrent;
}

void CompleteVehicleDataPacket::setTotalCurrent(const uint16_t &value)
{
    *totalCurrent = value;
}

uint8_t CompleteVehicleDataPacket::getSoc() const
{
    return *soc;
}

void CompleteVehicleDataPacket::setSoc(const uint8_t &value)
{
    *soc = value;
}

uint8_t CompleteVehicleDataPacket::getDcdcState() const
{
    return *dcdcState;
}

void CompleteVehicleDataPacket::setDcdcState(const uint8_t &value)
{
    *dcdcState = value;
}

uint8_t CompleteVehicleDataPacket::getGearPosition() const
{
    return *gearPosition;
}

void CompleteVehicleDataPacket::setGearPosition(const uint8_t &value)
{
    *gearPosition = value;
}

uint16_t CompleteVehicleDataPacket::getInsulationResistance() const
{
    return *insulationResistance;
}

void CompleteVehicleDataPacket::setInsulationResistance(const uint16_t &value)
{
    *insulationResistance = value;
}

uint8_t CompleteVehicleDataPacket::getStrokeOfAcceratorPedal() const
{
    return *strokeOfAcceratorPedal;
}

void CompleteVehicleDataPacket::setStrokeOfAcceratorPedal(const uint8_t &value)
{
    *strokeOfAcceratorPedal = value;
}

uint8_t CompleteVehicleDataPacket::getBrakePedalState() const
{
    return *brakePedalState;
}

void CompleteVehicleDataPacket::setBrakePedalState(const uint8_t &value)
{
    *brakePedalState = value;
}

ElectricMachineDataUnitPacket::ElectricMachineDataUnitPacket()
{
    //printf("%s()", __func__);
    snOfElectricalMachine = std::make_shared<BYTE_GBT>();
    stateOfElectricalMachine = std::make_shared<BYTE_GBT>();
    temperatureOfElectricalMachineController = std::make_shared<BYTE_GBT>();
    speedOfElectricalMachine = std::make_shared<WORD_GBT>();
    torqueOfElectricalMachine = std::make_shared<WORD_GBT>();
    temperatureOfElectricalMachine = std::make_shared<BYTE_GBT>();
    inputVoltageOfElectricalMachineController = std::make_shared<WORD_GBT>();
    currentOfDCbusOfElectricalMachineController = std::make_shared<WORD_GBT>();
}

void ElectricMachineDataUnitPacket::addChildField()
{
    addField(snOfElectricalMachine);
    addField(stateOfElectricalMachine);
    addField(temperatureOfElectricalMachineController);
    addField(speedOfElectricalMachine);
    addField(torqueOfElectricalMachine);
    addField(temperatureOfElectricalMachine);
    addField(inputVoltageOfElectricalMachineController);
    addField(currentOfDCbusOfElectricalMachineController);
}

std::string ElectricMachineDataUnitPacket::toString()
{
    //printf("%s()", __func__);
    std::string str("");
    str += "ElectricMachineDataUnitPacket\n{\n";
    str += "snOfElectricalMachine :" + snOfElectricalMachine->toString() + "\n";
    str += "stateOfElectricalMachine :" + stateOfElectricalMachine->toString() + "\n";
    str += "temperatureOfElectricalMachineController :" + temperatureOfElectricalMachineController->toString() + "\n";
    str += "speedOfElectricalMachine :" + speedOfElectricalMachine->toString() + "\n";
    str += "torqueOfElectricalMachine :" + torqueOfElectricalMachine->toString() + "\n";
    str += "temperatureOfElectricalMachine :" + temperatureOfElectricalMachine->toString() + "\n";
    str += "inputVoltageOfElectricalMachineController :" + inputVoltageOfElectricalMachineController->toString() + "\n";
    str += "currentOfDCbusOfElectricalMachineController :" + currentOfDCbusOfElectricalMachineController->toString() + "\n";
    str += "\n}";
    return str;
}

uint8_t ElectricMachineDataUnitPacket::getSnOfElectricalMachine() const
{
    return *snOfElectricalMachine;
}

void ElectricMachineDataUnitPacket::setSnOfElectricalMachine(const uint8_t &value)
{
    *snOfElectricalMachine = value;
}

uint8_t ElectricMachineDataUnitPacket::getStateOfElectricalMachine() const
{
    return *stateOfElectricalMachine;
}

void ElectricMachineDataUnitPacket::setStateOfElectricalMachine(const uint8_t &value)
{
    *stateOfElectricalMachine = value;
}

uint8_t ElectricMachineDataUnitPacket::getTemperatureOfElectricalMachineController() const
{
    return *temperatureOfElectricalMachineController;
}

void ElectricMachineDataUnitPacket::setTemperatureOfElectricalMachineController(const uint8_t &value)
{
    *temperatureOfElectricalMachineController = value;
}

uint16_t ElectricMachineDataUnitPacket::getSpeedOfElectricalMachine() const
{
    return *speedOfElectricalMachine;
}

void ElectricMachineDataUnitPacket::setSpeedOfElectricalMachine(const uint16_t &value)
{
    *speedOfElectricalMachine = value;
}

uint16_t ElectricMachineDataUnitPacket::getTorqueOfElectricalMachine() const
{
    return *torqueOfElectricalMachine;
}

void ElectricMachineDataUnitPacket::setTorqueOfElectricalMachine(const uint16_t &value)
{
    *torqueOfElectricalMachine = value;
}

uint8_t ElectricMachineDataUnitPacket::getTemperatureOfElectricalMachine() const
{
    return *temperatureOfElectricalMachine;
}

void ElectricMachineDataUnitPacket::setTemperatureOfElectricalMachine(const uint8_t &value)
{
    *temperatureOfElectricalMachine = value;
}

uint16_t ElectricMachineDataUnitPacket::getInputVoltageOfElectricalMachineController() const
{
    return *inputVoltageOfElectricalMachineController;
}

void ElectricMachineDataUnitPacket::setInputVoltageOfElectricalMachineController(const uint16_t &value)
{
    *inputVoltageOfElectricalMachineController = value;
}

uint16_t ElectricMachineDataUnitPacket::getCurrentOfDCbusOfElectricalMachineController() const
{
    return *currentOfDCbusOfElectricalMachineController;
}

void ElectricMachineDataUnitPacket::setCurrentOfDCbusOfElectricalMachineController(const uint16_t &value)
{
    *currentOfDCbusOfElectricalMachineController = value;
}

ElectricMachineDataPacket::ElectricMachineDataPacket()
{
    //printf("%s()", __func__);
    quantityOfElectricMachine = std::make_shared<BYTE_GBT>();
    *quantityOfElectricMachine = 1;
}

void ElectricMachineDataPacket::addChildField()
{
    addField(quantityOfElectricMachine);
}

std::string ElectricMachineDataPacket::toString()
{
    //printf("%s()", __func__);
    std::string str("");
    str += "ElectricMachineDataPacket\n{\n";
    str += "quantityOfElectricMachine :" + quantityOfElectricMachine->toString() + "\n";

    if (*quantityOfElectricMachine == 2)
    {
        str += "electricMachineDataUnitPacketF\n{\n";
        str += electricMachineDataUnitPacketF->toString() + "\n";
        str += "}\n";
        str += "electricMachineDataUnitPacketR\n{\n";
        str += electricMachineDataUnitPacketR->toString() + "\n";
        str += "}\n";
    }
    else
    {
        str += "electricMachineDataUnitPacketR\n{\n";
        str += electricMachineDataUnitPacketR->toString();
        str += "}\n";
    }
    str += "}";
    return str;
}

bool ElectricMachineDataPacket::deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos)
{
    //uint32_t remainLen = len;
    bool ret = quantityOfElectricMachine->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += quantityOfElectricMachine->getCurSize();
    //remainLen -= numberOfFaults->getCurSize();

    uint16_t emNum = *quantityOfElectricMachine;
    setQuantityOfElectricMachine(emNum);

    if (emNum == 2)
    {
        ret = electricMachineDataUnitPacketR->deserialize(buf, offsetPos);
        if (!ret)
        {
            return false;
        }
        offsetPos += electricMachineDataUnitPacketR->getCurSize();

        ret = electricMachineDataUnitPacketF->deserialize(buf, offsetPos);
        if (!ret)
        {
            return false;
        }
    }
    else
    {
        ret = electricMachineDataUnitPacketR->deserialize(buf, offsetPos);
        if (!ret)
        {
            return false;
        }
    }
    return true;
}

uint8_t ElectricMachineDataPacket::getQuantityOfElectricMachine() const
{
    return *quantityOfElectricMachine;
}

void ElectricMachineDataPacket::setQuantityOfElectricMachine(const uint8_t &value)
{
    *quantityOfElectricMachine = value;
    if (value == 2)
    {
        electricMachineDataUnitPacketR = std::make_shared<ElectricMachineDataUnitPacket>();
        electricMachineDataUnitPacketF = std::make_shared<ElectricMachineDataUnitPacket>();
        addField(electricMachineDataUnitPacketF);
        addField(electricMachineDataUnitPacketR);
    }
    else
    {
        electricMachineDataUnitPacketR = std::make_shared<ElectricMachineDataUnitPacket>();
        addField(electricMachineDataUnitPacketR);
    }
}

std::shared_ptr<ElectricMachineDataUnitPacket> ElectricMachineDataPacket::getElectricMachineDataUnitPacketR() const
{
    return electricMachineDataUnitPacketR;
}

std::shared_ptr<ElectricMachineDataUnitPacket> ElectricMachineDataPacket::getElectricMachineDataUnitPacketF() const
{
    return electricMachineDataUnitPacketF;
}

FuelCellDataPacket::FuelCellDataPacket()
{
    //printf("%s()", __func__);
    voltageOfFuelCell = std::make_shared<WORD_GBT>();
    currentOfFuelCell = std::make_shared<WORD_GBT>();
    fuelConsumption = std::make_shared<WORD_GBT>();
    totalNumberOfFuelCellTemperatureProbes = std::make_shared<WORD_GBT>();
    probeTemperatureValue = std::make_shared<GBTListOfItem<BYTE_GBT>>();
    maxTemperatureInHydrogenSystem = std::make_shared<WORD_GBT>();
    codeOfProbeWithMaxTempInHydrogenSystem = std::make_shared<BYTE_GBT>();
    maxConcentrationInHydrogen = std::make_shared<WORD_GBT>();
    codeOfSensorWithMaxConcentrationOfHydrogen = std::make_shared<BYTE_GBT>();
    maxPressureOfHydrogen = std::make_shared<WORD_GBT>();
    codeOfSensorWithTheMaxPressureOfHydrogen = std::make_shared<BYTE_GBT>();
    highPressureDCDCState = std::make_shared<BYTE_GBT>();
}

void FuelCellDataPacket::addChildField()
{
    addField(voltageOfFuelCell);
    addField(currentOfFuelCell);
    addField(fuelConsumption);
    addField(totalNumberOfFuelCellTemperatureProbes);
    addField(probeTemperatureValue);
    addField(maxTemperatureInHydrogenSystem);
    addField(codeOfProbeWithMaxTempInHydrogenSystem);
    addField(maxConcentrationInHydrogen);
    addField(codeOfSensorWithMaxConcentrationOfHydrogen);
    addField(maxPressureOfHydrogen);
    addField(codeOfSensorWithTheMaxPressureOfHydrogen);
    addField(highPressureDCDCState);
}

std::string FuelCellDataPacket::toString()
{
    //printf("%s()", __func__);
    std::string str("");
    str += "FuelCellDataPacket\n{\n";
    str += "voltageOfFuelCell :" + voltageOfFuelCell->toString() + "\n";
    str += "currentOfFuelCell :" + currentOfFuelCell->toString() + "\n";
    str += "fuelConsumption :" + fuelConsumption->toString() + "\n";
    str += "totalNumberOfFuelCellTemperatureProbes :" + totalNumberOfFuelCellTemperatureProbes->toString() + "\n";
    str += "probeTemperatureValue: []\n";

    str += "maxTemperatureInHydrogenSystem :" + maxTemperatureInHydrogenSystem->toString() + "\n";
    str += "codeOfProbeWithMaxTempInHydrogenSystem :" + codeOfProbeWithMaxTempInHydrogenSystem->toString() + "\n";
    str += "maxConcentrationInHydrogen :" + maxConcentrationInHydrogen->toString() + "\n";
    str += "codeOfSensorWithMaxConcentrationOfHydrogen :" + codeOfSensorWithMaxConcentrationOfHydrogen->toString() + "\n";
    str += "maxPressureOfHydrogen :" + maxPressureOfHydrogen->toString() + "\n";
    str += "codeOfSensorWithTheMaxPressureOfHydrogen :" + codeOfSensorWithTheMaxPressureOfHydrogen->toString() + "\n";
    str += "highPressureDCDCState :" + highPressureDCDCState->toString() + "\n";
    str += "}";
    return str;
}

uint16_t FuelCellDataPacket::getVoltageOfFuelCell() const
{
    return *voltageOfFuelCell;
}

void FuelCellDataPacket::setVoltageOfFuelCell(const uint16_t &value)
{
    *voltageOfFuelCell = value;
}

uint16_t FuelCellDataPacket::getCurrentOfFuelCell() const
{
    return *currentOfFuelCell;
}

void FuelCellDataPacket::setCurrentOfFuelCell(const uint16_t &value)
{
    *currentOfFuelCell = value;
}

uint16_t FuelCellDataPacket::getFuelConsumption() const
{
    return *fuelConsumption;
}

void FuelCellDataPacket::setFuelConsumption(const uint16_t &value)
{
    *fuelConsumption = value;
}

uint16_t FuelCellDataPacket::getTotalNumberOfFuelCellTemperatureProbes() const
{
    return *totalNumberOfFuelCellTemperatureProbes;
}

void FuelCellDataPacket::setTotalNumberOfFuelCellTemperatureProbes(const uint16_t &value)
{
    *totalNumberOfFuelCellTemperatureProbes = value;
}

std::shared_ptr<GBTListOfItem<BYTE_GBT>> FuelCellDataPacket::getProbeTemperatureValue() const
{
    return probeTemperatureValue;
}

uint16_t FuelCellDataPacket::getMaxTemperatureInHydrogenSystem() const
{
    return *maxTemperatureInHydrogenSystem;
}

void FuelCellDataPacket::setMaxTemperatureInHydrogenSystem(const uint16_t &value)
{
    *maxTemperatureInHydrogenSystem = value;
}

uint8_t FuelCellDataPacket::getCodeOfProbeWithMaxTempInHydrogenSystem() const
{
    return *codeOfProbeWithMaxTempInHydrogenSystem;
}

void FuelCellDataPacket::setCodeOfProbeWithMaxTempInHydrogenSystem(const uint8_t &value)
{
    *codeOfProbeWithMaxTempInHydrogenSystem = value;
}

uint16_t FuelCellDataPacket::getMaxConcentrationInHydrogen() const
{
    return *maxConcentrationInHydrogen;
}

void FuelCellDataPacket::setMaxConcentrationInHydrogen(const uint16_t &value)
{
    *maxConcentrationInHydrogen = value;
}

uint8_t FuelCellDataPacket::getCodeOfSensorWithMaxConcentrationOfHydrogen() const
{
    return *codeOfSensorWithMaxConcentrationOfHydrogen;
}

void FuelCellDataPacket::setCodeOfSensorWithMaxConcentrationOfHydrogen(const uint8_t &value)
{
    *codeOfSensorWithMaxConcentrationOfHydrogen = value;
}

uint16_t FuelCellDataPacket::getMaxPressureOfHydrogen() const
{
    return *maxPressureOfHydrogen;
}

void FuelCellDataPacket::setMaxPressureOfHydrogen(const uint16_t &value)
{
    *maxPressureOfHydrogen = value;
}

uint8_t FuelCellDataPacket::getCodeOfSensorWithTheMaxPressureOfHydrogen() const
{
    return *codeOfSensorWithTheMaxPressureOfHydrogen;
}

void FuelCellDataPacket::setCodeOfSensorWithTheMaxPressureOfHydrogen(const uint8_t &value)
{
    *codeOfSensorWithTheMaxPressureOfHydrogen = value;
}

uint8_t FuelCellDataPacket::getHighPressureDCDCState() const
{
    return *highPressureDCDCState;
}

void FuelCellDataPacket::setHighPressureDCDCState(const uint8_t &value)
{
    *highPressureDCDCState = value;
}

DataOfEnginePacket::DataOfEnginePacket()
{
    //printf("%s()", __func__);
    engineState = std::make_shared<BYTE_GBT>();
    crankshaftSpeed = std::make_shared<WORD_GBT>();
    fuelConsumption = std::make_shared<WORD_GBT>();
}

void DataOfEnginePacket::addChildField()
{
    addField(engineState);
    addField(crankshaftSpeed);
    addField(fuelConsumption);
}

std::string DataOfEnginePacket::toString()
{
    //printf("%s()", __func__);
    std::string str("");
    str += "DataOfEnginePacket\n{\n";
    str += "engineState :" + engineState->toString() + "\n";
    str += "crankshaftSpeed :" + crankshaftSpeed->toString() + "\n";
    str += "fuelConsumption :" + fuelConsumption->toString() + "\n";
    str += "}";
    return str;
}

uint8_t DataOfEnginePacket::getEngineState() const
{
    return *engineState;
}

void DataOfEnginePacket::setEngineState(const uint8_t &value)
{
    *engineState = value;
}

uint16_t DataOfEnginePacket::getCrankshaftSpeed() const
{
    return *crankshaftSpeed;
}

void DataOfEnginePacket::setCrankshaftSpeed(const uint16_t &value)
{
    *crankshaftSpeed = value;
}

uint16_t DataOfEnginePacket::getFuelConsumption() const
{
    return *fuelConsumption;
}

void DataOfEnginePacket::setFuelConsumption(const uint16_t &value)
{
    *fuelConsumption = value;
}

GPSDataPacket::GPSDataPacket()
{
    //printf("%s()", __func__);
    positioningState = std::make_shared<BYTE_GBT>();
    longitude = std::make_shared<DWORD_GBT>();
    latitude = std::make_shared<DWORD_GBT>();
}

void GPSDataPacket::addChildField()
{
    addField(positioningState);
    addField(longitude);
    addField(latitude);
}

std::string GPSDataPacket::toString()
{
    //printf("%s()", __func__);
    std::string str("");
    str += "GPSDataPacket\n{\n";
    str += "positioningState :" + positioningState->toString() + "\n";
    str += "longitude :" + longitude->toString() + "\n";
    str += "latitude :" + latitude->toString() + "\n";
    str += "}";
    return str;
}

uint8_t GPSDataPacket::getPositioningState() const
{
    return *positioningState;
}

void GPSDataPacket::setPositioningState(const uint8_t &value)
{
    *positioningState = value;
}

uint32_t GPSDataPacket::getLongitude() const
{
    return *longitude;
}

void GPSDataPacket::setLongitude(const uint32_t &value)
{
    *longitude = value;
}

uint32_t GPSDataPacket::getLatitude() const
{
    return *latitude;
}

void GPSDataPacket::setLatitude(const uint32_t &value)
{
    *latitude = value;
}

LimitValueDataPacket::LimitValueDataPacket()
{
    //printf("%s()", __func__);
    idNoOfBatterySubsystemWithMaxVoltage = std::make_shared<BYTE_GBT>();
    idNoOfCellWithMaxVoltage = std::make_shared<BYTE_GBT>();
    maxCellVoltage = std::make_shared<WORD_GBT>();
    idNoOfBatterySubsystemWithMinVoltage = std::make_shared<BYTE_GBT>();
    idNoOfCellWithMinVoltage = std::make_shared<BYTE_GBT>();
    minCellVoltage = std::make_shared<WORD_GBT>();
    idNoOfSubsystemWithMaxTemperature = std::make_shared<BYTE_GBT>();
    codeOfSingleProbeWithMaxTemperature = std::make_shared<BYTE_GBT>();
    maxTemperatureValue = std::make_shared<BYTE_GBT>();
    idNoOfSubsystemWithMinTemperature = std::make_shared<BYTE_GBT>();
    codeOfProbeSubsystemWithMinTemperature = std::make_shared<BYTE_GBT>();
    minTemperatureValue = std::make_shared<BYTE_GBT>();
}

void LimitValueDataPacket::addChildField()
{
    addField(idNoOfBatterySubsystemWithMaxVoltage);
    addField(idNoOfCellWithMaxVoltage);
    addField(maxCellVoltage);
    addField(idNoOfBatterySubsystemWithMinVoltage);
    addField(idNoOfCellWithMinVoltage);
    addField(minCellVoltage);
    addField(idNoOfSubsystemWithMaxTemperature);
    addField(codeOfSingleProbeWithMaxTemperature);
    addField(maxTemperatureValue);
    addField(idNoOfSubsystemWithMinTemperature);
    addField(codeOfProbeSubsystemWithMinTemperature);
    addField(minTemperatureValue);
}

std::string LimitValueDataPacket::toString()
{
    //printf("%s()", __func__);
    std::string str("");
    str += "LimitValueDataPacket\n{\n";
    str += "idNoOfBatterySubsystemWithMaxVoltage :" + idNoOfBatterySubsystemWithMaxVoltage->toString() + "\n";
    str += "idNoOfCellWithMaxVoltage :" + idNoOfCellWithMaxVoltage->toString() + "\n";
    str += "maxCellVoltage :" + maxCellVoltage->toString() + "\n";
    str += "idNoOfBatterySubsystemWithMinVoltage :" + idNoOfBatterySubsystemWithMinVoltage->toString() + "\n";
    str += "idNoOfCellWithMinVoltage :" + idNoOfCellWithMinVoltage->toString() + "\n";
    str += "minCellVoltage :" + minCellVoltage->toString() + "\n";
    str += "idNoOfSubsystemWithMaxTemperature :" + idNoOfSubsystemWithMaxTemperature->toString() + "\n";
    str += "codeOfSingleProbeWithMaxTemperature :" + codeOfSingleProbeWithMaxTemperature->toString() + "\n";
    str += "maxTemperatureValue :" + maxTemperatureValue->toString() + "\n";
    str += "idNoOfSubsystemWithMinTemperature :" + idNoOfSubsystemWithMinTemperature->toString() + "\n";
    str += "codeOfProbeSubsystemWithMinTemperature :" + codeOfProbeSubsystemWithMinTemperature->toString() + "\n";
    str += "minTemperatureValue :" + minTemperatureValue->toString() + "\n";
    str += "}";
    return str;
}

uint8_t LimitValueDataPacket::getIdNoOfBatterySubsystemWithMaxVoltage() const
{
    return *idNoOfBatterySubsystemWithMaxVoltage;
}

void LimitValueDataPacket::setIdNoOfBatterySubsystemWithMaxVoltage(const uint8_t &value)
{
    *idNoOfBatterySubsystemWithMaxVoltage = value;
}

uint8_t LimitValueDataPacket::getIdNoOfCellWithMaxVoltage() const
{
    return *idNoOfCellWithMaxVoltage;
}

void LimitValueDataPacket::setIdNoOfCellWithMaxVoltage(const uint8_t &value)
{
    *idNoOfCellWithMaxVoltage = value;
}

uint16_t LimitValueDataPacket::getMaxCellVoltage() const
{
    return *maxCellVoltage;
}

void LimitValueDataPacket::setMaxCellVoltage(const uint16_t &value)
{
    *maxCellVoltage = value;
}

uint8_t LimitValueDataPacket::getIdNoOfBatterySubsystemWithMinVoltage() const
{
    return *idNoOfBatterySubsystemWithMinVoltage;
}

void LimitValueDataPacket::setIdNoOfBatterySubsystemWithMinVoltage(const uint8_t &value)
{
    *idNoOfBatterySubsystemWithMinVoltage = value;
}

uint8_t LimitValueDataPacket::getIdNoOfCellWithMinVoltage() const
{
    return *idNoOfCellWithMinVoltage;
}

void LimitValueDataPacket::setIdNoOfCellWithMinVoltage(const uint8_t &value)
{
    *idNoOfCellWithMinVoltage = value;
}

uint16_t LimitValueDataPacket::getMinCellVoltage() const
{
    return *minCellVoltage;
}

void LimitValueDataPacket::setMinCellVoltage(const uint16_t &value)
{
    *minCellVoltage = value;
}

uint8_t LimitValueDataPacket::getIdNoOfSubsystemWithMaxTemperature() const
{
    return *idNoOfSubsystemWithMaxTemperature;
}

void LimitValueDataPacket::setIdNoOfSubsystemWithMaxTemperature(const uint8_t &value)
{
    *idNoOfSubsystemWithMaxTemperature = value;
}

uint8_t LimitValueDataPacket::getCodeOfSingleProbeWithMaxTemperature() const
{
    return *codeOfSingleProbeWithMaxTemperature;
}

void LimitValueDataPacket::setCodeOfSingleProbeWithMaxTemperature(const uint8_t &value)
{
    *codeOfSingleProbeWithMaxTemperature = value;
}

uint8_t LimitValueDataPacket::getMaxTemperatureValue() const
{
    return *maxTemperatureValue;
}

void LimitValueDataPacket::setMaxTemperatureValue(const uint8_t &value)
{
    *maxTemperatureValue = value;
}

uint8_t LimitValueDataPacket::getIdNoOfSubsystemWithMinTemperature() const
{
    return *idNoOfSubsystemWithMinTemperature;
}

void LimitValueDataPacket::setIdNoOfSubsystemWithMinTemperature(const uint8_t &value)
{
    *idNoOfSubsystemWithMinTemperature = value;
}

uint8_t LimitValueDataPacket::getCodeOfProbeSubsystemWithMinTemperature() const
{
    return *codeOfProbeSubsystemWithMinTemperature;
}

void LimitValueDataPacket::setCodeOfProbeSubsystemWithMinTemperature(const uint8_t &value)
{
    *codeOfProbeSubsystemWithMinTemperature = value;
}

uint8_t LimitValueDataPacket::getMinTemperatureValue() const
{
    return *minTemperatureValue;
}

void LimitValueDataPacket::setMinTemperatureValue(const uint8_t &value)
{
    *minTemperatureValue = value;
}

WarningDataPacket::WarningDataPacket()
{
    //printf("%s()", __func__);
    highestWarningLevel = std::make_shared<BYTE_GBT>();
    generalWarningMark = std::make_shared<DWORD_GBT>();
    listOfCodesOfChargeableEnergyStorageDeviceFaults = std::make_shared<ListOfWarningFaultData>();
    listOfCodesOfElectricalMachineFaults = std::make_shared<ListOfWarningFaultData>();
    listOfEngineFaults = std::make_shared<ListOfWarningFaultData>();
    listOfCodesOfOtherFaults = std::make_shared<ListOfWarningFaultData>();
}

void WarningDataPacket::addChildField()
{
    addField(highestWarningLevel);
    addField(generalWarningMark);

    addField(listOfCodesOfChargeableEnergyStorageDeviceFaults);

    addField(listOfCodesOfElectricalMachineFaults);

    addField(listOfEngineFaults);

    addField(listOfCodesOfOtherFaults);
}

std::string WarningDataPacket::toString()
{
    //printf("%s()", __func__);
    std::string str("");
    str += "WarningDataPacket\n{\n";
    str += "highestWarningLevel :" + highestWarningLevel->toString() + "\n";
    str += "generalWarningMark :0x" + generalWarningMark->toHexString() + "\n";
    str += listOfCodesOfChargeableEnergyStorageDeviceFaults->toString() + "\n";
    str += listOfCodesOfElectricalMachineFaults->toString() + "\n";
    str += listOfEngineFaults->toString() + "\n";
    str += listOfCodesOfOtherFaults->toString() + "\n";
    str += "}";
    return str;
}

uint8_t WarningDataPacket::getHighestWarningLevel() const
{
    return *highestWarningLevel;
}

void WarningDataPacket::setHighestWarningLevel(const uint8_t &value)
{
    *highestWarningLevel = value;
}

uint32_t WarningDataPacket::getGeneralWarningMark() const
{
    return *generalWarningMark;
}

void WarningDataPacket::setGeneralWarningMark(const uint32_t &value)
{
    *generalWarningMark = value;
}

std::shared_ptr<ListOfWarningFaultData> WarningDataPacket::getListOfCodesOfChargeableEnergyStorageDeviceFaults() const
{
    return listOfCodesOfChargeableEnergyStorageDeviceFaults;
}

std::shared_ptr<ListOfWarningFaultData> WarningDataPacket::getListOfCodesOfElectricalMachineFaults() const
{
    return listOfCodesOfElectricalMachineFaults;
}

std::shared_ptr<ListOfWarningFaultData> WarningDataPacket::getListOfEngineFaults() const
{
    return listOfEngineFaults;
}

std::shared_ptr<ListOfWarningFaultData> WarningDataPacket::getListOfCodesOfOtherFaults() const
{
    return listOfCodesOfOtherFaults;
}

VehicleLogoutPacket::VehicleLogoutPacket()
{
    //printf("%s()", __func__);
    logoutTime = std::make_shared<ChinaTimePacket>();
    logoutSN = std::make_shared<WORD_GBT>();
}

void VehicleLogoutPacket::addChildField()
{
    addField(logoutTime);
    addField(logoutSN);
}

std::string VehicleLogoutPacket::toString()
{
    //printf("%s()", __func__);
    std::string str("");
    str += "VehicleLogoutPacket\n{\n";
    str += "logoutTime\n{\n";
    str += logoutTime->toString() + "\n";
    str += "}\n";
    str += "logoutSN :" + logoutSN->toString() + "\n";
    str += "}";
    return str;
}

std::shared_ptr<ChinaTimePacket> VehicleLogoutPacket::getLogoutTime() const
{
    return logoutTime;
}

uint16_t VehicleLogoutPacket::getLogoutSN() const
{
    return *logoutSN;
}

void VehicleLogoutPacket::setLogoutSN(const uint16_t &value)
{
    *logoutSN = value;
}
////}

DataHeaderPacket::DataHeaderPacket()
{
    //printf("%s()", __func__);
    startcharacter = std::make_shared<GBTListOfItem<BYTE_GBT>>();
    startcharacter->setListSize(2);
    commandIdentification = std::make_shared<BYTE_GBT>();
    responseMark = std::make_shared<BYTE_GBT>();
    uniqueIdentificationNumber = std::make_shared<GBTListOfItem<BYTE_GBT>>();
    uniqueIdentificationNumber->setListSize(17);
    dataUnitEncryptionManner = std::make_shared<BYTE_GBT>();
}

void DataHeaderPacket::addChildField()
{
    addField(startcharacter);
    addField(commandIdentification);
    addField(responseMark);
    addField(uniqueIdentificationNumber);
    addField(dataUnitEncryptionManner);
}

std::string DataHeaderPacket::toString()
{
    //printf("%s()", __func__);
    std::string str("");
    str += "DataHeaderPacket\n{\n";
    str += "startcharacter: " + startcharacter->toHexString() + "\n";
    str += "commandIdentification: " + commandIdentification->toString() + "\n";
    str += "responseMark: " + responseMark->toString() + "\n";
    str += "uniqueIdentificationNumber: " + uniqueIdentificationNumber->toHexString() + "\n";
    str += "dataUnitEncryptionManner: " + dataUnitEncryptionManner->toString() + "\n";
    str += "}";
    return str;
}

std::string DataHeaderPacket::getStartcharacter() const
{
    return startcharacter->toString();
}

void DataHeaderPacket::setStartcharacter(const std::string &value)
{
    for (int i = 0; i < 2; i++)
    {
        *startcharacter->getItem(i) = value[i];
    }
}

uint8_t DataHeaderPacket::getCommandIdentification() const
{
    return *commandIdentification;
}

void DataHeaderPacket::setCommandIdentification(const uint8_t &value)
{
    *commandIdentification = value;
}

uint8_t DataHeaderPacket::getResponseMark() const
{
    return *responseMark;
}

void DataHeaderPacket::setResponseMark(const uint8_t &value)
{
    *responseMark = value;
}

std::string DataHeaderPacket::getUniqueIdentificationNumber() const
{
    return uniqueIdentificationNumber->toString();
}

void DataHeaderPacket::setUniqueIdentificationNumber(const std::string &value)
{
    for (int i = 0; i < 17; i++)
    {
        *uniqueIdentificationNumber->getItem(i) = value[i];
    }
}

uint8_t DataHeaderPacket::getDataUnitEncryptionManner() const
{
    return *dataUnitEncryptionManner;
}

void DataHeaderPacket::setDataUnitEncryptionManner(const uint8_t &value)
{
    *dataUnitEncryptionManner = value;
}

VehicleLoginDataPackage::VehicleLoginDataPackage()
{
    //printf("%s()", __func__);
    header = std::make_shared<DataHeaderPacket>();
    dataUnitLength = std::make_shared<WORD_GBT>();
    loginData = std::make_shared<VehicleLoginPacket>();
    checkCode = std::make_shared<BYTE_GBT>();
}

void VehicleLoginDataPackage::addChildField()
{
    addField(header);
    addField(dataUnitLength);
    addField(loginData);
    addField(checkCode);
}

std::string VehicleLoginDataPackage::toString()
{
    //printf("%s()", __func__);
    std::string str("");
    str += "VehicleLoginDataPackage\n{\n";
    str += header->toString() + "\n";
    str += "dataUnitLength: " + dataUnitLength->toString() + "\n";
    str += loginData->toString() + "\n";
    str += "checkCode: " + checkCode->toString() + "\n";
    str += "}";
    return str;
}

std::shared_ptr<DataHeaderPacket> VehicleLoginDataPackage::getHeader() const
{
    return header;
}

uint16_t VehicleLoginDataPackage::getDataUnitLength() const
{
    return *dataUnitLength;
}

void VehicleLoginDataPackage::setDataUnitLength(const uint16_t &value)
{
    *dataUnitLength = value;
}

std::shared_ptr<VehicleLoginPacket> VehicleLoginDataPackage::getLoginData() const
{
    return loginData;
}

uint8_t VehicleLoginDataPackage::getCheckCode() const
{
    return *checkCode;
}

void VehicleLoginDataPackage::setCheckCode(const uint8_t &value)
{
    *checkCode = value;
}

VehicleRealtimeDataPackage::VehicleRealtimeDataPackage()
{
    //printf("%s()", __func__);
    header = std::make_shared<DataHeaderPacket>();
    dataUnitLength = std::make_shared<WORD_GBT>();
    realtimeData = std::make_shared<RealTimeReportingPacket>();
    checkCode = std::make_shared<BYTE_GBT>();
}

void VehicleRealtimeDataPackage::addChildField()
{
    addField(header);
    addField(dataUnitLength);
    addField(realtimeData);
    addField(checkCode);
}

std::string VehicleRealtimeDataPackage::toString()
{
    //printf("%s()", __func__);
    std::string str("");
    int commandID = header->getCommandIdentification();
    if (commandID == 3)
    {
        str += "VehicleSuplementaryDataPackage\n{\n";
    }
    else if (commandID == 2)
    {
        str += "VehicleRealtimeDataPackage\n{\n";
    }

    str += header->toString() + "\n";
    str += "dataUnitLength: " + dataUnitLength->toString() + "\n";
    str += realtimeData->toString() + "\n";
    str += "checkCode: " + checkCode->toString() + "\n";
    str += "}";
    return str;
}

std::shared_ptr<DataHeaderPacket> VehicleRealtimeDataPackage::getHeader() const
{
    return header;
}

uint16_t VehicleRealtimeDataPackage::getDataUnitLength() const
{
    return *dataUnitLength;
}

void VehicleRealtimeDataPackage::setDataUnitLength(const uint16_t &value)
{
    *dataUnitLength = value;
}

std::shared_ptr<RealTimeReportingPacket> VehicleRealtimeDataPackage::getRealtimeData() const
{
    return realtimeData;
}

uint8_t VehicleRealtimeDataPackage::getCheckCode() const
{
    return *checkCode;
}

void VehicleRealtimeDataPackage::setCheckCode(const uint8_t &value)
{
    *checkCode = value;
}

void VehicleRealtimeDataPackage::setRealtimeData(const std::shared_ptr<RealTimeReportingPacket> &value)
{
    realtimeData = value;
}

VehicleLogoutDataPackage::VehicleLogoutDataPackage()
{
    //printf("%s()", __func__);
    header = std::make_shared<DataHeaderPacket>();
    dataUnitLength = std::make_shared<WORD_GBT>();
    logoutData = std::make_shared<VehicleLogoutPacket>();
    checkCode = std::make_shared<BYTE_GBT>();
}

void VehicleLogoutDataPackage::addChildField()
{
    addField(header);
    addField(dataUnitLength);
    addField(logoutData);
    addField(checkCode);
}

std::string VehicleLogoutDataPackage::toString()
{
    //printf("%s()", __func__);
    std::string str("");
    str += "VehicleLogoutDataPackage\n{\n";
    str += header->toString() + "\n";
    str += "dataUnitLength: " + dataUnitLength->toString() + "\n";
    str += logoutData->toString() + "\n";
    str += "checkCode: " + checkCode->toString() + "\n";
    str += "}";
    return str;
}

std::shared_ptr<DataHeaderPacket> VehicleLogoutDataPackage::getHeader() const
{
    return header;
}

uint16_t VehicleLogoutDataPackage::getDataUnitLength() const
{
    return *dataUnitLength;
}

void VehicleLogoutDataPackage::setDataUnitLength(const uint16_t &value)
{
    *dataUnitLength = value;
}

std::shared_ptr<VehicleLogoutPacket> VehicleLogoutDataPackage::getLogoutData() const
{
    return logoutData;
}

uint8_t VehicleLogoutDataPackage::getCheckCode() const
{
    return *checkCode;
}

void VehicleLogoutDataPackage::setCheckCode(const uint8_t &value)
{
    *checkCode = value;
}

VehicleTimingPacket::VehicleTimingPacket()
{
    //printf("%s()", __func__);
    gbtTime = std::make_shared<ChinaTimePacket>();
}

void VehicleTimingPacket::addChildField()
{
    addField(gbtTime);
}

std::string VehicleTimingPacket::toString()
{
    //printf("%s()", __func__);
    std::string str("");
    str += "VehicleTimingPacket\n{\n";
    str += "gbtTime\n{\n";
    str += gbtTime->toString() + "\n";
    str += "}\n";
    str += "}";
    return str;
}

std::shared_ptr<ChinaTimePacket> VehicleTimingPacket::getGBTTime() const
{
    return gbtTime;
}

VehicleTimingDataPackage::VehicleTimingDataPackage()
{
    //printf("%s()", __func__);
    header = std::make_shared<DataHeaderPacket>();
    dataUnitLength = std::make_shared<WORD_GBT>();
    timingData = std::make_shared<VehicleTimingPacket>();
    checkCode = std::make_shared<BYTE_GBT>();
}

void VehicleTimingDataPackage::addChildField()
{
    addField(header);
    addField(dataUnitLength);
    addField(timingData);
    addField(checkCode);
}

std::string VehicleTimingDataPackage::toString()
{
    //printf("%s()", __func__);
    std::string str("");
    str += "VehicleTimingDataPackage\n{\n";
    str += header->toString() + "\n";
    str += "dataUnitLength: " + dataUnitLength->toString() + "\n";
    str += timingData->toString() + "\n";
    str += "checkCode: " + checkCode->toString() + "\n";
    str += "}";
    return str;
}

std::shared_ptr<DataHeaderPacket> VehicleTimingDataPackage::getHeader() const
{
    return header;
}

uint16_t VehicleTimingDataPackage::getDataUnitLength() const
{
    return *dataUnitLength;
}

void VehicleTimingDataPackage::setDataUnitLength(const uint16_t &value)
{
    *dataUnitLength = value;
}

std::shared_ptr<VehicleTimingPacket> VehicleTimingDataPackage::getTimingData() const
{
    return timingData;
}

uint8_t VehicleTimingDataPackage::getCheckCode() const
{
    return *checkCode;
}

void VehicleTimingDataPackage::setCheckCode(const uint8_t &value)
{
    *checkCode = value;
}

VoltageInformationOfChargeableEnergyStoreSubsystem::VoltageInformationOfChargeableEnergyStoreSubsystem()
{
    codeOfChargeableEnergyStoreSubsystem = std::make_shared<BYTE_GBT>();
    voltageOfChargeableEnergyStorageDevice = std::make_shared<WORD_GBT>();
    currentOfChargeableEnergyStorageDevice = std::make_shared<WORD_GBT>();
    totalNumberOfCell = std::make_shared<WORD_GBT>();
    snOfStartingBatteryOfThisFrame = std::make_shared<WORD_GBT>();
    totalCellNumberOfThisFrame = std::make_shared<BYTE_GBT>();
    voltageOfCell = std::make_shared<VoltageOfCellList>();
}

void VoltageInformationOfChargeableEnergyStoreSubsystem::addChildField()
{
    addField(codeOfChargeableEnergyStoreSubsystem);
    addField(voltageOfChargeableEnergyStorageDevice);
    addField(currentOfChargeableEnergyStorageDevice);
    addField(totalNumberOfCell);
    addField(snOfStartingBatteryOfThisFrame);
    addField(totalCellNumberOfThisFrame);
    addField(voltageOfCell);
}

std::string VoltageInformationOfChargeableEnergyStoreSubsystem::toString()
{
    //printf("%s()", __func__);
    std::string str("");
    str += "VoltageInformationOfChargeableEnergyStoreSubsystem\n{\n";
    str += "codeOfChargeableEnergyStoreSubsystem :" + codeOfChargeableEnergyStoreSubsystem->toString() + "\n";
    str += "voltageOfChargeableEnergyStorageDevice :" + voltageOfChargeableEnergyStorageDevice->toString() + "\n";
    str += "currentOfChargeableEnergyStorageDevice :" + currentOfChargeableEnergyStorageDevice->toString() + "\n";
    str += "totalNumberOfCell :" + totalNumberOfCell->toString() + "\n";
    str += "snOfStartingBatteryOfThisFrame :" + snOfStartingBatteryOfThisFrame->toString() + "\n";
    str += "totalCellNumberOfThisFrame :" + totalCellNumberOfThisFrame->toString() + "\n";
    str += "voltageOfCell\n{\n" + voltageOfCell->toValueArrString() + "\n}\n";
    str += "}";
    return str;
}

bool VoltageInformationOfChargeableEnergyStoreSubsystem::deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos)
{
    bool ret = codeOfChargeableEnergyStoreSubsystem->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += codeOfChargeableEnergyStoreSubsystem->getCurSize();

    ret = voltageOfChargeableEnergyStorageDevice->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += voltageOfChargeableEnergyStorageDevice->getCurSize();

    ret = currentOfChargeableEnergyStorageDevice->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += currentOfChargeableEnergyStorageDevice->getCurSize();

    ret = totalNumberOfCell->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += totalNumberOfCell->getCurSize();

    ret = snOfStartingBatteryOfThisFrame->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += snOfStartingBatteryOfThisFrame->getCurSize();

    ret = totalCellNumberOfThisFrame->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += totalCellNumberOfThisFrame->getCurSize();

    int cellNum = *totalCellNumberOfThisFrame;
    voltageOfCell->setListSize(cellNum);
    ret = voltageOfCell->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    return true;
}

uint8_t VoltageInformationOfChargeableEnergyStoreSubsystem::getCodeOfChargeableEnergyStoreSubsystem() const
{
    return *codeOfChargeableEnergyStoreSubsystem;
}

void VoltageInformationOfChargeableEnergyStoreSubsystem::setCodeOfChargeableEnergyStoreSubsystem(const uint8_t &value)
{
    *codeOfChargeableEnergyStoreSubsystem = value;
}

uint16_t VoltageInformationOfChargeableEnergyStoreSubsystem::getVoltageOfChargeableEnergyStorageDevice() const
{
    return *voltageOfChargeableEnergyStorageDevice;
}

void VoltageInformationOfChargeableEnergyStoreSubsystem::setVoltageOfChargeableEnergyStorageDevice(const uint16_t &value)
{
    *voltageOfChargeableEnergyStorageDevice = value;
}

uint16_t VoltageInformationOfChargeableEnergyStoreSubsystem::getCurrentOfChargeableEnergyStorageDevice() const
{
    return *currentOfChargeableEnergyStorageDevice;
}

void VoltageInformationOfChargeableEnergyStoreSubsystem::setCurrentOfChargeableEnergyStorageDevice(const uint16_t &value)
{
    *currentOfChargeableEnergyStorageDevice = value;
}

uint16_t VoltageInformationOfChargeableEnergyStoreSubsystem::getTotalNumberOfCell() const
{
    return *totalNumberOfCell;
}

void VoltageInformationOfChargeableEnergyStoreSubsystem::setTotalNumberOfCell(const uint16_t &value)
{
    *totalNumberOfCell = value;
}

uint16_t VoltageInformationOfChargeableEnergyStoreSubsystem::getSnOfStartingBatteryOfThisFrame() const
{
    return *snOfStartingBatteryOfThisFrame;
}

void VoltageInformationOfChargeableEnergyStoreSubsystem::setSnOfStartingBatteryOfThisFrame(const uint16_t &value)
{
    *snOfStartingBatteryOfThisFrame = value;
}

uint8_t VoltageInformationOfChargeableEnergyStoreSubsystem::getTotalCellNumberOfThisFrame() const
{
    return *totalCellNumberOfThisFrame;
}

void VoltageInformationOfChargeableEnergyStoreSubsystem::setTotalCellNumberOfThisFrame(const uint8_t &value)
{
    *totalCellNumberOfThisFrame = value;
}

std::shared_ptr<VoltageOfCellList> VoltageInformationOfChargeableEnergyStoreSubsystem::getVoltageOfCell() const
{
    return voltageOfCell;
}

uint8_t VoltageDataOfChargeableEnergyStoreSubsystem::getQuantityOfChargeableEnergyStoreSubsystem() const
{
    return *quantityOfChargeableEnergyStoreSubsystem;
}

void VoltageDataOfChargeableEnergyStoreSubsystem::setQuantityOfChargeableEnergyStoreSubsystem(const uint8_t &value)
{
    *quantityOfChargeableEnergyStoreSubsystem = value;
}

VoltageDataOfChargeableEnergyStoreSubsystem::VoltageDataOfChargeableEnergyStoreSubsystem()
{
    quantityOfChargeableEnergyStoreSubsystem = std::make_shared<BYTE_GBT>();
    listOfVoltageInformationOfChargeableEnergyStoreSubsystem = std::make_shared<ListOfVoltageInformationOfChargeableEnergyStoreSubsystem>();
}

void VoltageDataOfChargeableEnergyStoreSubsystem::addChildField()
{
    addField(quantityOfChargeableEnergyStoreSubsystem);
    addField(listOfVoltageInformationOfChargeableEnergyStoreSubsystem);
}

std::string VoltageDataOfChargeableEnergyStoreSubsystem::toString()
{
    //printf("%s()", __func__);
    std::string str("");
    str += "VoltageDataOfChargeableEnergyStoreSubsystem\n{\n";
    str += "quantityOfChargeableEnergyStoreSubsystem :" + quantityOfChargeableEnergyStoreSubsystem->toString() + "\n";
    str += listOfVoltageInformationOfChargeableEnergyStoreSubsystem->toString() + "\n";
    str += "}";
    return str;
}

bool VoltageDataOfChargeableEnergyStoreSubsystem::deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos)
{
    bool ret = quantityOfChargeableEnergyStoreSubsystem->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += quantityOfChargeableEnergyStoreSubsystem->getCurSize();

    uint16_t cellListSize = *quantityOfChargeableEnergyStoreSubsystem;
    listOfVoltageInformationOfChargeableEnergyStoreSubsystem->setListSize(cellListSize);
    ret = listOfVoltageInformationOfChargeableEnergyStoreSubsystem->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    return true;
}

std::shared_ptr<ListOfVoltageInformationOfChargeableEnergyStoreSubsystem> VoltageDataOfChargeableEnergyStoreSubsystem::getListOfVoltageInformationOfChargeableEnergyStoreSubsystem() const
{
    return listOfVoltageInformationOfChargeableEnergyStoreSubsystem;
}

void VoltageDataOfChargeableEnergyStoreSubsystem::setListOfVoltageInformationOfChargeableEnergyStoreSubsystem(const std::shared_ptr<GBTListOfItem<VoltageInformationOfChargeableEnergyStoreSubsystem>> &value)
{
    listOfVoltageInformationOfChargeableEnergyStoreSubsystem = value;
}

TemperatureInformationOfChargeableEnergyStoreSubsystem::TemperatureInformationOfChargeableEnergyStoreSubsystem()
{
    codeOfChargeableEnergyStoreSubsystem = std::make_shared<BYTE_GBT>();
    quantityOfChargeableEnergyStoreSubsystem = std::make_shared<WORD_GBT>();
    temperatureValueOfEachChargeableEnergyStoreSubsystem = std::make_shared<TemperatureValueList>();
    *codeOfChargeableEnergyStoreSubsystem = 1;
    *quantityOfChargeableEnergyStoreSubsystem = 1;
}

void TemperatureInformationOfChargeableEnergyStoreSubsystem::addChildField()
{
    addField(codeOfChargeableEnergyStoreSubsystem);
    addField(quantityOfChargeableEnergyStoreSubsystem);
    addField(temperatureValueOfEachChargeableEnergyStoreSubsystem);
}

std::string TemperatureInformationOfChargeableEnergyStoreSubsystem::toString()
{
    //printf("%s()", __func__);
    std::string str("");
    str += "TemperatureInformationOfChargeableEnergyStoreSubsystem\n{\n";
    str += "codeOfChargeableEnergyStoreSubsystem :" + codeOfChargeableEnergyStoreSubsystem->toString() + "\n";
    str += "quantityOfChargeableEnergyStoreSubsystem :" + quantityOfChargeableEnergyStoreSubsystem->toString() + "\n";
    str += "temperatureValueOfEachChargeableEnergyStoreSubsystem\n{\n" + temperatureValueOfEachChargeableEnergyStoreSubsystem->toValueArrString() + "\n}\n";
    str += "}";
    return str;
}

bool TemperatureInformationOfChargeableEnergyStoreSubsystem::deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos)
{
    bool ret = codeOfChargeableEnergyStoreSubsystem->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += codeOfChargeableEnergyStoreSubsystem->getCurSize();
    //remainLen -= codeOfChargeableEnergyStoreSubsystem->getCurSize();

    ret = quantityOfChargeableEnergyStoreSubsystem->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += quantityOfChargeableEnergyStoreSubsystem->getCurSize();
    //remainLen -= quantityOfChargeableEnergyStoreSubsystem->getCurSize();

    int probeNum = *quantityOfChargeableEnergyStoreSubsystem;
    temperatureValueOfEachChargeableEnergyStoreSubsystem->setListSize(probeNum);
    ret = temperatureValueOfEachChargeableEnergyStoreSubsystem->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    return true;
}

uint8_t TemperatureInformationOfChargeableEnergyStoreSubsystem::getCodeOfChargeableEnergyStoreSubsystem() const
{
    return *codeOfChargeableEnergyStoreSubsystem;
}

void TemperatureInformationOfChargeableEnergyStoreSubsystem::setCodeOfChargeableEnergyStoreSubsystem(const uint8_t &value)
{
    *codeOfChargeableEnergyStoreSubsystem = value;
}

uint16_t TemperatureInformationOfChargeableEnergyStoreSubsystem::getQuantityOfChargeableEnergyStoreSubsystem() const
{
    return *quantityOfChargeableEnergyStoreSubsystem;
}

void TemperatureInformationOfChargeableEnergyStoreSubsystem::setQuantityOfChargeableEnergyStoreSubsystem(const uint16_t &value)
{
    *quantityOfChargeableEnergyStoreSubsystem = value;
}

std::shared_ptr<TemperatureValueList> TemperatureInformationOfChargeableEnergyStoreSubsystem::getTemperatureValueOfEachChargeableEnergyStoreSubsystem() const
{
    return temperatureValueOfEachChargeableEnergyStoreSubsystem;
}

void TemperatureInformationOfChargeableEnergyStoreSubsystem::setTemperatureValueOfEachChargeableEnergyStoreSubsystem(const std::shared_ptr<TemperatureValueList> &value)
{
    temperatureValueOfEachChargeableEnergyStoreSubsystem = value;
}

uint8_t TemperatureDataOfChargeableEnergyStoreSubsystem::getQuantityOfChargeableEnergyStoreSubsystem() const
{
    return *quantityOfChargeableEnergyStoreSubsystem;
}

void TemperatureDataOfChargeableEnergyStoreSubsystem::setQuantityOfChargeableEnergyStoreSubsystem(const uint8_t &value)
{
    *quantityOfChargeableEnergyStoreSubsystem = value;
}

TemperatureDataOfChargeableEnergyStoreSubsystem::TemperatureDataOfChargeableEnergyStoreSubsystem()
{
    quantityOfChargeableEnergyStoreSubsystem = std::make_shared<BYTE_GBT>();
    listOfTemperatureInformationOfChargeableEnergyStoreSubsystem = std::make_shared<ListOfTemperatureInformationOfChargeableEnergyStoreSubsystem>();
}

void TemperatureDataOfChargeableEnergyStoreSubsystem::addChildField()
{
    addField(quantityOfChargeableEnergyStoreSubsystem);
    addField(listOfTemperatureInformationOfChargeableEnergyStoreSubsystem);
}

std::string TemperatureDataOfChargeableEnergyStoreSubsystem::toString()
{
    //printf("%s()", __func__);
    std::string str("");
    str += "TemperatureDataOfChargeableEnergyStoreSubsystem\n{\n";
    str += "quantityOfChargeableEnergyStoreSubsystem :" + quantityOfChargeableEnergyStoreSubsystem->toString() + "\n";
    str += listOfTemperatureInformationOfChargeableEnergyStoreSubsystem->toString() + "\n";
    str += "}";
    return str;
}

bool TemperatureDataOfChargeableEnergyStoreSubsystem::deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos)
{
    //uint32_t remainLen = len;
    bool ret = quantityOfChargeableEnergyStoreSubsystem->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += quantityOfChargeableEnergyStoreSubsystem->getCurSize();
    //remainLen -= quantityOfChargeableEnergyStoreSubsystem->getCurSize();

    uint16_t tempListSize = *quantityOfChargeableEnergyStoreSubsystem;
    listOfTemperatureInformationOfChargeableEnergyStoreSubsystem->setListSize(tempListSize);
    ret = listOfTemperatureInformationOfChargeableEnergyStoreSubsystem->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    return true;
}

std::shared_ptr<ListOfTemperatureInformationOfChargeableEnergyStoreSubsystem> TemperatureDataOfChargeableEnergyStoreSubsystem::getListOfTemperatureInformationOfChargeableEnergyStoreSubsystem() const
{
    return listOfTemperatureInformationOfChargeableEnergyStoreSubsystem;
}

void TemperatureDataOfChargeableEnergyStoreSubsystem::setListOfTemperatureInformationOfChargeableEnergyStoreSubsystem(const std::shared_ptr<ListOfTemperatureInformationOfChargeableEnergyStoreSubsystem> &value)
{
    listOfTemperatureInformationOfChargeableEnergyStoreSubsystem = value;
}

ParameterItem::ParameterItem()
{
    parameterID = std::make_shared<BYTE_GBT>();
}

void ParameterItem::addChildField()
{
    addField(parameterID);
    uint8_t id = *parameterID;
    switch (id)
    {
    case 0x01:
    case 0x02:
    case 0x03:
    case 0x06:
    case 0x0A:
    case 0x0B:
    case 0x0F:
        addField(wordTypeField);
        break;
    case 0x04:
    case 0x09:
    case 0x0C:
    case 0x0D:
    case 0x10:
        addField(byteTypeField);
        break;
    case 0x05:
    case 0x07:
    case 0x08:
    case 0x0E:
        addField(byteArrayField);
        break;
    default:
        break;
    }
}

std::string ParameterItem::toString()
{
    std::string str("");
    str += "ParameterItem\n{\n";
    str += "parameterID :" + parameterID->toString() + "\n";
    uint8_t id = *parameterID;
    switch (id)
    {
    case 0x01:
    case 0x02:
    case 0x03:
    case 0x06:
    case 0x0A:
    case 0x0B:
    case 0x0F:
        str += "value :" + wordTypeField->toString() + "\n";
        break;
    case 0x04:
    case 0x09:
    case 0x0C:
    case 0x0D:
    case 0x10:
        str += "value :" + byteTypeField->toString() + "\n";
        break;
    case 0x05:
        str += "value :" + byteArrayField->toValueDataString() + "\n";
        break;
    case 0x07:
    case 0x08:
    case 0x0E:
        str += "value :" + byteArrayField->toString() + "\n";
        break;
    default:
        break;
    }
    str += "}";
    return str;
}

bool ParameterItem::deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos)
{
    //uint32_t remainLen = len;
    bool ret = parameterID->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += parameterID->getCurSize();
    //remainLen -= parameterID->getCurSize();

    uint8_t id = *parameterID;
    switch (id)
    {
    case 0x01:
    case 0x02:
    case 0x03:
    case 0x06:
    case 0x0A:
    case 0x0B:
    case 0x0F:
        wordTypeField = std::make_shared<WORD_GBT>();
        addField(wordTypeField);
        ret = wordTypeField->deserialize(buf, offsetPos);
        if (!ret)
        {
            return false;
        }
        offsetPos += wordTypeField->getCurSize();
        //remainLen -= wordTypeField->getCurSize();
        break;
    case 0x04:
        byteTypeField = std::make_shared<BYTE_GBT>();
        addField(byteTypeField);
        ret = byteTypeField->deserialize(buf, offsetPos);
        if (!ret)
        {
            return false;
        }
        offsetPos += byteTypeField->getCurSize();
        //remainLen -= byteTypeField->getCurSize();
        NEVInternalData::GetInstance()->setCnevDnsLength(*byteTypeField);
        break;
    case 0x05:
        byteArrayField = std::make_shared<GBTListOfItem<BYTE_GBT>>();
        addField(byteArrayField);
        byteArrayField->setListSize(NEVInternalData::GetInstance()->getCnevDnsLength());
        ret = byteArrayField->deserialize(buf, offsetPos);
        if (!ret)
        {
            return false;
        }
        offsetPos += byteArrayField->getCurSize();
        //remainLen -= byteArrayField->getCurSize();
        break;
    case 0x09:
    case 0x0C:
    case 0x10:
        byteTypeField = std::make_shared<BYTE_GBT>();
        addField(byteTypeField);
        ret = byteTypeField->deserialize(buf, offsetPos);
        if (!ret)
        {
            return false;
        }
        offsetPos += byteTypeField->getCurSize();
        //remainLen -= byteTypeField->getCurSize();
        break;
    case 0x0D:
        byteTypeField = std::make_shared<BYTE_GBT>();
        addField(byteTypeField);
        ret = byteTypeField->deserialize(buf, offsetPos);
        if (!ret)
        {
            return false;
        }
        offsetPos += byteTypeField->getCurSize();
        //remainLen -= byteTypeField->getCurSize();
        NEVInternalData::GetInstance()->setBitDnsLength(*byteTypeField);
        break;
    case 0x0E:
        byteArrayField = std::make_shared<GBTListOfItem<BYTE_GBT>>();
        addField(byteArrayField);
        byteArrayField->setListSize(NEVInternalData::GetInstance()->getBitDnsLength());
        ret = byteArrayField->deserialize(buf, offsetPos);
        if (!ret)
        {
            return false;
        }
        offsetPos += byteArrayField->getCurSize();
        //remainLen -= byteArrayField->getCurSize();
        break;
    case 0x07:
    case 0x08:
        byteArrayField = std::make_shared<GBTListOfItem<BYTE_GBT>>();
        addField(byteArrayField);
        byteArrayField->setListSize(5);
        ret = byteArrayField->deserialize(buf, offsetPos);
        if (!ret)
        {
            byteArrayField->setListSize(0);
            return false;
        }
        offsetPos += byteArrayField->getCurSize();
        //remainLen -= byteArrayField->getCurSize();
        break;
    default:
        break;
    }
    return true;
}

uint8_t ParameterItem::getParameterID() const
{
    return *parameterID;
}

void ParameterItem::setParameterID(const uint8_t &value)
{
    resetField();
    addField(parameterID);
    *parameterID = value;
    switch (value)
    {
    case 0x01:
    case 0x02:
    case 0x03:
    case 0x06:
    case 0x0A:
    case 0x0B:
    case 0x0F:
        wordTypeField = std::make_shared<WORD_GBT>();
        addField(wordTypeField);
        break;
    case 0x04:
    case 0x09:
    case 0x0C:
    case 0x0D:
    case 0x10:
        byteTypeField = std::make_shared<BYTE_GBT>();
        addField(byteTypeField);
        break;
    case 0x05:
    case 0x07:
    case 0x08:
    case 0x0E:
        byteArrayField = std::make_shared<GBTListOfItem<BYTE_GBT>>();
        addField(byteArrayField);
        break;
    default:
        break;
    }
}

uint8_t ParameterItem::getByteTypeField() const
{
    return *byteTypeField;
}

void ParameterItem::setByteTypeField(const uint8_t &value)
{
    *byteTypeField = value;
}

uint16_t ParameterItem::getWordTypeField() const
{
    return *wordTypeField;
}

void ParameterItem::setWordTypeField(const uint16_t &value)
{
    *wordTypeField = value;
}

std::string ParameterItem::getByteArrayField() const
{
    return byteArrayField->toString();
}

void ParameterItem::setByteArrayField(const std::string &value)
{
    byteArrayField->setListSize(value.length());
    for (int i = 0; i < value.length(); i++)
    {
        *byteArrayField->getItem(i) = value[i];
    }
}

ParameterQueryDownlinkPackage::ParameterQueryDownlinkPackage()
{
    timeOfParameterQuery = std::make_shared<ChinaTimePacket>();
    totalNumberOfParameter = std::make_shared<BYTE_GBT>();
    parameterId = std::make_shared<GBTListOfItem<BYTE_GBT>>();
}

void ParameterQueryDownlinkPackage::addChildField()
{
    addField(timeOfParameterQuery);
    addField(totalNumberOfParameter);
    addField(parameterId);
}

std::string ParameterQueryDownlinkPackage::toString()
{
    std::string str("");
    str += "ParameterQueryDownlinkPackage\n{\n";
    str += timeOfParameterQuery->toString() + "\n";
    str += "totalNumberOfParameter :" + totalNumberOfParameter->toString() + "\n";
    str += "parameterId : [" + parameterId->toString() + "]\n";
    str += "}";
    return str;
}

bool ParameterQueryDownlinkPackage::deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos)
{
    printf("%s()", __func__);
    //uint32_t remainLen = len;
    bool ret = timeOfParameterQuery->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += timeOfParameterQuery->getCurSize();
    //remainLen -= timeOfParameterQuery->getCurSize();

    ret = totalNumberOfParameter->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += totalNumberOfParameter->getCurSize();
    //remainLen -= totalNumberOfParameter->getCurSize();

    parameterId->setListSize(*totalNumberOfParameter);
    ret = parameterId->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += parameterId->getCurSize();
    //remainLen -= parameterId->getCurSize();
    return true;
}

std::shared_ptr<ChinaTimePacket> ParameterQueryDownlinkPackage::getTimeOfParameterQuery() const
{
    return timeOfParameterQuery;
}

uint8_t ParameterQueryDownlinkPackage::getTotalNumberOfParameter() const
{
    return *totalNumberOfParameter;
}

void ParameterQueryDownlinkPackage::setTotalNumberOfParameter(const uint8_t &value)
{
    *totalNumberOfParameter = value;
}

std::shared_ptr<GBTListOfItem<BYTE_GBT>> ParameterQueryDownlinkPackage::getParameterID() const
{
    return parameterId;
}

ParameterQueryDownlinkDataPackage::ParameterQueryDownlinkDataPackage()
{
    printf("%s()", __func__);
    header = std::make_shared<DataHeaderPacket>();
    dataUnitLength = std::make_shared<WORD_GBT>();
    parameterQueryData = std::make_shared<ParameterQueryDownlinkPackage>();
    checkCode = std::make_shared<BYTE_GBT>();
}

void ParameterQueryDownlinkDataPackage::addChildField()
{
    addField(header);
    addField(dataUnitLength);
    addField(parameterQueryData);
    addField(checkCode);
}

std::string ParameterQueryDownlinkDataPackage::toString()
{
    printf("%s()", __func__);
    std::string str("");
    str += "ParameterQueryDownlinkDataPackage\n{\n";
    str += header->toString() + "\n";
    str += "dataUnitLength: " + dataUnitLength->toString() + "\n";
    str += parameterQueryData->toString() + "\n";
    str += "checkCode: " + checkCode->toString() + "\n";
    str += "}";
    return str;
}

std::shared_ptr<DataHeaderPacket> ParameterQueryDownlinkDataPackage::getHeader() const
{
    return header;
}

uint16_t ParameterQueryDownlinkDataPackage::getDataUnitLength() const
{
    return *dataUnitLength;
}

void ParameterQueryDownlinkDataPackage::setDataUnitLength(const uint16_t &value)
{
    *dataUnitLength = value;
}

std::shared_ptr<ParameterQueryDownlinkPackage> ParameterQueryDownlinkDataPackage::getParameterQueryData() const
{
    return parameterQueryData;
}

uint8_t ParameterQueryDownlinkDataPackage::getCheckCode() const
{
    return *checkCode;
}

void ParameterQueryDownlinkDataPackage::setCheckCode(const uint8_t &value)
{
    *checkCode = value;
}

ParameterQueryUplinkPackage::ParameterQueryUplinkPackage()
{
    returnTimeOfParameterQuery = std::make_shared<ChinaTimePacket>();
    totalNumberOfReturnParameter = std::make_shared<BYTE_GBT>();
    listOfParameterItem = std::make_shared<ListOfParameterItem>();
}

void ParameterQueryUplinkPackage::addChildField()
{
    addField(returnTimeOfParameterQuery);
    addField(totalNumberOfReturnParameter);
    addField(listOfParameterItem);
}

std::string ParameterQueryUplinkPackage::toString()
{
    std::string str("");
    str += "ParameterQueryUplinkPackage\n{\n";
    str += returnTimeOfParameterQuery->toString() + "\n";
    str += "totalNumberOfReturnParameter :" + totalNumberOfReturnParameter->toString() + "\n";
    str += listOfParameterItem->toString() + "\n";
    str += "}";
    return str;
}

bool ParameterQueryUplinkPackage::deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos)
{
    printf("ParameterQueryUplinkPackage::%s()", __func__);
    //uint32_t remainLen = len;
    bool ret = returnTimeOfParameterQuery->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += returnTimeOfParameterQuery->getCurSize();
    //remainLen -= returnTimeOfParameterQuery->getCurSize();

    ret = totalNumberOfReturnParameter->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += totalNumberOfReturnParameter->getCurSize();
    //remainLen -= totalNumberOfReturnParameter->getCurSize();

    listOfParameterItem->setListSize(*totalNumberOfReturnParameter);
    ret = listOfParameterItem->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += listOfParameterItem->getCurSize();
    //remainLen -= listOfParameterItem->getCurSize();
    return true;
}

std::shared_ptr<ChinaTimePacket> ParameterQueryUplinkPackage::getReturnTimeOfParameterQuery() const
{
    return returnTimeOfParameterQuery;
}

uint8_t ParameterQueryUplinkPackage::getTotalNumberOfReturnParameter() const
{
    return *totalNumberOfReturnParameter;
}

void ParameterQueryUplinkPackage::setTotalNumberOfReturnParameter(const uint8_t &value)
{
    *totalNumberOfReturnParameter = value;
}

std::shared_ptr<ListOfParameterItem> ParameterQueryUplinkPackage::getListOfParameterItem() const
{
    return listOfParameterItem;
}

ParameterQueryUplinkDataPackage::ParameterQueryUplinkDataPackage()
{
    printf("%s()", __func__);
    header = std::make_shared<DataHeaderPacket>();
    dataUnitLength = std::make_shared<WORD_GBT>();
    parameterQueryData = std::make_shared<ParameterQueryUplinkPackage>();
    checkCode = std::make_shared<BYTE_GBT>();
}

void ParameterQueryUplinkDataPackage::addChildField()
{
    addField(header);
    addField(dataUnitLength);
    addField(parameterQueryData);
    addField(checkCode);
}

std::string ParameterQueryUplinkDataPackage::toString()
{
    printf("%s()", __func__);
    std::string str("");
    str += "ParameterQueryUplinkDataPackage\n{\n";
    str += header->toString() + "\n";
    str += "dataUnitLength: " + dataUnitLength->toString() + "\n";
    str += parameterQueryData->toString() + "\n";
    str += "checkCode: " + checkCode->toString() + "\n";
    str += "}";
    return str;
}

std::shared_ptr<DataHeaderPacket> ParameterQueryUplinkDataPackage::getHeader() const
{
    return header;
}

void ParameterQueryUplinkDataPackage::setHeader(std::shared_ptr<DataHeaderPacket> value)
{
    header = value;
}

uint16_t ParameterQueryUplinkDataPackage::getDataUnitLength() const
{
    return *dataUnitLength;
}

void ParameterQueryUplinkDataPackage::setDataUnitLength(const uint16_t &value)
{
    *dataUnitLength = value;
}

std::shared_ptr<ParameterQueryUplinkPackage> ParameterQueryUplinkDataPackage::getParameterQueryData() const
{
    return parameterQueryData;
}

uint8_t ParameterQueryUplinkDataPackage::getCheckCode() const
{
    return *checkCode;
}

void ParameterQueryUplinkDataPackage::setCheckCode(const uint8_t &value)
{
    *checkCode = value;
}

ParameterSettingPackage::ParameterSettingPackage()
{
    timeOfParameterSetting = std::make_shared<ChinaTimePacket>();
    listOfParameterItem = std::make_shared<ParameterSettingItem>();
}

void ParameterSettingPackage::addChildField()
{
    addField(timeOfParameterSetting);
    addField(listOfParameterItem);
}

std::string ParameterSettingPackage::toString()
{
    std::string str("");
    str += "ParameterSettingPackage\n{\n";
    str += timeOfParameterSetting->toString() + "\n";
    str += listOfParameterItem->toString() + "\n";
    str += "}";
    return str;
}

std::shared_ptr<ChinaTimePacket> ParameterSettingPackage::getTimeOfParameterSetting() const
{
    return timeOfParameterSetting;
}

std::shared_ptr<ParameterSettingItem> ParameterSettingPackage::getListOfParameterItem() const
{
    return listOfParameterItem;
}

void ParameterSettingPackage::setListOfParameterItem(const std::shared_ptr<ParameterSettingItem> &value)
{
    listOfParameterItem = value;
}

ParameterSettingDataPackage::ParameterSettingDataPackage()
{
    printf("%s()", __func__);
    header = std::make_shared<DataHeaderPacket>();
    dataUnitLength = std::make_shared<WORD_GBT>();
    parameterSettingPackage = std::make_shared<ParameterSettingPackage>();
    checkCode = std::make_shared<BYTE_GBT>();
}

void ParameterSettingDataPackage::addChildField()
{
    addField(header);
    addField(dataUnitLength);
    addField(parameterSettingPackage);
    addField(checkCode);
}

std::string ParameterSettingDataPackage::toString()
{
    printf("%s()", __func__);
    std::string str("");
    str += "ParameterSettingDataPackage\n{\n";
    str += header->toString() + "\n";
    str += "dataUnitLength: " + dataUnitLength->toString() + "\n";
    str += parameterSettingPackage->toString() + "\n";
    str += "checkCode: " + checkCode->toString() + "\n";
    str += "}";
    return str;
}

std::shared_ptr<DataHeaderPacket> ParameterSettingDataPackage::getHeader() const
{
    return header;
}

uint16_t ParameterSettingDataPackage::getDataUnitLength() const
{
    return *dataUnitLength;
}

void ParameterSettingDataPackage::setDataUnitLength(const uint16_t &value)
{
    *dataUnitLength = value;
}

std::shared_ptr<ParameterSettingPackage> ParameterSettingDataPackage::getParameterSettingPackage() const
{
    return parameterSettingPackage;
}

uint8_t ParameterSettingDataPackage::getCheckCode() const
{
    return *checkCode;
}

void ParameterSettingDataPackage::setCheckCode(const uint8_t &value)
{
    *checkCode = value;
}

VehicleTerminalControl::VehicleTerminalControl()
{
    time = std::make_shared<ChinaTimePacket>();
    terminalItem = std::make_shared<TerminalControlItem>();
}

void VehicleTerminalControl::addChildField()
{
    addField(time);
    addField(terminalItem);
}

std::string VehicleTerminalControl::toString()
{
    std::string str("");
    str += "VehicleTerminalControl\n{\n";
    str += time->toString() + "\n";
    str += terminalItem->toString() + "\n";
    str += "}";
    return str;
}

std::shared_ptr<ChinaTimePacket> VehicleTerminalControl::getTime() const
{
    return time;
}

std::shared_ptr<TerminalControlItem> VehicleTerminalControl::getTerminalItem()
{
    return terminalItem;
}

void VehicleTerminalControl::setTerminalItem(const std::shared_ptr<TerminalControlItem> &value)
{
    terminalItem = value;
}

VehicleTerminalControlDataPackage::VehicleTerminalControlDataPackage()
{
    printf("%s()", __func__);
    header = std::make_shared<DataHeaderPacket>();
    dataUnitLength = std::make_shared<WORD_GBT>();
    vehicleTerminalControl = std::make_shared<VehicleTerminalControl>();
    checkCode = std::make_shared<BYTE_GBT>();
}

void VehicleTerminalControlDataPackage::addChildField()
{
    addField(header);
    addField(dataUnitLength);
    addField(vehicleTerminalControl);
    addField(checkCode);
}

std::string VehicleTerminalControlDataPackage::toString()
{
    printf("%s()", __func__);
    std::string str("");
    str += "VehicleTerminalControlDataPackage\n{\n";
    str += header->toString() + "\n";
    str += "dataUnitLength: " + dataUnitLength->toString() + "\n";
    str += vehicleTerminalControl->toString() + "\n";
    str += "checkCode: " + checkCode->toString() + "\n";
    str += "}";
    return str;
}

std::shared_ptr<DataHeaderPacket> VehicleTerminalControlDataPackage::getHeader() const
{
    return header;
}

uint16_t VehicleTerminalControlDataPackage::getDataUnitLength() const
{
    return *dataUnitLength;
}

void VehicleTerminalControlDataPackage::setDataUnitLength(const uint16_t &value)
{
    *dataUnitLength = value;
}

std::shared_ptr<VehicleTerminalControl> VehicleTerminalControlDataPackage::getVehicleTerminalControl() const
{
    return vehicleTerminalControl;
}

uint8_t VehicleTerminalControlDataPackage::getCheckCode() const
{
    return *checkCode;
}

void VehicleTerminalControlDataPackage::setCheckCode(const uint8_t &value)
{
    *checkCode = value;
}

HeartbeatDataPackage::HeartbeatDataPackage()
{
    printf("%s()", __func__);
    header = std::make_shared<DataHeaderPacket>();
    dataUnitLength = std::make_shared<WORD_GBT>();
    checkCode = std::make_shared<BYTE_GBT>();
}

void HeartbeatDataPackage::addChildField()
{
    addField(header);
    addField(dataUnitLength);
    addField(checkCode);
}

std::string HeartbeatDataPackage::toString()
{
    printf("%s()", __func__);
    std::string str("");
    str += "HeartbeatDataPackage\n{\n";
    str += header->toString() + "\n";
    str += "dataUnitLength: " + dataUnitLength->toString() + "\n";
    str += "checkCode: " + checkCode->toString() + "\n";
    str += "}";
    return str;
}

std::shared_ptr<DataHeaderPacket> HeartbeatDataPackage::getHeader() const
{
    return header;
}

uint16_t HeartbeatDataPackage::getDataUnitLength() const
{
    return *dataUnitLength;
}

void HeartbeatDataPackage::setDataUnitLength(const uint16_t &value)
{
    *dataUnitLength = value;
}

uint8_t HeartbeatDataPackage::getCheckCode() const
{
    return *checkCode;
}

void HeartbeatDataPackage::setCheckCode(const uint8_t &value)
{
    *checkCode = value;
}

CodeOfChargeableEnergyStorageSystem::CodeOfChargeableEnergyStorageSystem()
{
    hvBattCompanyCode = std::make_shared<TRIBYTE_GBT>();
    hvBattProductType = std::make_shared<BYTE_GBT>();
    hvBattCellType = std::make_shared<BYTE_GBT>();
    hvBattTypeCode = std::make_shared<WORD_GBT>();
    hvBattTraceInfoCode1 = std::make_shared<BYTE_GBT>();

    hvBattTraceInfoCode2 = std::make_shared<BYTE_GBT>();
    hvBattTraceInfoCode3 = std::make_shared<BYTE_GBT>();
    hvBattTraceInfoCode4 = std::make_shared<BYTE_GBT>();
    hvBattTraceInfoCode5 = std::make_shared<BYTE_GBT>();
    hvBattTraceInfoCode6 = std::make_shared<BYTE_GBT>();
    hvBattTraceInfoCode7 = std::make_shared<BYTE_GBT>();
    hvBattProdDatePart1 = std::make_shared<WORD_GBT>();

    hvBattProdDatePart2 = std::make_shared<BYTE_GBT>();
    hvBattSerialNumPart1 = std::make_shared<DWORD_GBT>();
    hvBattSerialNumPart2 = std::make_shared<TRIBYTE_GBT>();
}

void CodeOfChargeableEnergyStorageSystem::addChildField()
{
    addField(hvBattCompanyCode);
    addField(hvBattProductType);
    addField(hvBattCellType);
    addField(hvBattTypeCode);
    addField(hvBattTraceInfoCode1);

    addField(hvBattTraceInfoCode2);
    addField(hvBattTraceInfoCode3);
    addField(hvBattTraceInfoCode4);
    addField(hvBattTraceInfoCode5);
    addField(hvBattTraceInfoCode6);
    addField(hvBattTraceInfoCode7);
    addField(hvBattProdDatePart1);

    addField(hvBattProdDatePart2);
    addField(hvBattSerialNumPart1);
    addField(hvBattSerialNumPart2);
}

std::string CodeOfChargeableEnergyStorageSystem::toString()
{
    std::string str("");
    str += "CodeOfChargeableEnergyStorageSystem\n{\n";
    str += "hvBattCompanyCode: " + hvBattCompanyCode->toString() + "\n";
    str += "hvBattProductType: " + hvBattProductType->toString() + "\n";
    str += "hvBattCellType: " + hvBattCellType->toString() + "\n";
    str += "hvBattTypeCode: " + hvBattTypeCode->toString() + "\n";
    str += "hvBattTraceInfoCode1: " + hvBattTraceInfoCode1->toString() + "\n";
    str += "hvBattTraceInfoCode2: " + hvBattTraceInfoCode2->toString() + "\n";
    str += "hvBattTraceInfoCode3: " + hvBattTraceInfoCode3->toString() + "\n";
    str += "hvBattTraceInfoCode4: " + hvBattTraceInfoCode4->toString() + "\n";
    str += "hvBattTraceInfoCode5: " + hvBattTraceInfoCode5->toString() + "\n";
    str += "hvBattTraceInfoCode6: " + hvBattTraceInfoCode6->toString() + "\n";
    str += "hvBattTraceInfoCode7: " + hvBattTraceInfoCode7->toString() + "\n";
    str += "hvBattProdDatePart1: " + hvBattProdDatePart1->toString() + "\n";
    str += "hvBattProdDatePart2: " + hvBattProdDatePart2->toString() + "\n";
    str += "hvBattSerialNumPart1: " + hvBattSerialNumPart1->toString() + "\n";
    str += "hvBattSerialNumPart2: " + hvBattSerialNumPart2->toString() + "\n";
    str += "}";
    return str;
}

int CodeOfChargeableEnergyStorageSystem::getHvBattCellType() const
{
    return *hvBattCellType;
}

void CodeOfChargeableEnergyStorageSystem::setHvBattCellType(const int &value)
{
    *hvBattCellType = value;
}

int CodeOfChargeableEnergyStorageSystem::getHvBattCompanyCode() const
{
    return *hvBattCompanyCode;
}

void CodeOfChargeableEnergyStorageSystem::setHvBattCompanyCode(const int &value)
{
    *hvBattCompanyCode = value;
}

int CodeOfChargeableEnergyStorageSystem::getHvBattProdDatePart1() const
{
    return *hvBattProdDatePart1;
}

void CodeOfChargeableEnergyStorageSystem::setHvBattProdDatePart1(const int &value)
{
    *hvBattProdDatePart1 = value;
}

int CodeOfChargeableEnergyStorageSystem::getHvBattProdDatePart2() const
{
    return *hvBattProdDatePart2;
}

void CodeOfChargeableEnergyStorageSystem::setHvBattProdDatePart2(const int &value)
{
    *hvBattProdDatePart2 = value;
}

int CodeOfChargeableEnergyStorageSystem::getHvBattProductType() const
{
    return *hvBattProductType;
}

void CodeOfChargeableEnergyStorageSystem::setHvBattProductType(const int &value)
{
    *hvBattProductType = value;
}

int CodeOfChargeableEnergyStorageSystem::getHvBattSerialNumPart1() const
{
    return *hvBattSerialNumPart1;
}

void CodeOfChargeableEnergyStorageSystem::setHvBattSerialNumPart1(const int &value)
{
    *hvBattSerialNumPart1 = value;
}

int CodeOfChargeableEnergyStorageSystem::getHvBattSerialNumPart2() const
{
    return *hvBattSerialNumPart2;
}

void CodeOfChargeableEnergyStorageSystem::setHvBattSerialNumPart2(const int &value)
{
    *hvBattSerialNumPart2 = value;
}

int CodeOfChargeableEnergyStorageSystem::getHvBattTraceInfoCode1() const
{
    return *hvBattTraceInfoCode1;
}

void CodeOfChargeableEnergyStorageSystem::setHvBattTraceInfoCode1(const int &value)
{
    *hvBattTraceInfoCode1 = value;
}

int CodeOfChargeableEnergyStorageSystem::getHvBattTraceInfoCode2() const
{
    return *hvBattTraceInfoCode2;
}

void CodeOfChargeableEnergyStorageSystem::setHvBattTraceInfoCode2(const int &value)
{
    *hvBattTraceInfoCode2 = value;
}

int CodeOfChargeableEnergyStorageSystem::getHvBattTraceInfoCode3() const
{
    return *hvBattTraceInfoCode3;
}

void CodeOfChargeableEnergyStorageSystem::setHvBattTraceInfoCode3(const int &value)
{
    *hvBattTraceInfoCode3 = value;
}

int CodeOfChargeableEnergyStorageSystem::getHvBattTraceInfoCode4() const
{
    return *hvBattTraceInfoCode4;
}

void CodeOfChargeableEnergyStorageSystem::setHvBattTraceInfoCode4(const int &value)
{
    *hvBattTraceInfoCode4 = value;
}

int CodeOfChargeableEnergyStorageSystem::getHvBattTraceInfoCode5() const
{
    return *hvBattTraceInfoCode5;
}

void CodeOfChargeableEnergyStorageSystem::setHvBattTraceInfoCode5(const int &value)
{
    *hvBattTraceInfoCode5 = value;
}

int CodeOfChargeableEnergyStorageSystem::getHvBattTraceInfoCode6() const
{
    return *hvBattTraceInfoCode6;
}

void CodeOfChargeableEnergyStorageSystem::setHvBattTraceInfoCode6(const int &value)
{
    *hvBattTraceInfoCode6 = value;
}

int CodeOfChargeableEnergyStorageSystem::getHvBattTraceInfoCode7() const
{
    return *hvBattTraceInfoCode7;
}

void CodeOfChargeableEnergyStorageSystem::setHvBattTraceInfoCode7(const int &value)
{
    *hvBattTraceInfoCode7 = value;
}

int CodeOfChargeableEnergyStorageSystem::getHvBattTypeCode() const
{
    return *hvBattTypeCode;
}

void CodeOfChargeableEnergyStorageSystem::setHvBattTypeCode(const int &value)
{
    *hvBattTypeCode = value;
}

TerminalTimingDownlinkDataPackage::TerminalTimingDownlinkDataPackage()
{
    printf("%s()", __func__);
    header = std::make_shared<DataHeaderPacket>();
    dataUnitLength = std::make_shared<WORD_GBT>();
    time = std::make_shared<ChinaTimePacket>();
    checkCode = std::make_shared<BYTE_GBT>();
}

void TerminalTimingDownlinkDataPackage::addChildField()
{
    addField(header);
    addField(dataUnitLength);
    addField(time);
    addField(checkCode);
}

std::string TerminalTimingDownlinkDataPackage::toString()
{
    printf("%s()", __func__);
    std::string str("");
    str += "TerminalTimingDownlinkDataPackage\n{\n";
    str += header->toString() + "\n";
    str += "dataUnitLength: " + dataUnitLength->toString() + "\n";
    str += time->toString() + "\n";
    str += "checkCode: " + checkCode->toString() + "\n";
    str += "}";
    return str;
}

std::shared_ptr<DataHeaderPacket> TerminalTimingDownlinkDataPackage::getHeader() const
{
    return header;
}

uint16_t TerminalTimingDownlinkDataPackage::getDataUnitLength() const
{
    return *dataUnitLength;
}

void TerminalTimingDownlinkDataPackage::setDataUnitLength(const uint16_t &value)
{
    *dataUnitLength = value;
}

uint8_t TerminalTimingDownlinkDataPackage::getCheckCode() const
{
    return *checkCode;
}

void TerminalTimingDownlinkDataPackage::setCheckCode(const uint8_t &value)
{
    *checkCode = value;
}

std::shared_ptr<ChinaTimePacket> TerminalTimingDownlinkDataPackage::getTime() const
{
    return time;
}

AcknowledgeDataPackage::AcknowledgeDataPackage()
{
    printf("%s()", __func__);
    header = std::make_shared<DataHeaderPacket>();
    dataUnitLength = std::make_shared<WORD_GBT>();
    dataUnit = std::make_shared<GBTListOfItem<BYTE_GBT>>();
    checkCode = std::make_shared<BYTE_GBT>();
}

void AcknowledgeDataPackage::addChildField()
{
    addField(header);
    addField(dataUnitLength);
    addField(dataUnit);
    addField(checkCode);
}

std::string AcknowledgeDataPackage::toString()
{
    printf("%s()", __func__);
    std::string str("");
    str += "AcknowledgeDataPackage\n{\n";
    str += header->toString() + "\n";
    str += "dataUnitLength: " + dataUnitLength->toString() + "\n";
    str += "dataUnit: " + dataUnit->toHexString() + "\n";
    str += "checkCode: " + checkCode->toString() + "\n";
    str += "}";
    return str;
}

bool AcknowledgeDataPackage::deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos)
{
    //uint32_t remainLen = len;
    bool ret = header->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += header->getCurSize();
    //remainLen -= header->getCurSize();

    ret = dataUnitLength->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += dataUnitLength->getCurSize();
    //remainLen -= dataUnitLength->getCurSize();

    uint16_t length = *dataUnitLength;
    dataUnit->setListSize(length);
    ret = dataUnit->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += dataUnit->getCurSize();
    //remainLen -= dataUnit->getCurSize();

    ret = checkCode->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += checkCode->getCurSize();
    //remainLen -= checkCode->getCurSize();

    return true;
}

std::shared_ptr<DataHeaderPacket> AcknowledgeDataPackage::getHeader() const
{
    return header;
}

uint16_t AcknowledgeDataPackage::getDataUnitLength() const
{
    return *dataUnitLength;
}

void AcknowledgeDataPackage::setDataUnitLength(const uint16_t &value)
{
    *dataUnitLength = value;
}

uint8_t AcknowledgeDataPackage::getCheckCode() const
{
    return *checkCode;
}

void AcknowledgeDataPackage::setCheckCode(const uint8_t &value)
{
    *checkCode = value;
}

std::shared_ptr<GBTListOfItem<BYTE_GBT>> AcknowledgeDataPackage::getDataUnit() const
{
    return dataUnit;
}

ListOfWarningFaultData::ListOfWarningFaultData()
{
    numberOfFaults = std::make_shared<BYTE_GBT>();
    listOfFaults = std::make_shared<ListOfFaultData>();
}

void ListOfWarningFaultData::addChildField()
{
    addField(numberOfFaults);
    addField(listOfFaults);
}

std::string ListOfWarningFaultData::toString()
{
    std::string str("");
    str += "ListOfWarningFaultData\n{\n";
    str += "numberOfFaults: " + numberOfFaults->toString() + "\n";
    str += "listOfFaults: " + listOfFaults->toHexString() + "\n";
    str += "}";
    return str;
}

bool ListOfWarningFaultData::deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos)
{
    //uint32_t remainLen = len;
    bool ret = numberOfFaults->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += numberOfFaults->getCurSize();
    //remainLen -= numberOfFaults->getCurSize();

    uint16_t faultNum = *numberOfFaults;
    listOfFaults->setListSize(faultNum);
    ret = listOfFaults->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    return true;
}

std::shared_ptr<ListOfFaultData> ListOfWarningFaultData::getListOfFaults() const
{
    return listOfFaults;
}

uint8_t ListOfWarningFaultData::getNumberOfFaults() const
{
    return *numberOfFaults;
}

void ListOfWarningFaultData::setNumberOfFaults(const uint8_t &value)
{
    *numberOfFaults = value;
}

ParameterSettingItem::ParameterSettingItem()
{
    totalNumberOfParameter = std::make_shared<BYTE_GBT>();
    listOfParameterItem = std::make_shared<ListOfParameterItem>();
}

void ParameterSettingItem::addChildField()
{
    addField(totalNumberOfParameter);
    addField(listOfParameterItem);
}

std::string ParameterSettingItem::toString()
{
    std::string str("");
    str += "ParameterSettingPackage\n{\n";
    str += "totalNumberOfParameter :" + totalNumberOfParameter->toString() + "\n";
    str += listOfParameterItem->toString() + "\n";
    str += "}";
    return str;
}

bool ParameterSettingItem::deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos)
{
    //uint32_t remainLen = len;

    bool ret = totalNumberOfParameter->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += totalNumberOfParameter->getCurSize();
    //remainLen -= totalNumberOfParameter->getCurSize();

    uint8_t parameterNum = *totalNumberOfParameter;
    listOfParameterItem->setListSize(parameterNum);
    ret = listOfParameterItem->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += listOfParameterItem->getCurSize();
    //remainLen -= listOfParameterItem->getCurSize();
    return true;
}

uint8_t ParameterSettingItem::getTotalNumberOfParameter() const
{
    return *totalNumberOfParameter;
}

void ParameterSettingItem::setTotalNumberOfParameter(const uint8_t &value)
{
    *totalNumberOfParameter = value;
}

std::shared_ptr<GBTListOfItem<ParameterItem>> ParameterSettingItem::getListOfParameterItem() const
{
    return listOfParameterItem;
}

void ParameterSettingItem::setListOfParameterItem(const std::shared_ptr<GBTListOfItem<ParameterItem>> &listInputItem)
{
    listOfParameterItem = listInputItem;
}

TerminalControlItem::TerminalControlItem()
{
    commandId = std::make_shared<BYTE_GBT>();
}

void TerminalControlItem::addChildField()
{
    addField(commandId);
    switch (*commandId)
    {
    case 0x01:
        addField(remoteUpgradingUrl);
        break;
    case 0x06:
        addField(warningLevel);
        break;
    default:
        break;
    }
}

std::string TerminalControlItem::toString()
{
    std::string str("");
    str += "TerminalControlItem\n{\n";

    str += "commandId: " + commandId->toString() + "\n";
    switch (*commandId)
    {
    case 0x01:
        str += "remoteUpgradingUrl: " + remoteUpgradingUrl->toString() + "\n";
        break;
    case 0x06:
        str += "warningLevel: " + warningLevel->toString() + "\n";
        break;
    default:
        break;
    }
    str += "}";
    return str;
}

bool TerminalControlItem::deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos)
{
    //uint32_t remainLen = len;
    bool ret = commandId->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += commandId->getCurSize();
    //remainLen -= commandId->getCurSize();

    switch (*commandId)
    {
    case 0x01:
        remoteUpgradingUrl = std::make_shared<GBTListOfItem<BYTE_GBT>>();
        remoteUpgradingUrl->setListSize(buf.size() - offsetPos);
        ret = remoteUpgradingUrl->deserialize(buf, offsetPos);
        if (!ret)
        {
            return false;
        }
        offsetPos += remoteUpgradingUrl->getCurSize();
        //remainLen -= remoteUpgradingUrl->getCurSize();
        addField(remoteUpgradingUrl);
        break;
    case 0x06:
        warningLevel = std::make_shared<BYTE_GBT>();
        ret = warningLevel->deserialize(buf, offsetPos);
        if (!ret)
        {
            return false;
        }
        offsetPos += warningLevel->getCurSize();
        //remainLen -= warningLevel->getCurSize();
        addField(warningLevel);
        break;
    default:
        break;
    }
    return true;
}

uint8_t TerminalControlItem::getCommandId() const
{
    return *commandId;
}

void TerminalControlItem::setCommandId(const uint8_t &value)
{
    resetField();
    addField(commandId);
    *commandId = value;
    switch (*commandId)
    {
    case 0x01:
        remoteUpgradingUrl = std::make_shared<GBTListOfItem<BYTE_GBT>>();
        addField(remoteUpgradingUrl);
        break;
    case 0x06:
        warningLevel = std::make_shared<BYTE_GBT>();
        addField(warningLevel);
        break;
    default:
        break;
    }
}

std::shared_ptr<GBTListOfItem<BYTE_GBT>> TerminalControlItem::getRemoteUpgradingUrl() const
{
    return remoteUpgradingUrl;
}

void TerminalControlItem::setRemoteUpgradingUrl(const std::shared_ptr<GBTListOfItem<BYTE_GBT>> &value)
{
    remoteUpgradingUrl = value;
}

uint8_t TerminalControlItem::getWarningLevel() const
{
    return *warningLevel;
}

void TerminalControlItem::setWarningLevel(const uint8_t &value)
{
    *warningLevel = value;
}
