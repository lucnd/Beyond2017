#define LOG_TAG "[NEV]GBTTransportStoreageConversion"
//#include <Log.h>

#include "GBTTransportStoreageConversion.h"

GBTTransportStoreageConversion::GBTTransportStoreageConversion()
{

}

void GBTTransportStoreageConversion::sampleGBTStorageDataFromVehicleRealtimeDataPackage(std::shared_ptr<GBTStorageData> storeData, std::shared_ptr<VehicleRealtimeDataPackage> realtimeData)
{
    storeData->setDataAcquisitionTime(realtimeData->getRealtimeData()->getDataAcquisitionTime());
    storeData->setCompleteVehicleData(realtimeData->getRealtimeData()->getCompleteVehicleDataPacket());
    storeData->setElectricMachineData(realtimeData->getRealtimeData()->getElectricMachineDataPacket());
    storeData->setDataOfEngine(realtimeData->getRealtimeData()->getDataOfEnginePacket());
    storeData->setGpsData(realtimeData->getRealtimeData()->getGpsDataPacket());
    storeData->setLimitValueData(realtimeData->getRealtimeData()->getLimitValueDataPacket());
    storeData->setWarningData(realtimeData->getRealtimeData()->getWarningDataPacket());

    storeData->setCellVoltageData(getCellVoltageStorageData(realtimeData->getRealtimeData()->getVoltageDataOfChargeableEnergyStoreSubsystem()));
    storeData->setTemperatureData(getTemperatureStorageData(realtimeData->getRealtimeData()->getTemperatureDataOfChargeableEnergyStoreSubsystem()));
}

void GBTTransportStoreageConversion::sampleVehicleRealtimeDataPackageFromGBTStorageData(std::shared_ptr<VehicleRealtimeDataPackage> realtimeData, std::shared_ptr<GBTStorageData> storeData)
{
    GBTDataPackaging packaging;
    packaging.sampleDataHeaderPacket(realtimeData->getHeader());
    realtimeData->getHeader()->setCommandIdentification(0x03);
    realtimeData->setRealtimeData(getRealTimeReportingPacket(storeData));
    packaging.sampleFuelCellDataPacket(realtimeData->getRealtimeData()->getFuelCellDataPacket());

    realtimeData->makeSerializeStruct();
    int dataUnitLength = realtimeData->getRealtimeData()->getCurSize();
    realtimeData->setDataUnitLength(dataUnitLength);

    realtimeData->setCheckCode(0);
}

std::shared_ptr<CellVoltageStorageData> GBTTransportStoreageConversion::getCellVoltageStorageData(std::shared_ptr<VoltageDataOfChargeableEnergyStoreSubsystem> rtCellData)
{
    std::shared_ptr<CellVoltageStorageData> stCellData = std::make_shared<CellVoltageStorageData>();
    std::shared_ptr<VoltageOfCellList> cellList = std::make_shared<VoltageOfCellList>();
    std::shared_ptr<ListOfVoltageInformationOfChargeableEnergyStoreSubsystem> listOfVolInfo = rtCellData->getListOfVoltageInformationOfChargeableEnergyStoreSubsystem();
    uint8_t paralellCellsCount = 1;

    bool isVolFrameValid = NEVInternalData::GetInstance()->checkAllVoltageFrameValid();
    if(isVolFrameValid)
    {
        int cellIdx = 0;
        paralellCellsCount = NEVInternalData::GetInstance()->getHvBattMuxModule(0)->getParallelCellsCount();

        for(int i = 0; i < listOfVolInfo->getListSize(); i++)
        {
            std::shared_ptr<VoltageInformationOfChargeableEnergyStoreSubsystem> volInfo = listOfVolInfo->getItem(i);

            for(int j = 0; j < volInfo->getVoltageOfCell()->getListSize(); j++)
            {
                if(j == cellIdx)
                {
                    cellList->prepend(volInfo->getVoltageOfCell()->getItem(j));
                    cellIdx += paralellCellsCount;
                }
            }
            cellIdx -= volInfo->getVoltageOfCell()->getListSize();
        }
    }
    else
    {
        std::shared_ptr<WORD_GBT> item = std::make_shared<WORD_GBT>();
        *item = 0xFFFF;
        cellList->prepend(item);
    }

    stCellData->setTotalVoltage(listOfVolInfo->getItem(0)->getVoltageOfChargeableEnergyStorageDevice());
    stCellData->setTotalCurrent(listOfVolInfo->getItem(0)->getCurrentOfChargeableEnergyStorageDevice());
    stCellData->setVoltageOfCellList(cellList);
    stCellData->setParallelCellsNum(paralellCellsCount);
    stCellData->setTotalNumberOfCell(cellList->getListSize());
    return stCellData;
}

std::shared_ptr<TemperatureStorageData> GBTTransportStoreageConversion::getTemperatureStorageData(std::shared_ptr<TemperatureDataOfChargeableEnergyStoreSubsystem> rtProbeData)
{
    std::shared_ptr<TemperatureStorageData> stProbeData = std::make_shared<TemperatureStorageData>();
    std::shared_ptr<TemperatureValueList> probeList = std::make_shared<TemperatureValueList>();

    std::shared_ptr<ListOfTemperatureInformationOfChargeableEnergyStoreSubsystem> listOfTempInfo = rtProbeData->getListOfTemperatureInformationOfChargeableEnergyStoreSubsystem();
    for(int i = 0; i < listOfTempInfo->getListSize(); i++)
    {
        std::shared_ptr<TemperatureInformationOfChargeableEnergyStoreSubsystem> tempInfo = listOfTempInfo->getItem(i);
        for(int j = 0; j < tempInfo->getTemperatureValueOfEachChargeableEnergyStoreSubsystem()->getListSize(); j++)
        {
            probeList->prepend(tempInfo->getTemperatureValueOfEachChargeableEnergyStoreSubsystem()->getItem(j));
        }
    }
    stProbeData->setTemperatureValueList(probeList);
    stProbeData->setTempProbeCount(probeList->getListSize());
    return stProbeData;
}

std::shared_ptr<RealTimeReportingPacket> GBTTransportStoreageConversion::getRealTimeReportingPacket(std::shared_ptr<GBTStorageData> storeData)
{
    std::shared_ptr<RealTimeReportingPacket> rtData = std::make_shared<RealTimeReportingPacket>();
    rtData->setDataAcquisitionTime(storeData->getDataAcquisitionTime());
    rtData->setCompleteVehicleDataPacket(storeData->getCompleteVehicleData());
    rtData->setElectricMachineDataPacket(storeData->getElectricMachineData());
    rtData->setDataOfEnginePacket(storeData->getDataOfEngine());
    rtData->setGpsDataPacket(storeData->getGpsData());
    rtData->setLimitValueDataPacket(storeData->getLimitValueData());
    rtData->setWarningDataPacket(storeData->getWarningData());
    rtData->setVoltageDataOfChargeableEnergyStoreSubsystem(getVoltageDataOfChargeableEnergyStoreSubsystem(storeData->getCellVoltageData()));
    rtData->setTemperatureDataOfChargeableEnergyStoreSubsystem(getTemperatureDataOfChargeableEnergyStoreSubsystem(storeData->getTemperatureData()));
    return rtData;
}

std::shared_ptr<VoltageDataOfChargeableEnergyStoreSubsystem> GBTTransportStoreageConversion::getVoltageDataOfChargeableEnergyStoreSubsystem(std::shared_ptr<CellVoltageStorageData> stCellData)
{
    std::shared_ptr<VoltageDataOfChargeableEnergyStoreSubsystem> rtCellData = std::make_shared<VoltageDataOfChargeableEnergyStoreSubsystem>();
    rtCellData->setListOfVoltageInformationOfChargeableEnergyStoreSubsystem(getListOfVoltageInformationOfChargeableEnergyStoreSubsystem(stCellData));
    rtCellData->setQuantityOfChargeableEnergyStoreSubsystem(rtCellData->getListOfVoltageInformationOfChargeableEnergyStoreSubsystem()->getListSize());
    return rtCellData;
}

std::shared_ptr<ListOfVoltageInformationOfChargeableEnergyStoreSubsystem> GBTTransportStoreageConversion::getListOfVoltageInformationOfChargeableEnergyStoreSubsystem(std::shared_ptr<CellVoltageStorageData> stCellData)
{
    std::shared_ptr<ListOfVoltageInformationOfChargeableEnergyStoreSubsystem> data = std::make_shared<ListOfVoltageInformationOfChargeableEnergyStoreSubsystem>();
    std::shared_ptr<VoltageOfCellList> voltageOfCell = stCellData->getVoltageOfCellList();

    uint8_t paralellCellsCount = stCellData->getParallelCellsNum();
    uint16_t seriesCellsCount = voltageOfCell->getListSize();
    uint16_t totalNumberOfCell = seriesCellsCount * paralellCellsCount;
    printf("totalNumberOfCell:%d", totalNumberOfCell);

    int listCount = (totalNumberOfCell - 1) / 200 + 1;
    data->setListSize(listCount);
    int snOfBattery = 1;
    for(int i = 0; i < listCount; i++)
    {
        std::shared_ptr<VoltageInformationOfChargeableEnergyStoreSubsystem> item = data->getItem(i);
        item->setCodeOfChargeableEnergyStoreSubsystem(i + 1);

        item->setVoltageOfChargeableEnergyStorageDevice(stCellData->getTotalVoltage());

        item->setCurrentOfChargeableEnergyStorageDevice(stCellData->getTotalCurrent());

        item->setTotalNumberOfCell(totalNumberOfCell);

        item->setSnOfStartingBatteryOfThisFrame(snOfBattery);
        snOfBattery += 200;

        uint8_t totalCellNumberOfThisFrame = 0;
        if(i < listCount - 1)
        {
            totalCellNumberOfThisFrame = 200;
        }
        else
        {
            totalCellNumberOfThisFrame = totalNumberOfCell - (listCount - 1) * 200;
        }
        item->setTotalCellNumberOfThisFrame(totalCellNumberOfThisFrame);

        std::shared_ptr<VoltageOfCellList> voltageOfCellOfThisFrame = item->getVoltageOfCell();
        for(int j = 0; j < totalCellNumberOfThisFrame; j++)
        {
            int cellIdx = i * 200 + j;
            int stVolIdx = cellIdx / paralellCellsCount;
            voltageOfCellOfThisFrame->prepend(voltageOfCell->getItem(stVolIdx));
        }
    }
    return data;
}

std::shared_ptr<TemperatureDataOfChargeableEnergyStoreSubsystem> GBTTransportStoreageConversion::getTemperatureDataOfChargeableEnergyStoreSubsystem(std::shared_ptr<TemperatureStorageData> stProbeData)
{
    std::shared_ptr<TemperatureDataOfChargeableEnergyStoreSubsystem> data = std::make_shared<TemperatureDataOfChargeableEnergyStoreSubsystem>();
    data->setQuantityOfChargeableEnergyStoreSubsystem(1);

    data->setListOfTemperatureInformationOfChargeableEnergyStoreSubsystem(getListOfTemperatureInformationOfChargeableEnergyStoreSubsystem(stProbeData));
    return data;
}

std::shared_ptr<ListOfTemperatureInformationOfChargeableEnergyStoreSubsystem> GBTTransportStoreageConversion::getListOfTemperatureInformationOfChargeableEnergyStoreSubsystem(std::shared_ptr<TemperatureStorageData> stProbeData)
{
    std::shared_ptr<ListOfTemperatureInformationOfChargeableEnergyStoreSubsystem> data = std::make_shared<ListOfTemperatureInformationOfChargeableEnergyStoreSubsystem>();
    std::shared_ptr<TemperatureInformationOfChargeableEnergyStoreSubsystem> item = std::make_shared<TemperatureInformationOfChargeableEnergyStoreSubsystem>();

    item->setCodeOfChargeableEnergyStoreSubsystem(1);
    item->setTemperatureValueOfEachChargeableEnergyStoreSubsystem(stProbeData->getTemperatureValueList());
    item->setQuantityOfChargeableEnergyStoreSubsystem(stProbeData->getTemperatureValueList()->getListSize());

    data->prepend(item);
    return data;
}
