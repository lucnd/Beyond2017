//#define LOG_TAG "[NEV]GBTDataPackaging"
//#include <Log.h>

#include "NEVInternalData.h"
#include "NEVConfigData.h"
#include "NEVSystemProperty.h"
#include "NEVDataType.h"
#include "GBTDataPackaging.h"
#include "GBTUtil.h"
#include <ctime>
#include <cmath>
#include "NEVMultiplexCanData.h"
#include "NEVApplicationType.h"

void GBTDataPackaging::sampleDataAcquisitionTime(std::shared_ptr<ChinaTimePacket> dataAcquisitionTime)
{
    LOGV("%s()", __func__);
    time_t timer = GBTUtil::getBeijingTime();

    const struct tm *date = localtime(&timer);   // Convert timer

    dataAcquisitionTime->setYear(date->tm_year - 100);
    dataAcquisitionTime->setMonth(date->tm_mon + 1);
    dataAcquisitionTime->setDay(date->tm_mday);
    dataAcquisitionTime->setHour(date->tm_hour);
    dataAcquisitionTime->setMinute(date->tm_min);
    dataAcquisitionTime->setSecond(date->tm_sec);
}

void GBTDataPackaging::sampleVehicleLoginPacket(std::shared_ptr<VehicleLoginPacket> data)
{
    sampleDataAcquisitionTime(data->getDataAcquisitionTime());

    int loginSn = GBTUtil::getLoginSerialNumber();
    data->setLoginSerialNumber(loginSn);

    std::string iccidStr = NEVConfigData::GetInstance()->getICCID();
    data->setIccid(iccidStr);

    int quantityOfCESS = 1;
    data->setQuantityOfChargeableEnergyStorageSubsystem(quantityOfCESS);

    int codeLengthOfCESS = 24;
    data->setCodeLengthOfChargeableEnergyStorageSystem((codeLengthOfCESS));

    sampleCodeOfChargeableEnergyStorageSystem(data->getCodeOfChargeableEnergyStorageSystem());
}

void GBTDataPackaging::sampleDataHeaderPacket(std::shared_ptr<DataHeaderPacket> data)
{
    data->setStartcharacter("##");
    data->setCommandIdentification(0x01);
    data->setResponseMark(0xFE);
    std::string vinStr = NEVConfigData::GetInstance()->getVINData();
    data->setUniqueIdentificationNumber(vinStr);
    data->setDataUnitEncryptionManner(0x01);
}

void GBTDataPackaging::sampleVehicleLoginDataPackage(std::shared_ptr<VehicleLoginDataPackage> data)
{
    sampleDataHeaderPacket(data->getHeader());
    data->getHeader()->setCommandIdentification(LOGIN_MESSAGE);

    sampleVehicleLoginPacket(data->getLoginData());
    data->makeSerializeStruct();
    int dataUnitLength = data->getLoginData()->getCurSize();
    data->setDataUnitLength(dataUnitLength);

    data->setCheckCode(0);
}

void GBTDataPackaging::sampleDefaultRealTimeReportingPacket(std::shared_ptr<RealTimeReportingPacket> data)
{
    sampleDataAcquisitionTime(data->getDataAcquisitionTime());

    sampleDefaultCompleteVehicleDataPacket(data->getCompleteVehicleDataPacket());

    sampleElectricMachineDataPacket(data->getElectricMachineDataPacket());

    sampleFuelCellDataPacket(data->getFuelCellDataPacket());

    sampleDataOfEnginePacket(data->getDataOfEnginePacket());

    sampleGPSDataPacket(data->getGpsDataPacket());

    sampleLimitValueDataPacket(data->getLimitValueDataPacket());

    sampleWarningDataPacket(data->getWarningDataPacket());

    sampleVoltageDataOfChargeableEnergyStoreSubsystem(data->getVoltageDataOfChargeableEnergyStoreSubsystem());

    sampleTemperatureDataOfChargeableEnergyStoreSubsystem(data->getTemperatureDataOfChargeableEnergyStoreSubsystem());
}

void GBTDataPackaging::sampleRealTimeReportingPacket(std::shared_ptr<RealTimeReportingPacket> data)
{
    sampleDataAcquisitionTime(data->getDataAcquisitionTime());

    sampleCompleteVehicleDataPacket(data->getCompleteVehicleDataPacket());

    sampleElectricMachineDataPacket(data->getElectricMachineDataPacket());

    sampleFuelCellDataPacket(data->getFuelCellDataPacket());

    sampleDataOfEnginePacket(data->getDataOfEnginePacket());

    sampleGPSDataPacket(data->getGpsDataPacket());

    sampleLimitValueDataPacket(data->getLimitValueDataPacket());

    sampleWarningDataPacket(data->getWarningDataPacket());

    sampleVoltageDataOfChargeableEnergyStoreSubsystem(data->getVoltageDataOfChargeableEnergyStoreSubsystem());

    sampleTemperatureDataOfChargeableEnergyStoreSubsystem(data->getTemperatureDataOfChargeableEnergyStoreSubsystem());
}

void GBTDataPackaging::sampleDefaultVehicleRealtimeDataPackage(std::shared_ptr<VehicleRealtimeDataPackage> data)
{
    sampleDataHeaderPacket(data->getHeader());
    data->getHeader()->setCommandIdentification(REALTIME_REPORT_MESSAGE);

    sampleDefaultRealTimeReportingPacket(data->getRealtimeData());
    data->makeSerializeStruct();
    int dataUnitLength = data->getRealtimeData()->getCurSize();
    data->setDataUnitLength(dataUnitLength);

    data->setCheckCode(0);
}

void GBTDataPackaging::sampleVehicleRealtimeDataPackage(std::shared_ptr<VehicleRealtimeDataPackage> data)
{
    sampleDataHeaderPacket(data->getHeader());
    data->getHeader()->setCommandIdentification(REALTIME_REPORT_MESSAGE);

    sampleRealTimeReportingPacket(data->getRealtimeData());
    data->makeSerializeStruct();
    int dataUnitLength = data->getRealtimeData()->getCurSize();
    data->setDataUnitLength(dataUnitLength);

    data->setCheckCode(0);
}

void GBTDataPackaging::sampleGBTStorageData(std::shared_ptr<GBTStorageData> data)
{
    sampleDataAcquisitionTime(data->getDataAcquisitionTime());

    sampleCompleteVehicleDataPacket(data->getCompleteVehicleData());

    sampleElectricMachineDataPacket(data->getElectricMachineData());

    sampleDataOfEnginePacket(data->getDataOfEngine());

    sampleGPSDataPacket(data->getGpsData());

    sampleLimitValueDataPacket(data->getLimitValueData());

    sampleWarningDataPacket(data->getWarningData());

    uint8_t paralellCellsCount = 1;
    sampleParallelCellsNum(paralellCellsCount);
    data->getCellVoltageData()->setParallelCellsNum(paralellCellsCount);

    sampleStoreVoltageData(data->getCellVoltageData()->getVoltageOfCellList());
    uint16_t totalNumberOfCell = data->getCellVoltageData()->getVoltageOfCellList()->getListSize();
    data->getCellVoltageData()->setTotalNumberOfCell(totalNumberOfCell);

    sampleTemperatureValueOfEachChargeableEnergyStoreSubsystem(data->getTemperatureData()->getTemperatureValueList());
    uint16_t tempProbeCount = data->getTemperatureData()->getTemperatureValueList()->getListSize();
    data->getTemperatureData()->setTempProbeCount(tempProbeCount);
}

void GBTDataPackaging::sampleParallelCellsNum(uint8_t &data)
{
    bool isVolFrameValid = NEVInternalData::GetInstance()->checkAllVoltageFrameValid();
    if(isVolFrameValid)
    {
        data = NEVInternalData::GetInstance()->getHvBattMuxModule(0)->getParallelCellsCount();
    }
    else
    {
        data = 1;
    }
}

void GBTDataPackaging::sampleVehicleLogoutPacket(std::shared_ptr<VehicleLogoutPacket> data)
{
    sampleDataAcquisitionTime(data->getLogoutTime());

    int logoutSN = NEVInternalData::GetInstance()->getLoginSerialNum();
    data->setLogoutSN(logoutSN);
}

void GBTDataPackaging::sampleVehicleLogoutDataPackage(std::shared_ptr<VehicleLogoutDataPackage> data)
{
    sampleDataHeaderPacket(data->getHeader());
    data->getHeader()->setCommandIdentification(LOGOUT_MESSAGE);

    sampleVehicleLogoutPacket(data->getLogoutData());
    data->makeSerializeStruct();
    int dataUnitLength = data->getLogoutData()->getCurSize();
    data->setDataUnitLength(dataUnitLength);

    data->setCheckCode(0);
}

void GBTDataPackaging::sampleVehicleTimingPacket(std::shared_ptr<VehicleTimingPacket> data)
{
    sampleDataAcquisitionTime(data->getGBTTime());
}

void GBTDataPackaging::sampleVehicleTimingDataPackage(std::shared_ptr<VehicleTimingDataPackage> data)
{
    sampleDataHeaderPacket(data->getHeader());
    data->getHeader()->setCommandIdentification(TERMINAL_TIMING);

    sampleVehicleTimingPacket(data->getTimingData());
    data->makeSerializeStruct();
    int dataUnitLength = data->getTimingData()->getCurSize();
    data->setDataUnitLength(dataUnitLength);

    data->setCheckCode(0);
}

void GBTDataPackaging::sampleHeartbeatDataPackage(std::shared_ptr<HeartbeatDataPackage> data)
{
    sampleDataHeaderPacket(data->getHeader());
    data->getHeader()->setCommandIdentification(HEARTBEAT_MESSAGE);

    data->setDataUnitLength(0);

    data->setCheckCode(0);
}

void GBTDataPackaging::sampleCodeOfChargeableEnergyStorageSystem(std::shared_ptr<CodeOfChargeableEnergyStorageSystem> data)
{
    int hvBattCellType = NEVInternalData::GetInstance()->getHvBattCellType();
    data->setHvBattCellType(hvBattCellType);

    int hvBattCompanyCode = NEVInternalData::GetInstance()->getHvBattCompanyCode();
    data->setHvBattCompanyCode(hvBattCompanyCode);

    int hvBattProdDatePart1 = NEVInternalData::GetInstance()->getHvBattProdDatePart1();
    data->setHvBattProdDatePart1(hvBattProdDatePart1);

    int hvBattProdDatePart2 = NEVInternalData::GetInstance()->getHvBattProdDatePart2();
    data->setHvBattProdDatePart2(hvBattProdDatePart2);

    int hvBattProductType = NEVInternalData::GetInstance()->getHvBattProductType();
    data->setHvBattProductType(hvBattProductType);

    int hvBattSerialNumPart1 = NEVInternalData::GetInstance()->getHvBattSerialNumPart1();
    data->setHvBattSerialNumPart1(hvBattSerialNumPart1);

    int hvBattSerialNumPart2 = NEVInternalData::GetInstance()->getHvBattSerialNumPart2();
    data->setHvBattSerialNumPart2(hvBattSerialNumPart2);

    int hvBattTraceInfoCode1 = NEVInternalData::GetInstance()->getHvBattTraceInfoCode1();
    data->setHvBattTraceInfoCode1(hvBattTraceInfoCode1);

    int hvBattTraceInfoCode2 = NEVInternalData::GetInstance()->getHvBattTraceInfoCode2();
    data->setHvBattTraceInfoCode2(hvBattTraceInfoCode2);

    int hvBattTraceInfoCode3 = NEVInternalData::GetInstance()->getHvBattTraceInfoCode3();
    data->setHvBattTraceInfoCode3(hvBattTraceInfoCode3);

    int hvBattTraceInfoCode4 = NEVInternalData::GetInstance()->getHvBattTraceInfoCode4();
    data->setHvBattTraceInfoCode4(hvBattTraceInfoCode4);

    int hvBattTraceInfoCode5 = NEVInternalData::GetInstance()->getHvBattTraceInfoCode5();
    data->setHvBattTraceInfoCode5(hvBattTraceInfoCode5);

    int hvBattTraceInfoCode6 = NEVInternalData::GetInstance()->getHvBattTraceInfoCode6();
    data->setHvBattTraceInfoCode6(hvBattTraceInfoCode6);

    int hvBattTraceInfoCode7 = NEVInternalData::GetInstance()->getHvBattTraceInfoCode7();
    data->setHvBattTraceInfoCode7(hvBattTraceInfoCode7);

    int hvBattTypeCode = NEVInternalData::GetInstance()->getHvBattTypeCode();
    data->setHvBattTypeCode(hvBattTypeCode);
}

void GBTDataPackaging::sampleDefaultCompleteVehicleDataPacket(std::shared_ptr<CompleteVehicleDataPacket> data)
{
    uint8_t vehicleState = 0;
    sampleVehicleState(vehicleState);
    data->setVehicleState(vehicleState);

    uint8_t chargingState = 0;
    sampleChargingState((chargingState));
    data->setChargingState(chargingState);

    uint8_t operationMode = 0;
    sampleOperationMode(operationMode);
    data->setOperationMode(operationMode);

    uint16_t vehicleSpeed = 0;
    sampleVehicleSpeed(vehicleSpeed);
    data->setVehicleSpeed(vehicleSpeed);

    uint32_t accuMileage = 0;
    sampleAccumelatedMilage(accuMileage);
    data->setAccumulatedMileage(accuMileage);

    uint16_t totalVoltage = 0;
    sampleTotalVoltage(totalVoltage);
    data->setTotalVoltage(totalVoltage);

    uint16_t totalCurrent = 0;
    data->setTotalCurrent(totalCurrent);

    uint8_t soc = 0;
    sampleSoc(soc);
    data->setSoc(soc);

    uint8_t dcdcState = 0;
    sampleDcdcState(dcdcState);
    data->setDcdcState(dcdcState);

    uint8_t gearPos = 0;
    sampleGearPosition(gearPos);
    data->setGearPosition(gearPos);

    uint16_t insulationResitance = 0;
    sampleInsulationResistance(insulationResitance);
    data->setInsulationResistance(insulationResitance);

    uint8_t strokeAcceleratorPedal = 0;
    sampleStrokeAcceleratorPedal(strokeAcceleratorPedal);
    data->setStrokeOfAcceratorPedal(strokeAcceleratorPedal);

    uint8_t brakePedalState = 0;
    sampleBrakePedalState(brakePedalState);
    data->setBrakePedalState(brakePedalState);
}

void GBTDataPackaging::sampleCompleteVehicleDataPacket(std::shared_ptr<CompleteVehicleDataPacket> data)
{
    uint8_t vehicleState = 0;
    sampleVehicleState(vehicleState);
    data->setVehicleState(vehicleState);

    uint8_t chargingState = 0;
    sampleChargingState((chargingState));
    data->setChargingState(chargingState);

    uint8_t operationMode = 0;
    sampleOperationMode(operationMode);
    data->setOperationMode(operationMode);

    uint16_t vehicleSpeed = 0;
    sampleVehicleSpeed(vehicleSpeed);
    data->setVehicleSpeed(vehicleSpeed);

    uint32_t accuMileage = 0;
    sampleAccumelatedMilage(accuMileage);
    data->setAccumulatedMileage(accuMileage);

    uint16_t totalVoltage = 0;
    sampleTotalVoltage(totalVoltage);
    data->setTotalVoltage(totalVoltage);

    uint16_t totalCurrent = 0;
    sampleTotalCurrent(totalCurrent);
    data->setTotalCurrent(totalCurrent);

    uint8_t soc = 0;
    sampleSoc(soc);
    data->setSoc(soc);

    uint8_t dcdcState = 0;
    sampleDcdcState(dcdcState);
    data->setDcdcState(dcdcState);

    uint8_t gearPos = 0;
    sampleGearPosition(gearPos);
    data->setGearPosition(gearPos);

    uint16_t insulationResitance = 0;
    sampleInsulationResistance(insulationResitance);
    data->setInsulationResistance(insulationResitance);

    uint8_t strokeAcceleratorPedal = 0;
    sampleStrokeAcceleratorPedal(strokeAcceleratorPedal);
    data->setStrokeOfAcceratorPedal(strokeAcceleratorPedal);

    uint8_t brakePedalState = 0;
    sampleBrakePedalState(brakePedalState);
    data->setBrakePedalState(brakePedalState);
}

void GBTDataPackaging::sampleVehicleState(uint8_t& data)
{
    data = VEHICLE_STATE_SHUTDOWN;
    int powerMode = NEVInternalData::GetInstance()->getCurrentPowerMode();
    if(powerMode >= PM_7_RUNNING)
    {
        data = VEHICLE_STATE_STARTUP;
    }
    else
    {
        data = VEHICLE_STATE_SHUTDOWN;
    }
}

void GBTDataPackaging::sampleChargingState(uint8_t& data)
{
    //check state is charging-parking
    int chargingStatusDisp = NEVInternalData::GetInstance()->getChargingStatusDisp();
    float hvBattCurrentExt = (NEVInternalData::GetInstance()->getHvBattCurrentExt() - TOTAL_CURRENT_OFFSET) * 1.0f / TOTAL_CURRENT_SCALE;
    int hybridMode = NEVInternalData::GetInstance()->getHybridMode();

    if(hvBattCurrentExt < 0x0A)
    {
        if(chargingStatusDisp == 0)
        {
            if(hybridMode == 5)
            {
                data = CHARGING_STATE_UNCHARGED;
            }
            else
            {
                data = CHARGING_STATE_DRIVING;
            }
        }
        else if (chargingStatusDisp == 1)
        {
            data = CHARGING_STATE_COMPLETED;
        }
        else if (chargingStatusDisp == 5)
        {
            data = CHARGING_STATE_ANOMALY;
        }
        else
        {
            data = CHARGING_STATE_PARKING;
        }
    }
    else if (hvBattCurrentExt >= 0x0A)
    {
        if(chargingStatusDisp == 5)
        {
            data = CHARGING_STATE_ANOMALY;
        }
        else
        {
            data = CHARGING_STATE_UNCHARGED;
        }
    }
    else
    {
        data = CHARGING_STATE_INVALID;
    }
}

void GBTDataPackaging::sampleOperationMode(uint8_t &data)
{
    int emOperatingModeExt = NEVInternalData::GetInstance()->getEMOperatingModeExt();
    uint8_t engineState = 0;
    sampleEngineState(engineState);

    int vehicleType = NEVConfigData::GetInstance()->getHybridType();
    if (vehicleType == _PHEV)
    {
        if (engineState == ENGINE_STATE_ON)
        {
            if (emOperatingModeExt == 1)
            {
                data = OPERATION_MODE_HYBRID;
            }
            else
            {
                data = OPERATION_MODE_FUEL;
            }
        }
        else if (engineState == ENGINE_STATE_OFF)
        {
            data = OPERATION_MODE_ALL;
        }
        else if (engineState == ENGINE_STATE_ANOMALY)
        {
            data = OPERATION_MODE_ANOMALY;
        }
        else
        {
            data = OPERATION_MODE_INVALID;
        }
    }
    else if (vehicleType == _BEV)
    {
        data = OPERATION_MODE_ALL;
    }
    else
    {
        data = OPERATION_MODE_INVALID;
    }
}

void GBTDataPackaging::sampleVehicleSpeed(uint16_t& data)
{
    int vehicleSpeed = NEVInternalData::GetInstance()->getVehicleSpeed();
    if(vehicleSpeed >= VEHICLE_SPEED_MIN && vehicleSpeed < VEHICLE_SPEED_MAX)
    {
        data = vehicleSpeed;
    }
    else if(vehicleSpeed >= VEHICLE_SPEED_MAX && vehicleSpeed <= VEHICLE_SPEED_OVER)
    {
        data = VEHICLE_SPEED_MAX;
    }
    else if(vehicleSpeed > VEHICLE_SPEED_OVER)
    {
        data = VEHICLE_SPEED_ANOMALY;
    }
    else
    {
        data = VEHICLE_SPEED_INVALID;
    }
}

void GBTDataPackaging::sampleAccumelatedMilage(uint32_t& data)
{
    long odometerMasterValue = NEVInternalData::GetInstance()->getOdometerMasterValue();
    LOGV("odometerMasterValue: %ld", odometerMasterValue);
    if(odometerMasterValue >= ACCUMELATED_MILAGE_MIN && odometerMasterValue <= ACCUMELATED_MILAGE_MAX)
    {
        data = odometerMasterValue;
    }
    else if(odometerMasterValue > ACCUMELATED_MILAGE_MAX && odometerMasterValue <= ACCUMELATED_MILAGE_OVER)
    {
        data = ACCUMELATED_MILAGE_MAX;
    }
    else
    {
        data = ACCUMULATED_MILEAGE_INVALID;
    }
}

void GBTDataPackaging::sampleTotalVoltage(uint16_t &data)
{
    int hvBattVoltageExt = NEVInternalData::GetInstance()->getHvBattVoltageExt();
    if(hvBattVoltageExt >= TOTAL_VOLTAGE_MIN && hvBattVoltageExt <= TOTAL_VOLTAGE_MAX)
    {
        data = hvBattVoltageExt;
    }
    else if(hvBattVoltageExt > TOTAL_VOLTAGE_MAX)
    {
        data = TOTAL_VOLTAGE_MAX;
    }
    else
    {
        data = TOTAL_VOLTAGE_INVALID;
    }
}

void GBTDataPackaging::sampleTotalCurrent(uint16_t &data)
{
    int hvBattCurrentExt = NEVInternalData::GetInstance()->getHvBattCurrentExt();
    if(hvBattCurrentExt >= TOTAL_CURRENT_MIN && hvBattCurrentExt <= TOTAL_CURRENT_MAX)
    {
        data = hvBattCurrentExt;
    }
    else if(hvBattCurrentExt < TOTAL_CURRENT_MIN)
    {
        data = TOTAL_CURRENT_MIN;
    }
    else
    {
        data = TOTAL_CURRENT_MAX;
    }
}

void GBTDataPackaging::sampleSoc(uint8_t &data)
{
    int hvBatteryUsableSoCDisp = NEVInternalData::GetInstance()->getHvBatteryUsableSoCDisp();
    if(hvBatteryUsableSoCDisp >= SOC_MIN && hvBatteryUsableSoCDisp <= SOC_MAX)
    {
        data = hvBatteryUsableSoCDisp;
    }
    else
    {
        data = SOC_INVALID;
    }
}

void GBTDataPackaging::sampleDcdcState(uint8_t& data)
{
    int dcdcOperatingModeExt = NEVInternalData::GetInstance()->getDCDCOperatingModeExt();
    switch (dcdcOperatingModeExt)
    {
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
    case 6:
        data = DCDC_STATE_IN_OPERATION;
        break;
    case 5:
        data = DCDC_STATE_CUT_OFF;
        break;
    case 7:
        data = DCDC_STATE_ANOMALY;
        break;
    default:
        data = DCDC_STATE_INVALID;
        break;
    }
}

void GBTDataPackaging::sampleGearPosition(uint8_t& data)
{
    int gearPosActual = NEVInternalData::GetInstance()->getGearPosActualExt();
    int brakeSwitchStatus = NEVInternalData::GetInstance()->getBrakeSwitchStatus();
    float pedalPosPro = NEVInternalData::GetInstance()->getPedalPosPro();
    if(gearPosActual >= GEAR_POS_MIN && gearPosActual <= GEAR_POS_MAX)
    {
        data = gearPosActual & 0x0F;
        NEVInternalData::GetInstance()->setGearPosition(data);
    }
    else
    {
        data = NEVInternalData::GetInstance()->getGearPosition();
    }
    uint8_t brakingForceMask = 0x10;
    uint8_t drivingForceMask = 0x20;
    if(brakeSwitchStatus == 1)
    {
        data |= brakingForceMask;//set to bit 4
    }
    if(pedalPosPro > 0)
    {
        data |= drivingForceMask;//set to bit 5
    }
}

void GBTDataPackaging::sampleInsulationResistance(uint16_t &data)
{
    int hvBattIsoRes = NEVInternalData::GetInstance()->getHvBattIsoRes();
    if(hvBattIsoRes >= INSULATION_RESISTANCE_MIN && hvBattIsoRes <= INSULATION_RESISTANCE_MAX)
    {
        data = hvBattIsoRes;
    }
    else if(hvBattIsoRes >= INSULATION_RESISTANCE_MAX)
    {
        data = INSULATION_RESISTANCE_MAX;
    }
    else
    {
        data = INSULATION_RESISTANCE_INVALID;
    }
}

void GBTDataPackaging::sampleStrokeAcceleratorPedal(uint8_t &data)
{
    int pedalPosPro = static_cast<int>(NEVInternalData::GetInstance()->getPedalPosPro());
    if(pedalPosPro >= STROKE_ACCELERATOR_PEDAL_MIN && pedalPosPro <= STROKE_ACCELERATOR_PEDAL_MAX)
    {
        data = pedalPosPro;
    }
    else
    {
        data = STROKE_ACCELERATOR_PEDAL_INVALID;
    }
}

void GBTDataPackaging::sampleBrakePedalState(uint8_t &data)
{
    int brakePressure = NEVInternalData::GetInstance()->getBrakePressure();
    if(brakePressure >= BRAKE_PEDAL_STATE_MIN && brakePressure <= BRAKE_PEDAL_STATE_MAX)
    {
        uint16_t percent = brakePressure;
        data = percent;
    }
    else
    {
        data = STROKE_ACCELERATOR_PEDAL_INVALID;
    }

}

void GBTDataPackaging::sampleDefaultElectricMachineDataPacket(std::shared_ptr<ElectricMachineDataPacket> data)
{
    int vehicleType = NEVConfigData::GetInstance()->getHybridType();
    if(vehicleType == _BEV)
    {
        data->setQuantityOfElectricMachine(2);

        sampleDefaultElectricMachineDataUnitPacketFront(data->getElectricMachineDataUnitPacketF());

        sampleDefaultElectricMachineDataUnitPacketRear(data->getElectricMachineDataUnitPacketR());
    }
    else
    {
        data->setQuantityOfElectricMachine(1);

        sampleDefaultElectricMachineDataUnitPacketRear(data->getElectricMachineDataUnitPacketR());
    }
}

void GBTDataPackaging::sampleElectricMachineDataPacket(std::shared_ptr<ElectricMachineDataPacket> data)
{
    int vehicleType = NEVConfigData::GetInstance()->getHybridType();
    if(vehicleType == _BEV)
    {
        data->setQuantityOfElectricMachine(2);

        sampleElectricMachineDataUnitPacketFront(data->getElectricMachineDataUnitPacketF());

        sampleElectricMachineDataUnitPacketRear(data->getElectricMachineDataUnitPacketR());
    }
    else
    {
        data->setQuantityOfElectricMachine(1);

        sampleElectricMachineDataUnitPacketRear(data->getElectricMachineDataUnitPacketR());
    }
}

void GBTDataPackaging::sampleDefaultElectricMachineDataUnitPacketRear(std::shared_ptr<ElectricMachineDataUnitPacket> data)
{
    uint8_t snOfEM = 0;
    sampleSnOfEMDataRear(snOfEM);
    data->setSnOfElectricalMachine(snOfEM);

    data->setStateOfElectricalMachine(0x03);
    data->setTemperatureOfElectricalMachineController(0xFF);
    data->setSpeedOfElectricalMachine(0xFFFF);
    data->setTorqueOfElectricalMachine(0xFFFF);
    data->setTemperatureOfElectricalMachine(0xFF);
    data->setInputVoltageOfElectricalMachineController(0xFFFF);
    data->setCurrentOfDCbusOfElectricalMachineController(0xFFFF);
}

void GBTDataPackaging::sampleDefaultElectricMachineDataUnitPacketFront(std::shared_ptr<ElectricMachineDataUnitPacket> data)
{
    uint8_t snOfEM = 0;
    sampleSnOfEMDataFront(snOfEM);
    data->setSnOfElectricalMachine(snOfEM);

    data->setStateOfElectricalMachine(0x03);
    data->setTemperatureOfElectricalMachineController(0xFF);
    data->setSpeedOfElectricalMachine(0xFFFF);
    data->setTorqueOfElectricalMachine(0xFFFF);
    data->setTemperatureOfElectricalMachine(0xFF);
    data->setInputVoltageOfElectricalMachineController(0xFFFF);
    data->setCurrentOfDCbusOfElectricalMachineController(0xFFFF);
}

void GBTDataPackaging::sampleElectricMachineDataUnitPacketRear(std::shared_ptr<ElectricMachineDataUnitPacket> data)
{
    uint8_t snOfEM = 0;
    sampleSnOfEMDataRear(snOfEM);
    data->setSnOfElectricalMachine(snOfEM);

    uint8_t stateOfEM = 0;
    sampleStateOfEMDataRear(stateOfEM);
    data->setStateOfElectricalMachine(stateOfEM);

    uint8_t tempOfEMController = 0;
    sampleTempatureOfEMControllerDataRear(tempOfEMController);
    data->setTemperatureOfElectricalMachineController(tempOfEMController);

    uint16_t speedOfEM = 0;
    sampleSpeedOfEMDataRear(speedOfEM);
    data->setSpeedOfElectricalMachine(speedOfEM);

    uint16_t torqueOfEM = 0;
    sampleTorqueOfEMDataRear(torqueOfEM);
    data->setTorqueOfElectricalMachine(torqueOfEM);

    uint8_t tempOfEM = 0;
    sampleTempatureOfEMDataRear(tempOfEM);
    data->setTemperatureOfElectricalMachine(tempOfEM);

    uint16_t inputVolOfEM = 0;
    sampleInputVoltageOfEMDataRear(inputVolOfEM);
    data->setInputVoltageOfElectricalMachineController(inputVolOfEM);

    uint16_t currentDCBusOfEM = 0;
    sampleCurrentDcdcOfEMDataRear(currentDCBusOfEM);
    data->setCurrentOfDCbusOfElectricalMachineController(currentDCBusOfEM);
}

void GBTDataPackaging::sampleElectricMachineDataUnitPacketFront(std::shared_ptr<ElectricMachineDataUnitPacket> data)
{
    if(NEVConfigData::GetInstance()->getHybridType() != _BEV)
    {
        LOGE("Only sample Front data for BEV type.");
        return;
    }
    uint8_t snOfEM = 0;
    sampleSnOfEMDataFront(snOfEM);
    data->setSnOfElectricalMachine(snOfEM);

    uint8_t stateOfEM = 0;
    sampleStateOfEMDataFront(stateOfEM);
    data->setStateOfElectricalMachine(stateOfEM);

    uint8_t tempOfEMController = 0;
    sampleTempatureOfEMControllerDataFront(tempOfEMController);
    data->setTemperatureOfElectricalMachineController(tempOfEMController);

    uint16_t speedOfEM = 0;
    sampleSpeedOfEMDataFront(speedOfEM);
    data->setSpeedOfElectricalMachine(speedOfEM);

    uint16_t torqueOfEM = 0;
    sampleTorqueOfEMDataFront(torqueOfEM);
    data->setTorqueOfElectricalMachine(torqueOfEM);

    uint8_t tempOfEM = 0;
    sampleTempatureOfEMDataFront(tempOfEM);
    data->setTemperatureOfElectricalMachine(tempOfEM);

    uint16_t inputVolOfEM = 0;
    sampleInputVoltageOfEMDataFront(inputVolOfEM);
    data->setInputVoltageOfElectricalMachineController(inputVolOfEM);

    uint16_t currentDCBusOfEM = 0;
    sampleCurrentDcdcOfEMDataFront(currentDCBusOfEM);
    data->setCurrentOfDCbusOfElectricalMachineController(currentDCBusOfEM);
}

void GBTDataPackaging::sampleSnOfEMDataRear(uint8_t &data)
{
    int vehicleType = NEVConfigData::GetInstance()->getHybridType();
    LOGV("vehicleType:%d", vehicleType);
    if(vehicleType == _BEV)
    {
        data = 2;
    }
    else
    {
        data = 1;
    }
}

void GBTDataPackaging::sampleSnOfEMDataFront(uint8_t &data)
{
    data = 1;
}

void GBTDataPackaging::sampleStateOfEMDataRear(uint8_t& data)
{
    uint8_t emOperatingModeExt = NEVInternalData::GetInstance()->getEMOperatingModeExt();
    switch (emOperatingModeExt)
    {
    case 0:
    case 4:
    case 9:
    case 14:
        data = EMSTATE_READINESS;
        break;
    case 1:
        data = EMSTATE_POWER_GENERATION;
        break;
    case 2:
    case 3:
    case 6:
    case 8:
        data = EMSTATE_POWER_CONSUMPTION;
        break;
    case 5:
    case 7:
        data = EMSTATE_DEACTIVATION_STATE;
        break;
    case 13:
    case 15:
        data = EMSTATE_ANOMALY;
        break;
    default:
        data = EMSTATE_INVALID;
        break;
    }
}

void GBTDataPackaging::sampleStateOfEMDataFront(uint8_t& data)
{
    int emOperatingModeF = NEVInternalData::GetInstance()->getEMOperatingModeF();
    switch (emOperatingModeF)
    {
    case 0:
    case 4:
    case 9:
    case 14:
        data = EMSTATE_READINESS;
        break;
    case 1:
        data = EMSTATE_POWER_GENERATION;
        break;
    case 2:
    case 3:
    case 6:
    case 8:
        data = EMSTATE_POWER_CONSUMPTION;
        break;
    case 5:
    case 7:
        data = EMSTATE_DEACTIVATION_STATE;
        break;
    case 13:
    case 15:
        data = EMSTATE_ANOMALY;
        break;
    default:
        data = EMSTATE_INVALID;
        break;
    }
}

void GBTDataPackaging::sampleTempatureOfEMControllerDataRear(uint8_t& data)
{
    int emControllerTemperature = NEVInternalData::GetInstance()->getInverterIGBTTemp();
    if(emControllerTemperature >= TEMP_EM_CONTROLLER_MIN && emControllerTemperature <= TEMP_EM_CONTROLLER_MAX)
    {
        data = emControllerTemperature;
    }
    else if(emControllerTemperature > TEMP_EM_CONTROLLER_MAX)
    {
        data = TEMP_EM_CONTROLLER_MAX;
    }
    else
    {
        data = TEMP_EM_INVALID;
    }
}

void GBTDataPackaging::sampleTempatureOfEMControllerDataFront(uint8_t& data)
{
    int emControllerTemperatureF = NEVInternalData::GetInstance()->getInverterIGBTTempF();
    if(emControllerTemperatureF >= TEMP_EM_CONTROLLER_MIN && emControllerTemperatureF <= TEMP_EM_CONTROLLER_MAX)
    {
        data = emControllerTemperatureF;
    }
    else if(emControllerTemperatureF > TEMP_EM_CONTROLLER_MAX)
    {
        data = TEMP_EM_CONTROLLER_MAX;
    }
    else
    {
        data = TEMP_EM_INVALID;
    }
}

void GBTDataPackaging::sampleSpeedOfEMDataRear(uint16_t& data)
{
    int emSpeedR = NEVInternalData::GetInstance()->getEmSpeedR();
    if(emSpeedR >= EM_SPEED_MIN && emSpeedR <= EM_SPEED_MAX)
    {
        data = emSpeedR;
    }
    else if(emSpeedR == EM_SPEED_FAIL)
    {
        data = SPEED_EM_ANOMALY;
    }
    else
    {
        data = SPEED_EM_INVALID;
    }
}

void GBTDataPackaging::sampleSpeedOfEMDataFront(uint16_t& data)
{
    int emSpeedF = NEVInternalData::GetInstance()->getEmSpeedF();
    if(emSpeedF >= EM_SPEED_MIN && emSpeedF <= EM_SPEED_MAX)
    {
        data = emSpeedF;
    }
    else if(emSpeedF == EM_SPEED_FAIL)
    {
        data = SPEED_EM_ANOMALY;
    }
    else
    {
        data = SPEED_EM_INVALID;
    }
}

void GBTDataPackaging::sampleTorqueOfEMDataRear(uint16_t& data)
{
    int emTorqueR = NEVInternalData::GetInstance()->getEmTorqueR();
    if(emTorqueR >= EM_TORQUE_MIN && emTorqueR <= EM_TORQUE_MAX)
    {
        data = emTorqueR;
    }
    else
    {
        data = TORQUE_EM_INVALID;
    }
}

void GBTDataPackaging::sampleTorqueOfEMDataFront(uint16_t& data)
{
    int emTorqueF = NEVInternalData::GetInstance()->getEmTorqueF();
    if(emTorqueF >= EM_TORQUE_MIN && emTorqueF <= EM_TORQUE_MAX)
    {
        data = emTorqueF;
    }
    else
    {
        data = TORQUE_EM_INVALID;
    }
}

void GBTDataPackaging::sampleTempatureOfEMDataRear(uint8_t& data)
{
    int emTemperature = NEVInternalData::GetInstance()->getEmTemperature();
    if(emTemperature >= TEMP_EM_MIN && emTemperature <= TEMP_EM_MAX)
    {
        data = emTemperature;
    }
    else if(emTemperature > TEMP_EM_MAX && emTemperature <= TEMP_EM_OVER)
    {
        data = TEMP_EM_MAX;
    }
    else if(emTemperature == TEMP_EM_FAIL)
    {
        data = TEMP_EM_ANOMALY;
    }
    else
    {
        data = TEMP_EM_INVALID;
    }
}

void GBTDataPackaging::sampleTempatureOfEMDataFront(uint8_t& data)
{
    int emTemperatureF = NEVInternalData::GetInstance()->getEmTemperatureF();
    if(emTemperatureF >= TEMP_EM_MIN && emTemperatureF <= TEMP_EM_MAX)
    {
        data = emTemperatureF;
    }
    else if(emTemperatureF > TEMP_EM_MAX && emTemperatureF <= TEMP_EM_OVER)
    {
        data = TEMP_EM_MAX;
    }
    else if(emTemperatureF == TEMP_EM_FAIL)
    {
        data = TEMP_EM_ANOMALY;
    }
    else
    {
        data = TEMP_EM_INVALID;
    }
}

void GBTDataPackaging::sampleInputVoltageOfEMDataRear(uint16_t &data)
{
    int emVoltageDCLinkExt = NEVInternalData::GetInstance()->getEmVoltageDCLinkExt();
    if(emVoltageDCLinkExt >= INPUT_VOLTAGE_EM_MIN && emVoltageDCLinkExt <= INPUT_VOLTAGE_EM_MAX)
    {
        data = emVoltageDCLinkExt;
    }
    else
    {
        data = INPUT_VOLTAGE_EM_INVALID;
    }
}

void GBTDataPackaging::sampleInputVoltageOfEMDataFront(uint16_t &data)
{
    int emVoltageDCLinkF = NEVInternalData::GetInstance()->getEmVoltageDCLinkF();
    if(emVoltageDCLinkF >= INPUT_VOLTAGE_EM_MIN && emVoltageDCLinkF <= INPUT_VOLTAGE_EM_MAX)
    {
        data = emVoltageDCLinkF;
    }
    else
    {
        data = INPUT_VOLTAGE_EM_INVALID;
    }
}

void GBTDataPackaging::sampleCurrentDcdcOfEMDataRear(uint16_t& data)
{
    int emCurrentDCLinkR = NEVInternalData::GetInstance()->getEmCurrentDCLinkR();
    if(emCurrentDCLinkR >= EM_CURRENT_DC_LINK_MIN && emCurrentDCLinkR <= EM_CURRENT_DC_LINK_MAX)
    {
        data = emCurrentDCLinkR;
    }
    else
    {
        data = CURRENT_DC_EM_CONTROLLER_INVALID;
    }
}

void GBTDataPackaging::sampleCurrentDcdcOfEMDataFront(uint16_t& data)
{
    int emCurrentDCLinkF = NEVInternalData::GetInstance()->getEmCurrentDCLinkF();
    if(emCurrentDCLinkF >= EM_CURRENT_DC_LINK_MIN && emCurrentDCLinkF <= EM_CURRENT_DC_LINK_MAX)
    {
        data = emCurrentDCLinkF;
    }
    else
    {
        data = CURRENT_DC_EM_CONTROLLER_INVALID;
    }
}

void GBTDataPackaging::sampleFuelCellDataPacket(std::shared_ptr<FuelCellDataPacket> data)
{
    data->setVoltageOfFuelCell(0xFFFF);
    data->setCurrentOfFuelCell(0xFFFF);

    data->setFuelConsumption(0xFFFF);

    data->setTotalNumberOfFuelCellTemperatureProbes(0);

    data->setMaxTemperatureInHydrogenSystem(0xFFFF);

    data->setCodeOfProbeWithMaxTempInHydrogenSystem(0xFF);

    data->setMaxConcentrationInHydrogen(0xFFFF);

    data->setCodeOfSensorWithMaxConcentrationOfHydrogen(0xFF);

    data->setMaxPressureOfHydrogen(0xFFFF);

    data->setCodeOfSensorWithTheMaxPressureOfHydrogen(0xFF);

    data->setHighPressureDCDCState(0xFF);
}

void GBTDataPackaging::sampleDefaultDataOfEnginePacket(std::shared_ptr<DataOfEnginePacket> data)
{
    data->setEngineState(0x02);
    data->setCrankshaftSpeed(0);
    data->setFuelConsumption(0);
}

void GBTDataPackaging::sampleDataOfEnginePacket(std::shared_ptr<DataOfEnginePacket> data)
{
    uint8_t engineState = 0;
    sampleEngineState(engineState);
    data->setEngineState(engineState);

    uint16_t crankSpeed = 0;
    sampleCrankShaftSpeed(crankSpeed);
    data->setCrankshaftSpeed(crankSpeed);

    uint16_t fuelConsumption = 0;
    sampleFuelConsumtion(fuelConsumption);
    data->setFuelConsumption(fuelConsumption);
}

void GBTDataPackaging::sampleEngineState(uint8_t &data)
{
    int powerPackStatus = NEVInternalData::GetInstance()->getPowerPackStatus();
    int vehicleType = NEVConfigData::GetInstance()->getHybridType();
    if(vehicleType == _PHEV)
    {
        switch (powerPackStatus) {
        case 0:
        case 1:
        case 2:
        case 3:
        case 4:
        case 6:
        case 9:
            data = ENGINE_STATE_OFF;
            break;
        case 5:
        case 7:
        case 8:
            data = ENGINE_STATE_ON;
            break;
        default:
            data = ENGINE_STATE_INVALID;
            break;
        }
    }
    else
    {
        data = ENGINE_STATE_INVALID;
    }
}

void GBTDataPackaging::sampleCrankShaftSpeed(uint16_t &data)
{
    int engineSpeed = NEVInternalData::GetInstance()->getEngineSpeed();
    int vehicleType = NEVConfigData::GetInstance()->getHybridType();
    if(vehicleType == _PHEV)
    {
        if(engineSpeed >= CRANKSHAFT_SPEED_MIN && engineSpeed <= CRANKSHAFT_SPEED_MAX)
        {
            data = engineSpeed;
        }
        else
        {
            data = CRANKSHAFT_SPEED_INVALID;
        }
    }
    else
    {
        data = CRANKSHAFT_SPEED_INVALID;
    }
}

void GBTDataPackaging::sampleFuelConsumtion(uint16_t &data)
{
    int vehicleType = NEVConfigData::GetInstance()->getHybridType();
    if(vehicleType == _PHEV)
    {
        std::shared_ptr<EcoDataMuxLiveBlock12> ecoData = NEVInternalData::GetInstance()->getEcoData();
        float tripCurrFuelEconomyPHEV = ecoData->getTripCurrFuelEconomyPHEV() / 10.0f;
        int fuelConsumption = 0;
        if(ecoData->getFuelEconomyUnits() == 0)
        {
            float l100kmValue = GBTUtil::convertMilePerGallonToLitrePer100Km(tripCurrFuelEconomyPHEV);
            fuelConsumption = static_cast<int>(std::round(l100kmValue * FUEL_CONSUMPTION_SCALE));
        }

        if(ecoData->getFuelEconomyUnits() == 1)
        {
            float l100kmValue = GBTUtil::convertMilePerLitreToLitrePer100Km(tripCurrFuelEconomyPHEV);
            fuelConsumption = static_cast<int>(std::round(l100kmValue * FUEL_CONSUMPTION_SCALE));
        }

        if(ecoData->getFuelEconomyUnits() == 2)
        {
            float l100kmValue = GBTUtil::convertKmPerLitreToLitrePer100Km(tripCurrFuelEconomyPHEV);
            fuelConsumption = static_cast<int>(std::round(l100kmValue * FUEL_CONSUMPTION_SCALE));
        }

        if(ecoData->getFuelEconomyUnits() == 3)
        {
            fuelConsumption = static_cast<int>(std::round(tripCurrFuelEconomyPHEV * FUEL_CONSUMPTION_SCALE));
        }

        if(ecoData->getFuelEconomyUnits() == 0 || ecoData->getFuelEconomyUnits() == 1 || ecoData->getFuelEconomyUnits() == 2 || ecoData->getFuelEconomyUnits() == 3)
        {
            if(fuelConsumption >= FUEL_CONSUMPTION_MIN && fuelConsumption <= FUEL_CONSUMPTION_MAX)
            {
                data = fuelConsumption;
            }
            else
            {
                data = FUEL_CONSUMPTION_INVALID;
            }
        }
        else
        {
            data = FUEL_CONSUMPTION_INVALID;
        }
    }
    else
    {
        data = FUEL_CONSUMPTION_INVALID;
    }
}

void GBTDataPackaging::sampleDefaultGPSDataPacket(std::shared_ptr<GPSDataPacket> data)
{
    data->setPositioningState(0);

    uint32_t longitude = 0;
    sampleLongitude(longitude);
    data->setLongitude(longitude);

    uint32_t latitude = 0;
    sampleLatitude(latitude);
    data->setLatitude(latitude);
}

void GBTDataPackaging::sampleGPSDataPacket(std::shared_ptr<GPSDataPacket> data)
{
    uint8_t positionState = 0;
    samplePositionState(positionState);
    data->setPositioningState(positionState);

    uint32_t longitude = 0;
    sampleLongitude(longitude);
    data->setLongitude(longitude);

    uint32_t latitude = 0;
    sampleLatitude(latitude);
    data->setLatitude(latitude);
}

void GBTDataPackaging::samplePositionState(uint8_t &data)
{
    bool gpsState = NEVInternalData::GetInstance()->getGpsStatus();
    uint8_t validPosMask = 0;
    if(gpsState == 1)
    {
        validPosMask = 0x00;
    }
    else
    {
        validPosMask = 0x01;
    }

    uint8_t latitudeMask = 0;
    int32_t latitude = NEVInternalData::GetInstance()->getLatitude();
    if(latitude >= 0)
    {
        latitudeMask = 0;
    }
    else
    {
        latitudeMask = 0x02;
    }

    uint8_t longitudeMask = 0;
    int32_t longitude = NEVInternalData::GetInstance()->getLongitude();
    if(longitude >= 0)
    {
        longitudeMask = 0;
    }
    else
    {
        longitudeMask = 0x04;
    }

    data = validPosMask | latitudeMask | longitudeMask;
}

void GBTDataPackaging::sampleLongitude(uint32_t &data)
{
    data = std::abs(NEVInternalData::GetInstance()->getLongitude());
}

void GBTDataPackaging::sampleLatitude(uint32_t &data)
{
    data = std::abs(NEVInternalData::GetInstance()->getLatitude());
}

void GBTDataPackaging::sampleParameterId(std::shared_ptr<ParameterItem> data)
{
    LOGV("%s ", __FUNCTION__);
    uint8_t id = data->getParameterID();
    LOGV("%s ParameterId = %d", __FUNCTION__, id);
    switch (id)
    {
    case 0x01:
    {
        data->setWordTypeField(NEVSystemProperty::GetInstance()->getIntValueById(NEVSystemProperty::GetInstance()->getConfigId(0x01)));
        break;
    }
    case 0x02:
    {
        data->setWordTypeField(NEVSystemProperty::GetInstance()->getIntValueById(NEVSystemProperty::GetInstance()->getConfigId(0x02)));
        break;
    }
    case 0x03:
    {
        data->setWordTypeField(NEVSystemProperty::GetInstance()->getIntValueById(NEVSystemProperty::GetInstance()->getConfigId(0x03)));
        break;
    }
    case 0x04:
    {
        data->setByteTypeField(NEVSystemProperty::GetInstance()->getIntValueById(NEVSystemProperty::GetInstance()->getConfigId(0x04)));
        break;
    }
    case 0x05:
    {
        data->setByteArrayField(NEVSystemProperty::GetInstance()->getStringValueById(NEVSystemProperty::GetInstance()->getConfigId(0x05)));
        break;
    }
    case 0x06:
    {
        data->setWordTypeField(NEVSystemProperty::GetInstance()->getIntValueById(NEVSystemProperty::GetInstance()->getConfigId(0x06)));
        break;
    }
    case 0x07:
    {
        data->setByteArrayField(NEVSystemProperty::GetInstance()->getStringValueById(NEVSystemProperty::GetInstance()->getConfigId(0x07)));
        break;
    }
    case 0x08:
    {
        data->setByteArrayField(NEVSystemProperty::GetInstance()->getStringValueById(NEVSystemProperty::GetInstance()->getConfigId(0x08)));
        break;
    }
    case 0x09:
    {
        data->setByteTypeField(NEVSystemProperty::GetInstance()->getIntValueById(NEVSystemProperty::GetInstance()->getConfigId(0x09)));
        break;
    }
    case 0x0A:
    {
        data->setWordTypeField(NEVSystemProperty::GetInstance()->getIntValueById(NEVSystemProperty::GetInstance()->getConfigId(0x0A)));
        break;
    }
    case 0x0B:
    {
        data->setWordTypeField(NEVSystemProperty::GetInstance()->getIntValueById(NEVSystemProperty::GetInstance()->getConfigId(0x0B)));
        break;
    }
    case 0x0C:
    {
        data->setByteTypeField(NEVSystemProperty::GetInstance()->getIntValueById(NEVSystemProperty::GetInstance()->getConfigId(0x0C)));
        break;
    }
    case 0x0D:
    {
        data->setByteTypeField(NEVSystemProperty::GetInstance()->getIntValueById(NEVSystemProperty::GetInstance()->getConfigId(0x0D)));
        break;
    }
    case 0x0E:
    {
        data->setByteArrayField(NEVSystemProperty::GetInstance()->getStringValueById(NEVSystemProperty::GetInstance()->getConfigId(0x0E)));
        break;
    }
    case 0x0F:
    {
        data->setWordTypeField(NEVSystemProperty::GetInstance()->getIntValueById(NEVSystemProperty::GetInstance()->getConfigId(0x0F)));
        break;
    }
    case 0x10:
    {
        data->setByteTypeField(NEVSystemProperty::GetInstance()->getIntValueById(NEVSystemProperty::GetInstance()->getConfigId(0x10)));
        break;
    }
    default:
        break;
    }
}

void GBTDataPackaging::sampleDefaultLimitValueDataPacket(std::shared_ptr<LimitValueDataPacket> data)
{
    data->setIdNoOfBatterySubsystemWithMaxVoltage(0xFF);
    data->setIdNoOfCellWithMaxVoltage(0xFF);
    data->setMaxCellVoltage(0xFFFF);
    data->setIdNoOfBatterySubsystemWithMinVoltage(0xFF);
    data->setIdNoOfCellWithMinVoltage(0xFF);
    data->setMinCellVoltage(0xFFFF);
    data->setIdNoOfSubsystemWithMaxTemperature(0xFF);
    data->setCodeOfSingleProbeWithMaxTemperature(0xFF);
    data->setMaxTemperatureValue(0xFF);
    data->setIdNoOfSubsystemWithMinTemperature(0xFF);
    data->setCodeOfProbeSubsystemWithMinTemperature(0xFF);
    data->setMinTemperatureValue(0xFF);
}

void GBTDataPackaging::sampleLimitValueDataPacket(std::shared_ptr<LimitValueDataPacket> data)
{
    LimitVoltageInfo volInfo = getLimitVoltageInfo();
    LimitTempInfo tempInfo = getLimitTempInfo();

    data->setIdNoOfBatterySubsystemWithMaxVoltage(volInfo.maxModuleId);
    data->setIdNoOfCellWithMaxVoltage(volInfo.maxCellId);
    data->setMaxCellVoltage(volInfo.maxVoltage);

    data->setIdNoOfBatterySubsystemWithMinVoltage(volInfo.minModuleId);
    data->setIdNoOfCellWithMinVoltage(volInfo.minCellId);
    data->setMinCellVoltage(volInfo.minVoltage);

    data->setIdNoOfSubsystemWithMaxTemperature(tempInfo.maxModuleId);
    data->setCodeOfSingleProbeWithMaxTemperature(tempInfo.maxCellId);
    data->setMaxTemperatureValue(tempInfo.maxTemp);

    data->setIdNoOfSubsystemWithMinTemperature(tempInfo.minModuleId);
    data->setCodeOfProbeSubsystemWithMinTemperature(tempInfo.minCellId);
    data->setMinTemperatureValue(tempInfo.minTemp);
}

GBTDataPackaging::LimitVoltageInfo GBTDataPackaging::getLimitVoltageInfo()
{
    LimitVoltageInfo info;

    bool isVolFrameValid = NEVInternalData::GetInstance()->checkAllVoltageFrameValid();
    if(isVolFrameValid)
    {
        int hvBattModuleCount = NEVInternalData::GetInstance()->getHvBattModuleCount();
        int maxVoltage = 0;
        int minVoltage = CELL_VOLTAGE_INVALID;

        for(int moduleId = 1; moduleId <= hvBattModuleCount; moduleId++)
        {
            std::shared_ptr<HVBattMuxModule> module = NEVInternalData::GetInstance()->getHvBattMuxModule(moduleId - 1);

            int seriesCellsCount = module->getSeriesCellsCount();
            int cellFrameCount = module->getCellFrameCount();

            for(int frameId = 1; frameId <= cellFrameCount; frameId++)
            {
                std::shared_ptr<HVBattMuxCellVoltage> cellVoltage = NEVInternalData::GetInstance()->getHvBattMuxCellVoltage(moduleId, frameId);
                for(int idx = 1; idx <= 3; idx++)
                {
                    int cellId = (frameId - 1) * 3 + idx;
                    if(cellId <= seriesCellsCount)
                    {
                        int voltage = cellVoltage->getCellVoltage(idx);
                        if(voltage == CELL_VOLTAGE_INVALID)
                        {
                            info.maxModuleId = ID_NO_BATTERY_SUBSYSTEM_VOLTAGE_INVALID;
                            info.maxCellId = ID_NO_CELL_VOLTAGE_INVALID;
                            info.maxVoltage = CELL_VOLTAGE_INVALID;

                            info.minModuleId = ID_NO_BATTERY_SUBSYSTEM_VOLTAGE_INVALID;
                            info.minCellId = ID_NO_CELL_VOLTAGE_INVALID;
                            info.minVoltage = CELL_VOLTAGE_INVALID;
                            return info;
                        }
                        if(voltage > maxVoltage)
                        {
                            maxVoltage = voltage;
                            info.maxModuleId = module->getModuleId();
                            info.maxCellId = (cellId - 1) * module->getParallelCellsCount() + 1;
                            info.maxVoltage = maxVoltage;
                        }

                        if(voltage < minVoltage)
                        {
                            minVoltage = voltage;
                            info.minModuleId = module->getModuleId();
                            info.minCellId = (cellId - 1) * module->getParallelCellsCount() + 1;
                            info.minVoltage = minVoltage;
                        }
                    }
                }
            }
        }
    }
    else
    {
        info.maxModuleId = ID_NO_BATTERY_SUBSYSTEM_VOLTAGE_INVALID;
        info.maxCellId = ID_NO_CELL_VOLTAGE_INVALID;
        info.maxVoltage = CELL_VOLTAGE_INVALID;

        info.minModuleId = ID_NO_BATTERY_SUBSYSTEM_VOLTAGE_INVALID;
        info.minCellId = ID_NO_CELL_VOLTAGE_INVALID;
        info.minVoltage = CELL_VOLTAGE_INVALID;
    }

    return info;
}

GBTDataPackaging::LimitTempInfo GBTDataPackaging::getLimitTempInfo()
{
    LimitTempInfo info;

    bool isTempValid = NEVInternalData::GetInstance()->checkAllTemperatureFrameValid();
    if(isTempValid)
    {
        int hvBattModuleCount = NEVInternalData::GetInstance()->getHvBattModuleCount();
        int maxTemperature = 0;
        int minTemperature = TEMP_INVALID;

        for(int moduleId = 1; moduleId <= hvBattModuleCount; moduleId++)
        {
            std::shared_ptr<HVBattMuxModule> module = NEVInternalData::GetInstance()->getHvBattMuxModule(moduleId - 1);

            int probeCount = module->getProbeCount();
            int probeFrameCount = module->getProbeFrameCount();

            for(int frameId = 1; frameId <= probeFrameCount; frameId++)
            {
                std::shared_ptr<HVBattMuxTempProbe> tempProbe = NEVInternalData::GetInstance()->getHvBattMuxTempProbe(moduleId, frameId);
                for(int idx = 1; idx <= 6; idx++)
                {
                    int probeId = (frameId - 1) * 6 + idx;
                    if(probeId <= probeCount)
                    {
                        int temperature = tempProbe->getProbeTemp(idx);
                        if(temperature == TEMP_INVALID)
                        {
                            info.maxModuleId = ID_NO_SUBSYSTEM_TEMP_INVALID;
                            info.maxCellId = CODE_SINGLE_PROBE_TEMP_INVALID;
                            info.maxTemp = TEMP_INVALID;
                            info.minModuleId = ID_NO_SUBSYSTEM_TEMP_INVALID;
                            info.minCellId = CODE_SINGLE_PROBE_TEMP_INVALID;
                            info.minTemp = TEMP_INVALID;
                            return info;
                        }
                        if(temperature > maxTemperature)
                        {
                            maxTemperature = temperature;
                            info.maxModuleId = module->getModuleId();
                            info.maxCellId = probeId;
                            info.maxTemp = maxTemperature;
                        }

                        if(temperature < minTemperature)
                        {
                            minTemperature = temperature;
                            info.minModuleId = module->getModuleId();
                            info.minCellId = probeId;
                            info.minTemp = minTemperature;
                        }
                    }
                }
            }
        }
    }
    else
    {
        info.maxModuleId = ID_NO_SUBSYSTEM_TEMP_INVALID;
        info.maxCellId = CODE_SINGLE_PROBE_TEMP_INVALID;
        info.maxTemp = TEMP_INVALID;
        info.minModuleId = ID_NO_SUBSYSTEM_TEMP_INVALID;
        info.minCellId = CODE_SINGLE_PROBE_TEMP_INVALID;
        info.minTemp = TEMP_INVALID;
    }

    return info;
}

void GBTDataPackaging::sampleDefaultWarningDataPacket(std::shared_ptr<WarningDataPacket> data)
{
    sampleWarningDataPacket(data);
}

void GBTDataPackaging::sampleWarningDataPacket(std::shared_ptr<WarningDataPacket> data)
{
    uint32_t generalWarningMark = 0;
    sampleGeneralWarningMark(generalWarningMark);
    data->setGeneralWarningMark(generalWarningMark);

    uint8_t highestWarningLevel = 0;
    sampleHighestWarningLevel(highestWarningLevel);
    data->setHighestWarningLevel(highestWarningLevel);

    sampleListOfCodesOfChargeableEnergyStorageDeviceFaults(data->getListOfCodesOfChargeableEnergyStorageDeviceFaults()->getListOfFaults());

    uint8_t numberOfChargeableEnergyStorageDeviceFault = data->getListOfCodesOfChargeableEnergyStorageDeviceFaults()->getListOfFaults()->getListSize();
    data->getListOfCodesOfChargeableEnergyStorageDeviceFaults()->setNumberOfFaults(numberOfChargeableEnergyStorageDeviceFault);

    sampleListOfCodesOfElectricalMachineFaults(data->getListOfCodesOfElectricalMachineFaults()->getListOfFaults());

    uint8_t totalNumberOfElectricalMachineFaults = data->getListOfCodesOfElectricalMachineFaults()->getListOfFaults()->getListSize();
    data->getListOfCodesOfElectricalMachineFaults()->setNumberOfFaults(totalNumberOfElectricalMachineFaults);

    sampleListOfEngineFaults(data->getListOfEngineFaults()->getListOfFaults());

    uint8_t totalNumberOfEngineFaults = data->getListOfEngineFaults()->getListOfFaults()->getListSize();
    data->getListOfEngineFaults()->setNumberOfFaults(totalNumberOfEngineFaults);

    sampleListOfCodesOfOtherFaults(data->getListOfCodesOfOtherFaults()->getListOfFaults());

    uint8_t totalNumberOfOtherFaults = data->getListOfCodesOfOtherFaults()->getListOfFaults()->getListSize();
    data->getListOfCodesOfOtherFaults()->setNumberOfFaults(totalNumberOfOtherFaults);
}

void GBTDataPackaging::sampleHighestWarningLevel(uint8_t &data)
{
    int warningLevel = NEVInternalData::GetInstance()->getWarningLevel();
    data = warningLevel;
}

void GBTDataPackaging::sampleGeneralWarningMark(uint32_t &data)
{
    data = 0;
    int highestLevel = 0;
    int hvBattTempDiffWarning = NEVInternalData::GetInstance()->getHvBattTempDiffWarning();
    if(hvBattTempDiffWarning == 1)
    {
        if(highestLevel < 1)
        {
            highestLevel = 1;
        }
        data |= ((uint32_t)1);
    }

    int hvBattHighTempWarning = NEVInternalData::GetInstance()->getHvBattHighTempWarning();
    if(hvBattHighTempWarning == 1)
    {
        if(highestLevel < 1)
        {
            highestLevel = 1;
        }
        data |= ((uint32_t)1 << 1);
    }

    int hvBattOverVoltage  = NEVInternalData::GetInstance()->getHvBattOverVoltage();
    if(hvBattOverVoltage == 1)
    {
        if(highestLevel < 1)
        {
            highestLevel = 1;
        }
        data |= ((uint32_t)1 << 2);
    }

    int hvBattUnderVoltage   = NEVInternalData::GetInstance()->getHvBattUnderVoltage();
    if(hvBattUnderVoltage == 1)
    {
        if(highestLevel < 1)
        {
            highestLevel = 1;
        }
        data |= ((uint32_t)1 << 3);
    }

    int hvBattLowSOCWarning   = NEVInternalData::GetInstance()->getHvBattLowSOCWarning();
    if(hvBattLowSOCWarning == 1)
    {
        if(highestLevel < 1)
        {
            highestLevel = 1;
        }
        data |= ((uint32_t)1 << 4);
    }

    int hvBattCellOverVoltage   = NEVInternalData::GetInstance()->getHvBattCellOverVoltage();
    if(hvBattCellOverVoltage == 1)
    {
        if(highestLevel < 1)
        {
            highestLevel = 1;
        }
        data |= ((uint32_t)1 << 5);
    }

    int hvBattCellUnderVoltage   = NEVInternalData::GetInstance()->getHvBattCellUnderVoltage();
    if(hvBattCellUnderVoltage == 1)
    {
        if(highestLevel < 1)
        {
            highestLevel = 1;
        }
        data |= ((uint32_t)1 << 6);
    }

    int hvBattHighSOCWarning   = NEVInternalData::GetInstance()->getHvBattHighSOCWarning();
    if(hvBattHighSOCWarning == 1)
    {
        if(highestLevel < 1)
        {
            highestLevel = 1;
        }
        data |= ((uint32_t)1 << 7);
    }

    int hvBattSOCJumpWarning   = NEVInternalData::GetInstance()->getHvBattSOCJumpWarning();
    if(hvBattSOCJumpWarning == 1)
    {
        if(highestLevel < 1)
        {
            highestLevel = 1;
        }
        data |= ((uint32_t)1 << 8);
    }

    int hvBattCompCheck   = NEVInternalData::GetInstance()->getHvBattCompCheck();
    if(hvBattCompCheck == 1)
    {
        if(highestLevel < 1)
        {
            highestLevel = 1;
        }
        data |= ((uint32_t)1 << 9);
    }

    int hvBattCellVoltClcWarn   = NEVInternalData::GetInstance()->getHvBattCellVoltClcWarn();
    if(hvBattCellVoltClcWarn == 1)
    {
        if(highestLevel < 1)
        {
            highestLevel = 1;
        }
        data |= ((uint32_t)1 << 10);
    }

    int hvBattIsolationStatus2   = NEVInternalData::GetInstance()->getHvBattIsolationStatus2();
    if(hvBattIsolationStatus2 == 1)
    {
        if(highestLevel < 3)
        {
            highestLevel = 3;
        }
        data |= ((uint32_t)1 << 11);
    }

    int dcdcTemperatureDerate   = NEVInternalData::GetInstance()->getDcdcTemperatureDerate();
    if(dcdcTemperatureDerate == 1)
    {
        if(highestLevel < 1)
        {
            highestLevel = 1;
        }
        data |= ((uint32_t)1 << 12);
    }

    int brakeWarningLamp   = NEVInternalData::GetInstance()->getBrakeWarningLamp();
    if(brakeWarningLamp == 1 || brakeWarningLamp == 3)
    {
        if(highestLevel < 3)
        {
            highestLevel = 3;
        }
        data |= ((uint32_t)1 << 13);
    }

    int powerSupplyStatus   = NEVInternalData::GetInstance()->getPowerSupplyStatus();
    if(powerSupplyStatus == 0)
    {
        if(highestLevel < 1)
        {
            highestLevel = 1;
        }
        data |= ((uint32_t)1 << 14);
    }

    int vehicleType = NEVConfigData::GetInstance()->getHybridType();
    if(vehicleType == _PHEV)
    {
        int inverterIGBTTemp   = NEVInternalData::GetInstance()->getInverterIGBTTemp();
        if(inverterIGBTTemp == 255)
        {
            if(highestLevel < 2)
            {
                highestLevel = 2;
            }
            data |= ((uint32_t)1 << 15);
        }
    }
    if(vehicleType == _BEV)
    {
        int inverterIGBTTemp   = NEVInternalData::GetInstance()->getInverterIGBTTemp();
        int inverterIGBTTempF   = NEVInternalData::GetInstance()->getInverterIGBTTempF();
        if(inverterIGBTTemp == 255 || inverterIGBTTempF == 255)
        {
            if(highestLevel < 2)
            {
                highestLevel = 2;
            }
            data |= ((uint32_t)1 << 15);
        }
    }

    int hvBattHVILStatus   = NEVInternalData::GetInstance()->getHvBattHVILStatus();
    int hvBattOCMonitorStatus   = NEVInternalData::GetInstance()->getHvBattOCMonitorStatus();
    if(hvBattHVILStatus == 1 || hvBattOCMonitorStatus == 2)
    {
        if(highestLevel < 3)
        {
            highestLevel = 3;
        }
        data |= ((uint32_t)1 << 16);
    }

    if(vehicleType == _PHEV)
    {
        int emTemperature   = NEVInternalData::GetInstance()->getEmTemperature();
        if(emTemperature == 511)
        {
            if(highestLevel < 2)
            {
                highestLevel = 2;
            }
            data |= ((uint32_t)1 << 17);
        }
    }
    if(vehicleType == _BEV)
    {
        int emTemperature   = NEVInternalData::GetInstance()->getEmTemperature();
        int emTemperatureF   = NEVInternalData::GetInstance()->getEmTemperatureF();
        if(emTemperature == 511 || emTemperatureF == 511)
        {
            if(highestLevel < 2)
            {
                highestLevel = 2;
            }
            data |= ((uint32_t)1 << 17);
        }
    }

    int hvBattOvercharge   = NEVInternalData::GetInstance()->getHvBattOvercharge();
    if(hvBattOvercharge == 1)
    {
        if(highestLevel < 1)
        {
            highestLevel = 1;
        }
        data |= ((uint32_t)1 << 18);
    }

    NEVInternalData::GetInstance()->setWarningLevel(highestLevel);
}

void GBTDataPackaging::sampleNumberOfChargeableEnergyStorageDeviceFault(uint8_t &data)
{
}

void GBTDataPackaging::sampleListOfCodesOfChargeableEnergyStorageDeviceFaults(std::shared_ptr<ListOfFaultData> data)
{
    std::shared_ptr<DWORD_GBT> item;
    int hvBattTempDiffWarning = NEVInternalData::GetInstance()->getHvBattTempDiffWarning();
    if(hvBattTempDiffWarning == 1)
    {
        item = std::make_shared<DWORD_GBT>();
        *item = 0x0000E00A;
        data->prepend(item);
    }

    int hvBattHighTempWarning = NEVInternalData::GetInstance()->getHvBattHighTempWarning();
    if(hvBattHighTempWarning == 1)
    {
        item = std::make_shared<DWORD_GBT>();
        *item = 0x0000E01A;
        data->prepend(item);
    }

    int hvBattOverVoltage  = NEVInternalData::GetInstance()->getHvBattOverVoltage();
    if(hvBattOverVoltage == 1)
    {
        item = std::make_shared<DWORD_GBT>();
        *item = 0x0000E02A;
        data->prepend(item);
    }

    int hvBattUnderVoltage   = NEVInternalData::GetInstance()->getHvBattUnderVoltage();
    if(hvBattUnderVoltage == 1)
    {
        item = std::make_shared<DWORD_GBT>();
        *item = 0x0000E03A;
        data->prepend(item);
    }

    int hvBattLowSOCWarning   = NEVInternalData::GetInstance()->getHvBattLowSOCWarning();
    if(hvBattLowSOCWarning == 1)
    {
        item = std::make_shared<DWORD_GBT>();
        *item = 0x0000E04A;
        data->prepend(item);
    }

    int hvBattCellOverVoltage   = NEVInternalData::GetInstance()->getHvBattCellOverVoltage();
    if(hvBattCellOverVoltage == 1)
    {
        item = std::make_shared<DWORD_GBT>();
        *item = 0x0000E05A;
        data->prepend(item);
    }

    int hvBattCellUnderVoltage   = NEVInternalData::GetInstance()->getHvBattCellUnderVoltage();
    if(hvBattCellUnderVoltage == 1)
    {
        item = std::make_shared<DWORD_GBT>();
        *item = 0x0000E06A;
        data->prepend(item);
    }

    int hvBattHighSOCWarning   = NEVInternalData::GetInstance()->getHvBattHighSOCWarning();
    if(hvBattHighSOCWarning == 1)
    {
        item = std::make_shared<DWORD_GBT>();
        *item = 0x0000E07A;
        data->prepend(item);
    }

    int hvBattSOCJumpWarning   = NEVInternalData::GetInstance()->getHvBattSOCJumpWarning();
    if(hvBattSOCJumpWarning == 1)
    {
        item = std::make_shared<DWORD_GBT>();
        *item = 0x0000E08A;
        data->prepend(item);
    }

    int hvBattCompCheck   = NEVInternalData::GetInstance()->getHvBattCompCheck();
    if(hvBattCompCheck == 1)
    {
        item = std::make_shared<DWORD_GBT>();
        *item = 0x0000E09A;
        data->prepend(item);
    }

    int hvBattCellVoltClcWarn   = NEVInternalData::GetInstance()->getHvBattCellVoltClcWarn();
    if(hvBattCellVoltClcWarn == 1)
    {
        item = std::make_shared<DWORD_GBT>();
        *item = 0x0000E0AA;
        data->prepend(item);
    }

    int hvBattIsolationStatus2   = NEVInternalData::GetInstance()->getHvBattIsolationStatus2();
    if(hvBattIsolationStatus2 == 1)
    {
        item = std::make_shared<DWORD_GBT>();
        *item = 0x0000E0BA;
        data->prepend(item);
    }

    int hvBattHVILStatus   = NEVInternalData::GetInstance()->getHvBattHVILStatus();
    int hvBattOCMonitorStatus   = NEVInternalData::GetInstance()->getHvBattOCMonitorStatus();
    if(hvBattHVILStatus == 1 || hvBattOCMonitorStatus == 2)
    {
        item = std::make_shared<DWORD_GBT>();
        *item = 0x0000E10A;
        data->prepend(item);
    }

    int hvBattOvercharge   = NEVInternalData::GetInstance()->getHvBattOvercharge();
    if(hvBattOvercharge == 1)
    {
        item = std::make_shared<DWORD_GBT>();
        *item = 0x0000E12A;
        data->prepend(item);
    }
}

void GBTDataPackaging::sampleTotalNumberOfElectricalMachineFaults(uint8_t &data)
{
}

void GBTDataPackaging::sampleListOfCodesOfElectricalMachineFaults(std::shared_ptr<ListOfFaultData> data)
{
    std::shared_ptr<DWORD_GBT> item;
    int dcdcTemperatureDerate   = NEVInternalData::GetInstance()->getDcdcTemperatureDerate();
    if(dcdcTemperatureDerate == 1)
    {
        item = std::make_shared<DWORD_GBT>();
        *item = 0x0000E0CA;
        data->prepend(item);
    }

    int powerSupplyStatus   = NEVInternalData::GetInstance()->getPowerSupplyStatus();
    if(powerSupplyStatus == 0)
    {
        item = std::make_shared<DWORD_GBT>();
        *item = 0x0000E0EA;
        data->prepend(item);
    }

    int inverterIGBTTemp   = NEVInternalData::GetInstance()->getInverterIGBTTemp();
    int inverterIGBTTempF   = NEVInternalData::GetInstance()->getInverterIGBTTempF();
    if(inverterIGBTTemp == 255 && inverterIGBTTempF == 255)
    {
        item = std::make_shared<DWORD_GBT>();
        *item = 0x0000E0FA;
        data->prepend(item);
    }
    else if(inverterIGBTTemp == 255)
    {
        item = std::make_shared<DWORD_GBT>();
        *item = 0x0000E0FB;
        data->prepend(item);
    }
    else if(inverterIGBTTempF == 255)
    {
        item = std::make_shared<DWORD_GBT>();
        *item = 0x0000E0FC;
        data->prepend(item);
    }
    else
    {
        ;
    }

    int emTemperature   = NEVInternalData::GetInstance()->getEmTemperature();
    int emTemperatureF   = NEVInternalData::GetInstance()->getEmTemperatureF();
    if(emTemperature == 511 && emTemperatureF == 511)
    {
        item = std::make_shared<DWORD_GBT>();
        *item = 0x0000E11A;
        data->prepend(item);
    }
    else if(emTemperature == 511)
    {
        item = std::make_shared<DWORD_GBT>();
        *item = 0x0000E11B;
        data->prepend(item);
    }
    else if(emTemperatureF == 511)
    {
        item = std::make_shared<DWORD_GBT>();
        *item = 0x0000E11C;
        data->prepend(item);
    }
    else
    {
        ;
    }
}

void GBTDataPackaging::sampleTotalNumberOfEngineFaults(uint8_t &data)
{
}

void GBTDataPackaging::sampleListOfEngineFaults(std::shared_ptr<ListOfFaultData> data)
{
    ;
}

void GBTDataPackaging::sampleTotalNumberOfOtherFaults(uint8_t &data)
{
}

void GBTDataPackaging::sampleListOfCodesOfOtherFaults(std::shared_ptr<ListOfFaultData> data)
{
    std::shared_ptr<DWORD_GBT> item;
    int brakeWarningLamp   = NEVInternalData::GetInstance()->getBrakeWarningLamp();
    if(brakeWarningLamp == 1 || brakeWarningLamp == 3)
    {
        item = std::make_shared<DWORD_GBT>();
        *item = 0x0000E0DA;
        data->prepend(item);
    }
}

void GBTDataPackaging::sampleDefaultVoltageDataOfChargeableEnergyStoreSubsystem(std::shared_ptr<VoltageDataOfChargeableEnergyStoreSubsystem> data)
{
    sampleDefaultListOfVoltageInformationOfChargeableEnergyStoreSubsystem(data->getListOfVoltageInformationOfChargeableEnergyStoreSubsystem());

    data->setQuantityOfChargeableEnergyStoreSubsystem(data->getListOfVoltageInformationOfChargeableEnergyStoreSubsystem()->getListSize());
}

void GBTDataPackaging::sampleVoltageDataOfChargeableEnergyStoreSubsystem(std::shared_ptr<VoltageDataOfChargeableEnergyStoreSubsystem> data)
{
    sampleListOfVoltageInformationOfChargeableEnergyStoreSubsystem(data->getListOfVoltageInformationOfChargeableEnergyStoreSubsystem());

    data->setQuantityOfChargeableEnergyStoreSubsystem(data->getListOfVoltageInformationOfChargeableEnergyStoreSubsystem()->getListSize());
}

void GBTDataPackaging::sampleDefaultListOfVoltageInformationOfChargeableEnergyStoreSubsystem(std::shared_ptr<ListOfVoltageInformationOfChargeableEnergyStoreSubsystem> data)
{
    std::shared_ptr<VoltageOfCellList> voltageOfCell = std::make_shared<VoltageOfCellList>();
    sampleDefaultVoltageOfCell(voltageOfCell);
    uint16_t totalNumberOfCell = voltageOfCell->getListSize();

    int listCount = (totalNumberOfCell - 1) / 200 + 1;
    data->setListSize(listCount);
    int snOfBattery = 1;
    for(int i = 0; i < listCount; i++)
    {
        std::shared_ptr<VoltageInformationOfChargeableEnergyStoreSubsystem> item = data->getItem(i);
        item->setCodeOfChargeableEnergyStoreSubsystem(i + 1);

        uint16_t voltageOfChargeableEnergyStorageDevice = 0;
        sampleVoltageOfChargeableEnergyStorageDevice(voltageOfChargeableEnergyStorageDevice);
        item->setVoltageOfChargeableEnergyStorageDevice(voltageOfChargeableEnergyStorageDevice);

        uint16_t currentOfChargeableEnergyStorageDevice = 0;
        sampleCurrentOfChargeableEnergyStorageDevice(currentOfChargeableEnergyStorageDevice);
        item->setCurrentOfChargeableEnergyStorageDevice(currentOfChargeableEnergyStorageDevice);

        item->setTotalNumberOfCell(totalNumberOfCell);

        item->setSnOfStartingBatteryOfThisFrame(snOfBattery);
        snOfBattery += 200;

        uint8_t totalCellNumberOfThisFrame = 0;
        if(i < listCount - 1)
        {
            totalCellNumberOfThisFrame = 200;
        }
        else
        {
            totalCellNumberOfThisFrame = totalNumberOfCell - (listCount - 1) * 200;
        }
        item->setTotalCellNumberOfThisFrame(totalCellNumberOfThisFrame);

        std::shared_ptr<VoltageOfCellList> voltageOfCellOfThisFrame = item->getVoltageOfCell();
        for(int j = 0; j < totalCellNumberOfThisFrame; j++)
        {
            int cellIdx = i * 200 + j;
            voltageOfCellOfThisFrame->prepend(voltageOfCell->getItem(cellIdx));
        }
    }
}

void GBTDataPackaging::sampleListOfVoltageInformationOfChargeableEnergyStoreSubsystem(std::shared_ptr<ListOfVoltageInformationOfChargeableEnergyStoreSubsystem> data)
{
    std::shared_ptr<VoltageOfCellList> voltageOfCell = std::make_shared<VoltageOfCellList>();
    sampleVoltageOfCell(voltageOfCell);
    uint16_t totalNumberOfCell = voltageOfCell->getListSize();
    LOGV("totalNumberOfCell:%d", totalNumberOfCell);

    int listCount = (totalNumberOfCell - 1) / 200 + 1;
    data->setListSize(listCount);
    int snOfBattery = 1;
    for(int i = 0; i < listCount; i++)
    {
        std::shared_ptr<VoltageInformationOfChargeableEnergyStoreSubsystem> item = data->getItem(i);
        item->setCodeOfChargeableEnergyStoreSubsystem(i + 1);

        uint16_t voltageOfChargeableEnergyStorageDevice = 0;
        sampleVoltageOfChargeableEnergyStorageDevice(voltageOfChargeableEnergyStorageDevice);
        item->setVoltageOfChargeableEnergyStorageDevice(voltageOfChargeableEnergyStorageDevice);

        uint16_t currentOfChargeableEnergyStorageDevice = 0;
        sampleCurrentOfChargeableEnergyStorageDevice(currentOfChargeableEnergyStorageDevice);
        item->setCurrentOfChargeableEnergyStorageDevice(currentOfChargeableEnergyStorageDevice);

        item->setTotalNumberOfCell(totalNumberOfCell);

        item->setSnOfStartingBatteryOfThisFrame(snOfBattery);
        snOfBattery += 200;

        uint8_t totalCellNumberOfThisFrame = 0;
        if(i < listCount - 1)
        {
            totalCellNumberOfThisFrame = 200;
        }
        else
        {
            totalCellNumberOfThisFrame = totalNumberOfCell - (listCount - 1) * 200;
        }
        item->setTotalCellNumberOfThisFrame(totalCellNumberOfThisFrame);

        std::shared_ptr<VoltageOfCellList> voltageOfCellOfThisFrame = item->getVoltageOfCell();
        for(int j = 0; j < totalCellNumberOfThisFrame; j++)
        {
            int cellIdx = i * 200 + j;
            voltageOfCellOfThisFrame->prepend(voltageOfCell->getItem(cellIdx));
        }
    }
}

void GBTDataPackaging::sampleVoltageOfChargeableEnergyStorageDevice(uint16_t &data)
{
    sampleTotalVoltage(data);
}

void GBTDataPackaging::sampleCurrentOfChargeableEnergyStorageDevice(uint16_t &data)
{
    sampleTotalCurrent(data);
}

void GBTDataPackaging::sampleTotalNumberOfCell(uint16_t &data)
{
    //HVBattModuleCount, HVBattMuxModule
    int hvBattModuleCount = NEVInternalData::GetInstance()->getHvBattModuleCount();
    int totalNumberOfCell = 0;
    for(int moduleId = 1; moduleId <= hvBattModuleCount; moduleId++)
    {
        int cellCount = NEVInternalData::GetInstance()->getHvBattMuxModule(moduleId - 1)->getSeriesCellsCount() * NEVInternalData::GetInstance()->getHvBattMuxModule(moduleId - 1)->getParallelCellsCount();
        totalNumberOfCell += cellCount;
    }
    if(totalNumberOfCell != 0)
    {
        data = totalNumberOfCell;
    }
    else
    {
        data = TOTAL_NUMBER_CELL_INVALID;
    }
}

void GBTDataPackaging::sampleDefaultVoltageOfCell(std::shared_ptr<VoltageOfCellList> data)
{
    int hvBattModuleCount = NEVInternalData::GetInstance()->getHvBattModuleCount();

    bool isVolFrameValid = NEVInternalData::GetInstance()->checkAllVoltageFrameValid();
    if(isVolFrameValid)
    {
        for(int moduleId = 1; moduleId <= hvBattModuleCount; moduleId++)
        {
            std::shared_ptr<HVBattMuxModule> module = NEVInternalData::GetInstance()->getHvBattMuxModule(moduleId - 1);

            int cellCount = module->getSeriesCellsCount() * module->getParallelCellsCount();
            std::shared_ptr<WORD_GBT> item = std::make_shared<WORD_GBT>();
            *item = 0xFFFF;

            for(int i = 1; i <= cellCount; i++)
            {
                data->prepend(item);
            }
        }
    }
    else
    {
        std::shared_ptr<WORD_GBT> item = std::make_shared<WORD_GBT>();
        *item = 0xFFFF;
        data->prepend(item);
    }
}

void GBTDataPackaging::sampleVoltageOfCell(std::shared_ptr<VoltageOfCellList> data)
{
    int hvBattModuleCount = NEVInternalData::GetInstance()->getHvBattModuleCount();

    bool isVolFrameValid = NEVInternalData::GetInstance()->checkAllVoltageFrameValid();
    if(isVolFrameValid)
    {
        for(int moduleId = 1; moduleId <= hvBattModuleCount; moduleId++)
        {
            std::shared_ptr<HVBattMuxModule> module = NEVInternalData::GetInstance()->getHvBattMuxModule(moduleId - 1);

            int seriesCellCount = module->getSeriesCellsCount();
            int cellFrameCount = module->getCellFrameCount();

            for(int frameId = 1; frameId <= cellFrameCount; frameId++)
            {
                std::shared_ptr<HVBattMuxCellVoltage> cellVoltage = NEVInternalData::GetInstance()->getHvBattMuxCellVoltage(moduleId, frameId);
                for(int idx = 1; idx <= 3; idx++)
                {
                    int cellId = (frameId - 1) * 3 + idx;
                    if(cellId <= seriesCellCount)
                    {
                        int voltage = cellVoltage->getCellVoltage(idx);
                        std::shared_ptr<WORD_GBT> item = std::make_shared<WORD_GBT>();
                        *item = voltage;

                        int paralellCellsCount = module->getParallelCellsCount();
                        for(int i = 0; i < paralellCellsCount; i++)
                        {
                            data->prepend(item);
                        }
                    }
                }
            }
        }
    }
    else
    {
        std::shared_ptr<WORD_GBT> item = std::make_shared<WORD_GBT>();
        *item = 0xFFFF;
        data->prepend(item);
    }
}

void GBTDataPackaging::sampleStoreVoltageData(std::shared_ptr<VoltageOfCellList> data)
{
    int hvBattModuleCount = NEVInternalData::GetInstance()->getHvBattModuleCount();

    bool isVolFrameValid = NEVInternalData::GetInstance()->checkAllVoltageFrameValid();
    if(isVolFrameValid)
    {
        for(int moduleId = 1; moduleId <= hvBattModuleCount; moduleId++)
        {
            std::shared_ptr<HVBattMuxModule> module = NEVInternalData::GetInstance()->getHvBattMuxModule(moduleId - 1);

            int seriesCellCount = module->getSeriesCellsCount();
            int cellFrameCount = module->getCellFrameCount();

            for(int frameId = 1; frameId <= cellFrameCount; frameId++)
            {
                std::shared_ptr<HVBattMuxCellVoltage> cellVoltage = NEVInternalData::GetInstance()->getHvBattMuxCellVoltage(moduleId, frameId);
                for(int idx = 1; idx <= 3; idx++)
                {
                    int cellId = (frameId - 1) * 3 + idx;
                    if(cellId <= seriesCellCount)
                    {
                        int voltage = cellVoltage->getCellVoltage(idx);
                        std::shared_ptr<WORD_GBT> item = std::make_shared<WORD_GBT>();
                        *item = voltage;

                        data->prepend(item);
                    }
                }
            }
        }
    }
    else
    {
        std::shared_ptr<WORD_GBT> item = std::make_shared<WORD_GBT>();
        *item = 0xFFFF;
        data->prepend(item);
    }
}

void GBTDataPackaging::sampleDefaultTemperatureDataOfChargeableEnergyStoreSubsystem(std::shared_ptr<TemperatureDataOfChargeableEnergyStoreSubsystem> data)
{
    data->setQuantityOfChargeableEnergyStoreSubsystem(1);

    std::shared_ptr<TemperatureInformationOfChargeableEnergyStoreSubsystem> item = std::make_shared<TemperatureInformationOfChargeableEnergyStoreSubsystem>();
    sampleDefaultTemperatureInformationOfChargeableEnergyStoreSubsystem(item);
    data->getListOfTemperatureInformationOfChargeableEnergyStoreSubsystem()->prepend(item);
}

void GBTDataPackaging::sampleTemperatureDataOfChargeableEnergyStoreSubsystem(std::shared_ptr<TemperatureDataOfChargeableEnergyStoreSubsystem> data)
{
    data->setQuantityOfChargeableEnergyStoreSubsystem(1);

    std::shared_ptr<TemperatureInformationOfChargeableEnergyStoreSubsystem> item = std::make_shared<TemperatureInformationOfChargeableEnergyStoreSubsystem>();
    sampleTemperatureInformationOfChargeableEnergyStoreSubsystem(item);
    data->getListOfTemperatureInformationOfChargeableEnergyStoreSubsystem()->prepend(item);
}

void GBTDataPackaging::sampleDefaultTemperatureInformationOfChargeableEnergyStoreSubsystem(std::shared_ptr<TemperatureInformationOfChargeableEnergyStoreSubsystem> data)
{
    data->setCodeOfChargeableEnergyStoreSubsystem(1);

    sampleDefaultTemperatureValueOfEachChargeableEnergyStoreSubsystem(data->getTemperatureValueOfEachChargeableEnergyStoreSubsystem());

    data->setQuantityOfChargeableEnergyStoreSubsystem(data->getTemperatureValueOfEachChargeableEnergyStoreSubsystem()->getListSize());
}

void GBTDataPackaging::sampleTemperatureInformationOfChargeableEnergyStoreSubsystem(std::shared_ptr<TemperatureInformationOfChargeableEnergyStoreSubsystem> data)
{
    data->setCodeOfChargeableEnergyStoreSubsystem(1);

    sampleTemperatureValueOfEachChargeableEnergyStoreSubsystem(data->getTemperatureValueOfEachChargeableEnergyStoreSubsystem());

    data->setQuantityOfChargeableEnergyStoreSubsystem(data->getTemperatureValueOfEachChargeableEnergyStoreSubsystem()->getListSize());
}

void GBTDataPackaging::sampleDefaultTemperatureValueOfEachChargeableEnergyStoreSubsystem(std::shared_ptr<TemperatureValueList> data)
{
    int hvBattModuleCount = NEVInternalData::GetInstance()->getHvBattModuleCount();

    bool isTempValid = NEVInternalData::GetInstance()->checkAllTemperatureFrameValid();
    if(isTempValid)
    {
        for(int moduleId = 1; moduleId <= hvBattModuleCount; moduleId++)
        {
            std::shared_ptr<HVBattMuxModule> module = NEVInternalData::GetInstance()->getHvBattMuxModule(moduleId - 1);

            int probeCount = module->getProbeCount();

            for(int idx = 1; idx <= probeCount; idx++)
            {
                std::shared_ptr<BYTE_GBT> item = std::make_shared<BYTE_GBT>();
                *item = 0xFF;
                data->prepend(item);
            }
        }
    }
    else
    {
        std::shared_ptr<BYTE_GBT> item = std::make_shared<BYTE_GBT>();
        *item = 0xFF;
        data->prepend(item);
    }
}

void GBTDataPackaging::sampleTemperatureValueOfEachChargeableEnergyStoreSubsystem(std::shared_ptr<TemperatureValueList> data)
{
    int hvBattModuleCount = NEVInternalData::GetInstance()->getHvBattModuleCount();

    bool isTempValid = NEVInternalData::GetInstance()->checkAllTemperatureFrameValid();
    if(isTempValid)
    {
        for(int moduleId = 1; moduleId <= hvBattModuleCount; moduleId++)
        {
            std::shared_ptr<HVBattMuxModule> module = NEVInternalData::GetInstance()->getHvBattMuxModule(moduleId - 1);

            int probeCount = module->getProbeCount();
            int probeFrameCount = module->getProbeFrameCount();

            for(int frameId = 1; frameId <= probeFrameCount; frameId++)
            {
                std::shared_ptr<HVBattMuxTempProbe> tempProbe = NEVInternalData::GetInstance()->getHvBattMuxTempProbe(moduleId, frameId);
                for(int idx = 1; idx <= 6; idx++)
                {
                    int probeId = (frameId - 1) * 6 + idx;
                    if(probeId <= probeCount)
                    {
                        int temperature = tempProbe->getProbeTemp(idx);
                        std::shared_ptr<BYTE_GBT> item = std::make_shared<BYTE_GBT>();
                        *item = temperature;
                        data->prepend(item);
                    }
                }
            }
        }
    }
    else
    {
        std::shared_ptr<BYTE_GBT> item = std::make_shared<BYTE_GBT>();
        *item = 0xFF;
        data->prepend(item);
    }
}

void GBTDataPackaging::sampleQueryUplinkDataPackage(std::shared_ptr<ParameterQueryUplinkDataPackage> dataUplink, std::shared_ptr<GBTListOfItem<BYTE_GBT>> listOfItems)
{
    sampleDataHeaderPacket(dataUplink->getHeader());
    dataUplink->getHeader()->setCommandIdentification(QUERY_MESSAGE);

    sampleQueryUplinkPackage(dataUplink->getParameterQueryData(), listOfItems);
    dataUplink->makeSerializeStruct();
    int dataUnitLength = dataUplink->getParameterQueryData()->getCurSize();
    dataUplink->setDataUnitLength(dataUnitLength);

    dataUplink->setCheckCode(0);
}

void GBTDataPackaging::sampleQueryUplinkPackage(std::shared_ptr<ParameterQueryUplinkPackage> dataUplink, std::shared_ptr<GBTListOfItem<BYTE_GBT>> listOfItems)
{
    sampleDataAcquisitionTime(dataUplink->getReturnTimeOfParameterQuery());
    sampleQueryResponse(dataUplink->getListOfParameterItem(), listOfItems);
    dataUplink->setTotalNumberOfReturnParameter(dataUplink->getListOfParameterItem()->getListSize());
}

void GBTDataPackaging::sampleQueryResponse(std::shared_ptr<ListOfParameterItem> listOfResponseParameter, std::shared_ptr<GBTListOfItem<BYTE_GBT>> listOfItems)
{
    for (int i = 0; i < listOfItems->getListSize(); i++)
    {
        std::shared_ptr<ParameterItem> responseItem = std::make_shared<ParameterItem>();
        std::shared_ptr<BYTE_GBT> item = listOfItems->getItem(i);
        uint8_t value = *item;
        responseItem->setParameterID(value);
        sampleParameterId(responseItem);
        listOfResponseParameter->prepend(responseItem);
    }
}

GBTDataPackaging::LimitVoltageInfo::LimitVoltageInfo()
{
    maxModuleId = ID_NO_BATTERY_SUBSYSTEM_VOLTAGE_INVALID;
    maxCellId = ID_NO_CELL_VOLTAGE_INVALID;
    maxVoltage = CELL_VOLTAGE_INVALID;
    minModuleId = ID_NO_BATTERY_SUBSYSTEM_VOLTAGE_INVALID;
    minCellId = ID_NO_CELL_VOLTAGE_INVALID;
    minVoltage = CELL_VOLTAGE_INVALID;
}

GBTDataPackaging::LimitTempInfo::LimitTempInfo()
{
    maxModuleId = ID_NO_SUBSYSTEM_TEMP_INVALID;
    maxCellId = CODE_SINGLE_PROBE_TEMP_INVALID;
    maxTemp = TEMP_INVALID;
    minModuleId = ID_NO_SUBSYSTEM_TEMP_INVALID;
    minCellId = CODE_SINGLE_PROBE_TEMP_INVALID;
    minTemp = TEMP_INVALID;
}
