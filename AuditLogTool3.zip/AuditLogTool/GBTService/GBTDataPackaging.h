#ifndef GBTDATAPACKAGING_H
#define GBTDATAPACKAGING_H
#include "GBTTransportData.h"
#include "GBTStorageData.h"

class GBTDataPackaging
{
public:
    void sampleDataAcquisitionTime(std::shared_ptr<ChinaTimePacket> dataAcquisitionTime);
    void sampleVehicleLoginPacket(std::shared_ptr<VehicleLoginPacket> data);
    void sampleDataHeaderPacket(std::shared_ptr<DataHeaderPacket> data);
    void sampleVehicleLoginDataPackage(std::shared_ptr<VehicleLoginDataPackage> data);

    void sampleDefaultRealTimeReportingPacket(std::shared_ptr<RealTimeReportingPacket> data);
    void sampleRealTimeReportingPacket(std::shared_ptr<RealTimeReportingPacket> data);
    void sampleDefaultVehicleRealtimeDataPackage(std::shared_ptr<VehicleRealtimeDataPackage> data);
    void sampleVehicleRealtimeDataPackage(std::shared_ptr<VehicleRealtimeDataPackage> data);

    void sampleGBTStorageData(std::shared_ptr<GBTStorageData> data);
    void sampleParallelCellsNum(uint8_t& data);

    void sampleVehicleLogoutPacket(std::shared_ptr<VehicleLogoutPacket> data);
    void sampleVehicleLogoutDataPackage(std::shared_ptr<VehicleLogoutDataPackage> data);

    void sampleVehicleTimingPacket(std::shared_ptr<VehicleTimingPacket> data);
    void sampleVehicleTimingDataPackage(std::shared_ptr<VehicleTimingDataPackage> data);

    void sampleHeartbeatDataPackage(std::shared_ptr<HeartbeatDataPackage> data);

    void sampleCodeOfChargeableEnergyStorageSystem(std::shared_ptr<CodeOfChargeableEnergyStorageSystem> data);

    void sampleDefaultCompleteVehicleDataPacket(std::shared_ptr<CompleteVehicleDataPacket> data);
    void sampleCompleteVehicleDataPacket(std::shared_ptr<CompleteVehicleDataPacket> data);
    void sampleVehicleState(uint8_t& data);
    void sampleChargingState(uint8_t& data);
    void sampleOperationMode(uint8_t& data);
    void sampleVehicleSpeed(uint16_t& data);
    void sampleAccumelatedMilage(uint32_t& data);
    void sampleTotalVoltage(uint16_t& data);
    void sampleTotalCurrent(uint16_t& data);
    void sampleSoc(uint8_t& data);
    void sampleDcdcState(uint8_t& data);
    void sampleGearPosition(uint8_t& data);
    void sampleInsulationResistance(uint16_t& data);
    void sampleStrokeAcceleratorPedal(uint8_t& data);
    void sampleBrakePedalState(uint8_t& data);

    void sampleDefaultElectricMachineDataPacket(std::shared_ptr<ElectricMachineDataPacket> data);
    void sampleElectricMachineDataPacket(std::shared_ptr<ElectricMachineDataPacket> data);
    void sampleDefaultElectricMachineDataUnitPacketRear(std::shared_ptr<ElectricMachineDataUnitPacket> data);
    void sampleDefaultElectricMachineDataUnitPacketFront(std::shared_ptr<ElectricMachineDataUnitPacket> data);
    void sampleElectricMachineDataUnitPacketRear(std::shared_ptr<ElectricMachineDataUnitPacket> data);
    void sampleElectricMachineDataUnitPacketFront(std::shared_ptr<ElectricMachineDataUnitPacket> data);
    void sampleSnOfEMDataRear(uint8_t& data);
    void sampleSnOfEMDataFront(uint8_t& data);
    void sampleStateOfEMDataRear(uint8_t& data);
    void sampleStateOfEMDataFront(uint8_t& data);
    void sampleTempatureOfEMControllerDataRear(uint8_t& data);
    void sampleTempatureOfEMControllerDataFront(uint8_t& data);
    void sampleSpeedOfEMDataRear(uint16_t& data);
    void sampleSpeedOfEMDataFront(uint16_t& data);
    void sampleTorqueOfEMDataRear(uint16_t& data);
    void sampleTorqueOfEMDataFront(uint16_t& data);
    void sampleTempatureOfEMDataRear(uint8_t& data);
    void sampleTempatureOfEMDataFront(uint8_t& data);
    void sampleInputVoltageOfEMDataRear(uint16_t& data);
    void sampleInputVoltageOfEMDataFront(uint16_t& data);
    void sampleCurrentDcdcOfEMDataRear(uint16_t& data);
    void sampleCurrentDcdcOfEMDataFront(uint16_t& data);

    void sampleFuelCellDataPacket(std::shared_ptr<FuelCellDataPacket> data);

    void sampleDefaultDataOfEnginePacket(std::shared_ptr<DataOfEnginePacket> data);
    void sampleDataOfEnginePacket(std::shared_ptr<DataOfEnginePacket> data);
    void sampleEngineState(uint8_t& data);
    void sampleCrankShaftSpeed(uint16_t &data);
    void sampleFuelConsumtion(uint16_t &data);

    void sampleDefaultGPSDataPacket(std::shared_ptr<GPSDataPacket> data);
    void sampleGPSDataPacket(std::shared_ptr<GPSDataPacket> data);
    void samplePositionState(uint8_t &data);
    void sampleLongitude(uint32_t &data);
    void sampleLatitude(uint32_t &data);

    void sampleParameterId(std::shared_ptr<ParameterItem> data);


    struct LimitVoltageInfo
    {
        LimitVoltageInfo();
        int maxModuleId;
        int maxCellId;
        int maxVoltage;
        int minModuleId;
        int minCellId;
        int minVoltage;
    };

    struct LimitTempInfo
    {
        LimitTempInfo();
        int maxModuleId;
        int maxCellId;
        int maxTemp;
        int minModuleId;
        int minCellId;
        int minTemp;
    };

    void sampleDefaultLimitValueDataPacket(std::shared_ptr<LimitValueDataPacket> data);
    void sampleLimitValueDataPacket(std::shared_ptr<LimitValueDataPacket> data);
    LimitVoltageInfo getLimitVoltageInfo();
    LimitTempInfo getLimitTempInfo();

    void sampleDefaultWarningDataPacket(std::shared_ptr<WarningDataPacket> data);
    void sampleWarningDataPacket(std::shared_ptr<WarningDataPacket> data);
    void sampleHighestWarningLevel(uint8_t &data);
    void sampleGeneralWarningMark(uint32_t &data);
    void sampleNumberOfChargeableEnergyStorageDeviceFault(uint8_t &data);
    void sampleListOfCodesOfChargeableEnergyStorageDeviceFaults(std::shared_ptr<ListOfFaultData> data);
    void sampleTotalNumberOfElectricalMachineFaults(uint8_t &data);
    void sampleListOfCodesOfElectricalMachineFaults(std::shared_ptr<ListOfFaultData> data);
    void sampleTotalNumberOfEngineFaults(uint8_t &data);
    void sampleListOfEngineFaults(std::shared_ptr<ListOfFaultData> data);
    void sampleTotalNumberOfOtherFaults(uint8_t &data);
    void sampleListOfCodesOfOtherFaults(std::shared_ptr<ListOfFaultData> data);

    void sampleDefaultVoltageDataOfChargeableEnergyStoreSubsystem(std::shared_ptr<VoltageDataOfChargeableEnergyStoreSubsystem> data);
    void sampleVoltageDataOfChargeableEnergyStoreSubsystem(std::shared_ptr<VoltageDataOfChargeableEnergyStoreSubsystem> data);
    void sampleDefaultListOfVoltageInformationOfChargeableEnergyStoreSubsystem(std::shared_ptr<ListOfVoltageInformationOfChargeableEnergyStoreSubsystem> data);
    void sampleListOfVoltageInformationOfChargeableEnergyStoreSubsystem(std::shared_ptr<ListOfVoltageInformationOfChargeableEnergyStoreSubsystem> data);
    void sampleVoltageOfChargeableEnergyStorageDevice(uint16_t &data);
    void sampleCurrentOfChargeableEnergyStorageDevice(uint16_t &data);
    void sampleTotalNumberOfCell(uint16_t &data);
    void sampleDefaultVoltageOfCell(std::shared_ptr<VoltageOfCellList> data);
    void sampleVoltageOfCell(std::shared_ptr<VoltageOfCellList> data);
    void sampleStoreVoltageData(std::shared_ptr<VoltageOfCellList> data);

    void sampleDefaultTemperatureDataOfChargeableEnergyStoreSubsystem(std::shared_ptr<TemperatureDataOfChargeableEnergyStoreSubsystem> data);
    void sampleTemperatureDataOfChargeableEnergyStoreSubsystem(std::shared_ptr<TemperatureDataOfChargeableEnergyStoreSubsystem> data);
    void sampleDefaultTemperatureInformationOfChargeableEnergyStoreSubsystem(std::shared_ptr<TemperatureInformationOfChargeableEnergyStoreSubsystem> data);
    void sampleTemperatureInformationOfChargeableEnergyStoreSubsystem(std::shared_ptr<TemperatureInformationOfChargeableEnergyStoreSubsystem> data);
    void sampleDefaultTemperatureValueOfEachChargeableEnergyStoreSubsystem(std::shared_ptr<TemperatureValueList> data);
    void sampleTemperatureValueOfEachChargeableEnergyStoreSubsystem(std::shared_ptr<TemperatureValueList> data);
    void sampleQueryUplinkDataPackage(std::shared_ptr<ParameterQueryUplinkDataPackage> dataUplink, std::shared_ptr<GBTListOfItem<BYTE_GBT>> listOfItems);
    void sampleQueryUplinkPackage(std::shared_ptr<ParameterQueryUplinkPackage> dataUplink, std::shared_ptr<GBTListOfItem<BYTE_GBT>> listOfItems);
    void sampleQueryResponse(std::shared_ptr<ListOfParameterItem> listOfResponseParameter, std::shared_ptr<GBTListOfItem<BYTE_GBT>> listOfItems);
};

#endif // GBTDATAPACKAGING_H
