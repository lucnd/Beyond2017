#ifndef GBTSERIALIZABLE_H
#define GBTSERIALIZABLE_H

#include <vector>
#include <memory>
#include <stdint.h>
#include "../interface/ISerializable.h"
#include "Utils/GBTUtil.h"

class GBTSerializable : public ISerializable
{
public:
    GBTSerializable();
    bool serialize(std::vector<uint8_t> &buf, uint32_t offsetPos);
    bool deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos);
    virtual void addChildField() {}
    void makeSerializeStruct();
    void addField(std::shared_ptr<ISerializable> field);
    uint32_t getCurSize();
    void resetField();

private:
    std::vector<std::shared_ptr<ISerializable>> fieldList;
};

#endif // GBTSERIALIZABLE_H
