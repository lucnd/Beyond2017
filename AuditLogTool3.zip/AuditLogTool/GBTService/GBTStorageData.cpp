#include "GBTStorageData.h"

CellVoltageStorageData::CellVoltageStorageData()
{
    totalVoltage = std::make_shared<WORD_GBT>();
    totalCurrent = std::make_shared<WORD_GBT>();
    totalNumberOfCell = std::make_shared<WORD_GBT>();
    parallelCellsNum = std::make_shared<BYTE_GBT>();
    voltageOfCellList = std::make_shared<VoltageOfCellList>();
}

void CellVoltageStorageData::addChildField()
{
    addField(totalVoltage);
    addField(totalCurrent);
    addField(totalNumberOfCell);
    addField(parallelCellsNum);
    addField(voltageOfCellList);
}

std::string CellVoltageStorageData::toString()
{
    std::string str("");
    str += "CellVoltageStorageData\n{\n";
    str += "totalVoltage: " + totalVoltage->toString() + "\n";
    str += "totalCurrent: " + totalCurrent->toString() + "\n";
    str += "totalNumberOfCell: " + totalNumberOfCell->toString() + "\n";
    str += "parallelCellsNum: " + parallelCellsNum->toString() + "\n";
    str += "voltageOfCellList: " + voltageOfCellList->toValueArrString() + "\n";
    str += "}";
    return str;
}

bool CellVoltageStorageData::deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos)
{
    //uint32_t remainLen = len;
    bool ret = totalVoltage->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += totalVoltage->getCurSize();
    //remainLen -= totalVoltage->getCurSize();

    ret = totalCurrent->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += totalCurrent->getCurSize();
    //remainLen -= totalCurrent->getCurSize();

    ret = totalNumberOfCell->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += totalNumberOfCell->getCurSize();
    //remainLen -= totalNumberOfCell->getCurSize();

    ret = parallelCellsNum->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += parallelCellsNum->getCurSize();
    //remainLen -= parallelCellsNum->getCurSize();

    uint16_t cellNum = *totalNumberOfCell;
    voltageOfCellList->setListSize(cellNum);
    ret = voltageOfCellList->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    return true;
}

uint16_t CellVoltageStorageData::getTotalNumberOfCell() const
{
    return *totalNumberOfCell;
}

void CellVoltageStorageData::setTotalNumberOfCell(const uint16_t &value)
{
    *totalNumberOfCell = value;
}

std::shared_ptr<VoltageOfCellList> CellVoltageStorageData::getVoltageOfCellList() const
{
    return voltageOfCellList;
}

void CellVoltageStorageData::setVoltageOfCellList(const std::shared_ptr<VoltageOfCellList> &value)
{
    voltageOfCellList = value;
}

uint16_t CellVoltageStorageData::getTotalVoltage() const
{
    return *totalVoltage;
}

void CellVoltageStorageData::setTotalVoltage(const uint16_t &value)
{
    *totalVoltage = value;
}

uint16_t CellVoltageStorageData::getTotalCurrent() const
{
    return *totalCurrent;
}

void CellVoltageStorageData::setTotalCurrent(const uint16_t &value)
{
    *totalCurrent = value;
}

uint8_t CellVoltageStorageData::getParallelCellsNum() const
{
    return *parallelCellsNum;
}

void CellVoltageStorageData::setParallelCellsNum(const uint8_t &value)
{
    *parallelCellsNum = value;
}

TemperatureStorageData::TemperatureStorageData()
{
    tempProbeCount = std::make_shared<WORD_GBT>();
    temperatureValueList = std::make_shared<TemperatureValueList>();
}

void TemperatureStorageData::addChildField()
{
    addField(tempProbeCount);
    addField(temperatureValueList);
}

std::string TemperatureStorageData::toString()
{
    std::string str("");
    str += "TemperatureStorageData\n{\n";
    str += "tempProbeCount: " + tempProbeCount->toString() + "\n";
    str += "temperatureValueList: " + temperatureValueList->toValueArrString() + "\n";
    str += "}";
    return str;
}

bool TemperatureStorageData::deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos)
{
    //uint32_t remainLen = len;
    bool ret = tempProbeCount->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    offsetPos += tempProbeCount->getCurSize();
    //remainLen -= tempProbeCount->getCurSize();

    uint16_t probeNum = *tempProbeCount;
    temperatureValueList->setListSize(probeNum);
    ret = temperatureValueList->deserialize(buf, offsetPos);
    if (!ret)
    {
        return false;
    }
    return true;
}

uint16_t TemperatureStorageData::getTempProbeCount() const
{
    return *tempProbeCount;
}

void TemperatureStorageData::setTempProbeCount(const uint16_t &value)
{
    *tempProbeCount = value;
}

std::shared_ptr<TemperatureValueList> TemperatureStorageData::getTemperatureValueList() const
{
    return temperatureValueList;
}

void TemperatureStorageData::setTemperatureValueList(const std::shared_ptr<TemperatureValueList> &value)
{
    temperatureValueList = value;
}

GBTStorageData::GBTStorageData()
{
    dataAcquisitionTime = std::make_shared<ChinaTimePacket>();
    completeVehicleData = std::make_shared<CompleteVehicleDataPacket>();
    electricMachineData = std::make_shared<ElectricMachineDataPacket>();
    dataOfEngine = std::make_shared<DataOfEnginePacket>();
    gpsData = std::make_shared<GPSDataPacket>();
    limitValueData = std::make_shared<LimitValueDataPacket>();
    warningData = std::make_shared<WarningDataPacket>();
    cellVoltageData = std::make_shared<CellVoltageStorageData>();
    temperatureData = std::make_shared<TemperatureStorageData>();
}

void GBTStorageData::addChildField()
{
    addField(dataAcquisitionTime);
    addField(completeVehicleData);
    addField(electricMachineData);
    addField(dataOfEngine);
    addField(gpsData);
    addField(limitValueData);
    addField(warningData);
    addField(cellVoltageData);
    addField(temperatureData);
}

std::string GBTStorageData::toString()
{
    std::string str("");
    str += "GBTStorageData\n{\n";
    str += dataAcquisitionTime->toString() + "\n";
    str += completeVehicleData->toString() + "\n";
    str += electricMachineData->toString() + "\n";
    str += dataOfEngine->toString() + "\n";
    str += gpsData->toString() + "\n";
    str += limitValueData->toString() + "\n";
    str += warningData->toString() + "\n";
    str += cellVoltageData->toString() + "\n";
    str += temperatureData->toString() + "\n";
    str += "}";
    return str;
}

std::shared_ptr<ChinaTimePacket> GBTStorageData::getDataAcquisitionTime() const
{
    return dataAcquisitionTime;
}

std::shared_ptr<CompleteVehicleDataPacket> GBTStorageData::getCompleteVehicleData() const
{
    return completeVehicleData;
}

std::shared_ptr<ElectricMachineDataPacket> GBTStorageData::getElectricMachineData() const
{
    return electricMachineData;
}

std::shared_ptr<DataOfEnginePacket> GBTStorageData::getDataOfEngine() const
{
    return dataOfEngine;
}

std::shared_ptr<GPSDataPacket> GBTStorageData::getGpsData() const
{
    return gpsData;
}

std::shared_ptr<LimitValueDataPacket> GBTStorageData::getLimitValueData() const
{
    return limitValueData;
}

std::shared_ptr<WarningDataPacket> GBTStorageData::getWarningData() const
{
    return warningData;
}

std::shared_ptr<CellVoltageStorageData> GBTStorageData::getCellVoltageData() const
{
    return cellVoltageData;
}

std::shared_ptr<TemperatureStorageData> GBTStorageData::getTemperatureData() const
{
    return temperatureData;
}

void GBTStorageData::setDataAcquisitionTime(const std::shared_ptr<ChinaTimePacket> &value)
{
    dataAcquisitionTime = value;
}

void GBTStorageData::setCompleteVehicleData(const std::shared_ptr<CompleteVehicleDataPacket> &value)
{
    completeVehicleData = value;
}

void GBTStorageData::setElectricMachineData(const std::shared_ptr<ElectricMachineDataPacket> &value)
{
    electricMachineData = value;
}

void GBTStorageData::setDataOfEngine(const std::shared_ptr<DataOfEnginePacket> &value)
{
    dataOfEngine = value;
}

void GBTStorageData::setGpsData(const std::shared_ptr<GPSDataPacket> &value)
{
    gpsData = value;
}

void GBTStorageData::setLimitValueData(const std::shared_ptr<LimitValueDataPacket> &value)
{
    limitValueData = value;
}

void GBTStorageData::setWarningData(const std::shared_ptr<WarningDataPacket> &value)
{
    warningData = value;
}

void GBTStorageData::setCellVoltageData(const std::shared_ptr<CellVoltageStorageData> &value)
{
    cellVoltageData = value;
}

void GBTStorageData::setTemperatureData(const std::shared_ptr<TemperatureStorageData> &value)
{
    temperatureData = value;
}
