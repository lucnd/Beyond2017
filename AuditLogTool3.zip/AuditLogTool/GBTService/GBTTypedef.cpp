#include "GBTTypedef.h"

template <int N>
GBTBaseType<N>::GBTBaseType()
{
    value = 0;
    memset(data, 0, N);
}

template <int N>
bool GBTBaseType<N>::serialize(std::vector<uint8_t> &buf, uint32_t offsetPos)
{
    if ((buf.size() - offsetPos) >= N)
    {
        std::copy(data, data + N, buf.begin() + offsetPos);
        return true;
    }
    else
    {
        return false;
    }
}

template <int N>
bool GBTBaseType<N>::deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos)
{
    if ((buf.size() - offsetPos) < N)
    {
        return false;
    }
    else
    {
        uint64_t tempValue = 0;
        for (int i = 0; i < N; i++)
        {
            data[i] = buf[offsetPos + i];
            tempValue |= (uint64_t)(buf[offsetPos + i]) << ((N - i - 1) * 8);
        }
        value = tempValue;
    }
    return true;
}

template <int N>
std::string GBTBaseType<N>::toString()
{
    return std::to_string(value);
}

template <int N>
std::string GBTBaseType<N>::toHexString()
{
    return GBTUtil::toHexString(data, N);
}

template <int N>
std::string GBTBaseType<N>::toCharString()
{
    return GBTUtil::toCharString(data, N);
}

template <int N>
uint32_t GBTBaseType<N>::getCurSize()
{
    return N;
}

template <int N>
GBTBaseType<N> &GBTBaseType<N>::operator=(const uint8_t &t)
{
    value = t;
    for (int i = 0; i < N; i++)
    {
        uint64_t mask = (uint64_t)(0xFF) << ((N - i - 1) * 8);
        data[i] = static_cast<unsigned char>((t & mask) >> ((N - i - 1) * 8));
    }
    return *this;
}

template <int N>
GBTBaseType<N> &GBTBaseType<N>::operator=(const uint16_t &t)
{
    value = t;
    for (int i = 0; i < N; i++)
    {
        uint64_t mask = (uint64_t)(0xFF) << ((N - i - 1) * 8);
        data[i] = static_cast<unsigned char>((t & mask) >> ((N - i - 1) * 8));
    }
    return *this;
}

template <int N>
GBTBaseType<N> &GBTBaseType<N>::operator=(const uint32_t &t)
{
    value = t;
    for (int i = 0; i < N; i++)
    {
        uint64_t mask = (uint64_t)(0xFF) << ((N - i - 1) * 8);
        data[i] = static_cast<unsigned char>((t & mask) >> ((N - i - 1) * 8));
    }
    return *this;
}

template <int N>
GBTBaseType<N> &GBTBaseType<N>::operator=(const uint64_t &t)
{
    value = t;
    for (int i = 0; i < N; i++)
    {
        uint64_t mask = (uint64_t)(0xFF) << ((N - i - 1) * 8);
        data[i] = static_cast<unsigned char>((t & mask) >> ((N - i - 1) * 8));
    }
    return *this;
}

template <int N>
GBTBaseType<N> &GBTBaseType<N>::operator=(const int &t)
{
    value = t;
    for (int i = 0; i < N; i++)
    {
        uint64_t mask = (uint64_t)(0xFF) << ((N - i - 1) * 8);
        data[i] = static_cast<unsigned char>((t & mask) >> ((N - i - 1) * 8));
    }
    return *this;
}

template <int N>
GBTBaseType<N> &GBTBaseType<N>::operator=(const GBTBaseType &t)
{
    if (this == &t)
    {
        return *this;
    }
    this->value = t.value;
    for (int i = 0; i < N; i++)
    {
        data[i] = t.data[i];
    }
    return *this;
}

template <int N>
bool GBTBaseType<N>::operator==(const GBTBaseType &t) const
{
    if (this->getCurSize() != t.getCurSize())
    {
        return false;
    }

    for (int i = 0; i < N; i++)
    {
        if (this->data[i] != t.data[i])
        {
            return false;
        }
    }
    return true;
}

template <int N>
bool GBTBaseType<N>::operator!=(const GBTBaseType &t) const
{
    return !(operator==(t));
}

template <int N>
GBTBaseType<N>::operator uint64_t()
{
    return value;
}
