#include "GBTListOfItem.h"
//#include <Log.h>

template<typename T>
GBTListOfItem<T>::GBTListOfItem()
{
    listSize = 0;
}

template<typename T>
void GBTListOfItem<T>::addChildField()
{
    for (auto field : listOfItem)
    {
        addField(field);
    }
}

template<typename T>
std::string GBTListOfItem<T>::toString()
{
    //LOGV("%s()", __func__);
    std::string str("");
    str += "GBTListOfItem\n{\n";
    for (auto field : listOfItem)
    {
        str += field->toString() + "\n";
    }
    str += "}";
    return str;
}

template<typename T>
std::string GBTListOfItem<T>::toHexString()
{
    std::string str("");
    str += "GBTListOfItem\n{\n";
    int idx = 0;
    for (auto field : listOfItem)
    {
        str += "0x" + field->toHexString() + " ";
        idx++;
        if(idx == 10)
        {
            str += "\n";
            idx = 0;
        }
    }
    str += "\n}";
    return str;
}

template<typename T>
std::string GBTListOfItem<T>::toValueArrString()
{
    std::string str("");
    str += "GBTListOfItem\n{\n";
    int idx = 0;
    for (auto field : listOfItem)
    {
        str += field->toString() + " ";
        idx++;
        if(idx == 10)
        {
            str += "\n";
            idx = 0;
        }
    }
    str += "\n}";
    return str;
}

template <typename T>
std::string GBTListOfItem<T>::toValueDataString()
{
    std::string str("");
    str += "GBTListOfItem\n{\n";
    int idx = 0;
    for (auto field : listOfItem)
    {
        str += field->toString();
    }
    str += "\n}";
    return str;
}

template <typename T>
std::shared_ptr<T> GBTListOfItem<T>::operator[](int index)
{
    return listOfItem.at(index);
}

template<typename T>
std::shared_ptr<T> GBTListOfItem<T>::getItem(int index)
{
    return listOfItem.at(index);
}

template<typename T>
bool GBTListOfItem<T>::deserialize(std::vector<uint8_t>& buf, uint32_t offsetPos)
{
    for(int i = 0; i < listSize; i++)
    {
        bool ret = listOfItem.at(i)->deserialize(buf, offsetPos);
        if(!ret)
        {
            return false;
        }
        offsetPos += listOfItem.at(i)->getCurSize();
    }
    return true;
}

template<typename T>
int GBTListOfItem<T>::getListSize() const
{
    return listOfItem.size();
}

template<typename T>
void GBTListOfItem<T>::setListSize(int value)
{
    if(value != listSize)
    {
        listOfItem.clear();
        listSize = value;
        if(listSize > 0)
        {
            for(int i = 0; i < listSize; i++)
            {
                std::shared_ptr<T> newItem = std::make_shared<T>();
                listOfItem.push_back(newItem);
                addField(newItem);
            }
        }
    }
}

template<typename T>
void GBTListOfItem<T>::prepend(const std::shared_ptr<T> &data)
{
    listOfItem.push_back(data);
    addField(data);
}

template<typename T>
void GBTListOfItem<T>::removeItem(int index)
{
    if(index < listOfItem.size())
    {
        listOfItem.erase(listOfItem.begin() + index);
    }
}
