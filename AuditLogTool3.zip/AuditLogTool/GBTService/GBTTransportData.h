#ifndef GBTTRANSPORTDATA_H
#define GBTTRANSPORTDATA_H

#include <vector>
#include "GBTTypedef.h"
#include "GBTSerializable.h"
#include "GBTListOfItem.h"

#define BYTE_GBT GBTBaseType<1>
#define WORD_GBT GBTBaseType<2>
#define DWORD_GBT GBTBaseType<4>
#define QWORD_GBT GBTBaseType<8>
#define TRIBYTE_GBT GBTBaseType<3>

#define ListOfFaultData GBTListOfItem<DWORD_GBT>
#define VoltageOfCellList GBTListOfItem<WORD_GBT>
#define TemperatureValueList GBTListOfItem<BYTE_GBT>
#define ListOfVoltageInformationOfChargeableEnergyStoreSubsystem GBTListOfItem<VoltageInformationOfChargeableEnergyStoreSubsystem>
#define ListOfTemperatureInformationOfChargeableEnergyStoreSubsystem GBTListOfItem<TemperatureInformationOfChargeableEnergyStoreSubsystem>
#define ListOfParameterItem GBTListOfItem<ParameterItem>
#define ListOfParameterItemResponse GBTListOfItem<ParameterItemResponse>

enum PacketType
{
    LoginType,
    LogoutType,
    RealTimeType
};

class DataHeaderPacket : public GBTSerializable
{
public:
    DataHeaderPacket();
    void addChildField();
    std::string toString();

    std::string getStartcharacter() const;
    void setStartcharacter(const std::string &value);

    uint8_t getCommandIdentification() const;
    void setCommandIdentification(const uint8_t &value);

    uint8_t getResponseMark() const;
    void setResponseMark(const uint8_t &value);

    std::string getUniqueIdentificationNumber() const;
    void setUniqueIdentificationNumber(const std::string &value);

    uint8_t getDataUnitEncryptionManner() const;
    void setDataUnitEncryptionManner(const uint8_t &value);

private:
    std::shared_ptr<GBTListOfItem<BYTE_GBT>> startcharacter;
    std::shared_ptr<BYTE_GBT> commandIdentification;
    std::shared_ptr<BYTE_GBT> responseMark;
    std::shared_ptr<GBTListOfItem<BYTE_GBT>> uniqueIdentificationNumber;
    std::shared_ptr<BYTE_GBT> dataUnitEncryptionManner;
};

class ChinaTimePacket : public GBTSerializable
{
public:
    ChinaTimePacket();
    void addChildField();
    std::string toString();

    uint8_t getYear() const;
    void setYear(const uint8_t &value);

    uint8_t getMonth() const;
    void setMonth(const uint8_t &value);

    uint8_t getDay() const;
    void setDay(const uint8_t &value);

    uint8_t getHour() const;
    void setHour(const uint8_t &value);

    uint8_t getMinute() const;
    void setMinute(const uint8_t &value);

    uint8_t getSecond() const;
    void setSecond(const uint8_t &value);

private:
    std::shared_ptr<BYTE_GBT> year;
    std::shared_ptr<BYTE_GBT> month;
    std::shared_ptr<BYTE_GBT> day;
    std::shared_ptr<BYTE_GBT> hour;
    std::shared_ptr<BYTE_GBT> minute;
    std::shared_ptr<BYTE_GBT> second;
};

class CodeOfChargeableEnergyStorageSystem : public GBTSerializable
{
public:
    CodeOfChargeableEnergyStorageSystem();
    void addChildField();
    std::string toString();

    int getHvBattCellType() const;
    void setHvBattCellType(const int &value);

    int getHvBattCompanyCode() const;
    void setHvBattCompanyCode(const int &value);

    int getHvBattProdDatePart1() const;
    void setHvBattProdDatePart1(const int &value);

    int getHvBattProdDatePart2() const;
    void setHvBattProdDatePart2(const int &value);

    int getHvBattProductType() const;
    void setHvBattProductType(const int &value);

    int getHvBattSerialNumPart1() const;
    void setHvBattSerialNumPart1(const int &value);

    int getHvBattSerialNumPart2() const;
    void setHvBattSerialNumPart2(const int &value);

    int getHvBattTraceInfoCode1() const;
    void setHvBattTraceInfoCode1(const int &value);

    int getHvBattTraceInfoCode2() const;
    void setHvBattTraceInfoCode2(const int &value);

    int getHvBattTraceInfoCode3() const;
    void setHvBattTraceInfoCode3(const int &value);

    int getHvBattTraceInfoCode4() const;
    void setHvBattTraceInfoCode4(const int &value);

    int getHvBattTraceInfoCode5() const;
    void setHvBattTraceInfoCode5(const int &value);

    int getHvBattTraceInfoCode6() const;
    void setHvBattTraceInfoCode6(const int &value);

    int getHvBattTraceInfoCode7() const;
    void setHvBattTraceInfoCode7(const int &value);

    int getHvBattTypeCode() const;
    void setHvBattTypeCode(const int &value);

private:
    std::shared_ptr<TRIBYTE_GBT> hvBattCompanyCode;
    std::shared_ptr<BYTE_GBT> hvBattProductType;
    std::shared_ptr<BYTE_GBT> hvBattCellType;
    std::shared_ptr<WORD_GBT> hvBattTypeCode;
    std::shared_ptr<BYTE_GBT> hvBattTraceInfoCode1;

    std::shared_ptr<BYTE_GBT> hvBattTraceInfoCode2;
    std::shared_ptr<BYTE_GBT> hvBattTraceInfoCode3;
    std::shared_ptr<BYTE_GBT> hvBattTraceInfoCode4;
    std::shared_ptr<BYTE_GBT> hvBattTraceInfoCode5;
    std::shared_ptr<BYTE_GBT> hvBattTraceInfoCode6;
    std::shared_ptr<BYTE_GBT> hvBattTraceInfoCode7;
    std::shared_ptr<WORD_GBT> hvBattProdDatePart1;

    std::shared_ptr<BYTE_GBT> hvBattProdDatePart2;
    std::shared_ptr<DWORD_GBT> hvBattSerialNumPart1;
    std::shared_ptr<TRIBYTE_GBT> hvBattSerialNumPart2;
};

class VehicleLoginPacket : public GBTSerializable
{
public:
    VehicleLoginPacket();
    void addChildField();
    std::string toString();

    std::shared_ptr<ChinaTimePacket> getDataAcquisitionTime() const;
    uint16_t getLoginSerialNumber() const;
    void setLoginSerialNumber(const uint16_t &value);
    std::string getIccid() const;
    void setIccid(const std::string &value);
    uint8_t getQuantityOfChargeableEnergyStorageSubsystem() const;
    void setQuantityOfChargeableEnergyStorageSubsystem(const uint8_t &value);
    uint8_t getCodeLengthOfChargeableEnergyStorageSystem() const;
    void setCodeLengthOfChargeableEnergyStorageSystem(const uint8_t &value);

    std::shared_ptr<CodeOfChargeableEnergyStorageSystem> getCodeOfChargeableEnergyStorageSystem() const;

private:
    std::shared_ptr<ChinaTimePacket> dataAcquisitionTime;
    std::shared_ptr<WORD_GBT> loginSerialNumber;
    std::shared_ptr<GBTListOfItem<BYTE_GBT>> iccid;
    std::shared_ptr<BYTE_GBT> quantityOfChargeableEnergyStorageSubsystem;
    std::shared_ptr<BYTE_GBT> codeLengthOfChargeableEnergyStorageSystem;
    std::shared_ptr<CodeOfChargeableEnergyStorageSystem> codeOfChargeableEnergyStorageSystem;
};

class VehicleLoginDataPackage : public GBTSerializable
{
public:
    VehicleLoginDataPackage();
    void addChildField();
    std::string toString();

    std::shared_ptr<DataHeaderPacket> getHeader() const;

    uint16_t getDataUnitLength() const;
    void setDataUnitLength(const uint16_t &value);

    std::shared_ptr<VehicleLoginPacket> getLoginData() const;

    uint8_t getCheckCode() const;
    void setCheckCode(const uint8_t &value);

private:
    std::shared_ptr<DataHeaderPacket> header;
    std::shared_ptr<WORD_GBT> dataUnitLength;
    std::shared_ptr<VehicleLoginPacket> loginData;
    std::shared_ptr<BYTE_GBT> checkCode;
};

class CompleteVehicleDataPacket : public GBTSerializable
{
public:
    CompleteVehicleDataPacket();
    void addChildField();
    std::string toString();

    uint8_t getVehicleState() const;
    void setVehicleState(const uint8_t &value);

    uint8_t getChargingState() const;
    void setChargingState(const uint8_t &value);

    uint8_t getOperationMode() const;
    void setOperationMode(const uint8_t &value);

    uint16_t getVehicleSpeed() const;
    void setVehicleSpeed(const uint16_t &value);

    uint32_t getAccumulatedMileage() const;
    void setAccumulatedMileage(const uint32_t &value);

    uint16_t getTotalVoltage() const;
    void setTotalVoltage(const uint16_t &value);

    uint16_t getTotalCurrent() const;
    void setTotalCurrent(const uint16_t &value);

    uint8_t getSoc() const;
    void setSoc(const uint8_t &value);

    uint8_t getDcdcState() const;
    void setDcdcState(const uint8_t &value);

    uint8_t getGearPosition() const;
    void setGearPosition(const uint8_t &value);

    uint16_t getInsulationResistance() const;
    void setInsulationResistance(const uint16_t &value);

    uint8_t getStrokeOfAcceratorPedal() const;
    void setStrokeOfAcceratorPedal(const uint8_t &value);

    uint8_t getBrakePedalState() const;
    void setBrakePedalState(const uint8_t &value);

private:
    std::shared_ptr<BYTE_GBT> vehicleState;
    std::shared_ptr<BYTE_GBT> chargingState;
    std::shared_ptr<BYTE_GBT> operationMode;
    std::shared_ptr<WORD_GBT> vehicleSpeed;
    std::shared_ptr<DWORD_GBT> accumulatedMileage;
    std::shared_ptr<WORD_GBT> totalVoltage;
    std::shared_ptr<WORD_GBT> totalCurrent;
    std::shared_ptr<BYTE_GBT> soc;
    std::shared_ptr<BYTE_GBT> dcdcState;
    std::shared_ptr<BYTE_GBT> gearPosition;
    std::shared_ptr<WORD_GBT> insulationResistance;
    std::shared_ptr<BYTE_GBT> strokeOfAcceratorPedal;
    std::shared_ptr<BYTE_GBT> brakePedalState;
};

class ElectricMachineDataUnitPacket : public GBTSerializable
{
public:
    ElectricMachineDataUnitPacket();
    void addChildField();
    std::string toString();

    uint8_t getSnOfElectricalMachine() const;
    void setSnOfElectricalMachine(const uint8_t &value);

    uint8_t getStateOfElectricalMachine() const;
    void setStateOfElectricalMachine(const uint8_t &value);

    uint8_t getTemperatureOfElectricalMachineController() const;
    void setTemperatureOfElectricalMachineController(const uint8_t &value);

    uint16_t getSpeedOfElectricalMachine() const;
    void setSpeedOfElectricalMachine(const uint16_t &value);

    uint16_t getTorqueOfElectricalMachine() const;
    void setTorqueOfElectricalMachine(const uint16_t &value);

    uint8_t getTemperatureOfElectricalMachine() const;
    void setTemperatureOfElectricalMachine(const uint8_t &value);

    uint16_t getInputVoltageOfElectricalMachineController() const;
    void setInputVoltageOfElectricalMachineController(const uint16_t &value);

    uint16_t getCurrentOfDCbusOfElectricalMachineController() const;
    void setCurrentOfDCbusOfElectricalMachineController(const uint16_t &value);

private:
    std::shared_ptr<BYTE_GBT> snOfElectricalMachine;
    std::shared_ptr<BYTE_GBT> stateOfElectricalMachine;
    std::shared_ptr<BYTE_GBT> temperatureOfElectricalMachineController;
    std::shared_ptr<WORD_GBT> speedOfElectricalMachine;
    std::shared_ptr<WORD_GBT> torqueOfElectricalMachine;
    std::shared_ptr<BYTE_GBT> temperatureOfElectricalMachine;
    std::shared_ptr<WORD_GBT> inputVoltageOfElectricalMachineController;
    std::shared_ptr<WORD_GBT> currentOfDCbusOfElectricalMachineController;
};

class ElectricMachineDataPacket : public GBTSerializable
{
public:
    ElectricMachineDataPacket();
    void addChildField();
    std::string toString();
    bool deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos);

    uint8_t getQuantityOfElectricMachine() const;
    void setQuantityOfElectricMachine(const uint8_t &value);

    std::shared_ptr<ElectricMachineDataUnitPacket> getElectricMachineDataUnitPacketR() const;

    std::shared_ptr<ElectricMachineDataUnitPacket> getElectricMachineDataUnitPacketF() const;

private:
    std::shared_ptr<BYTE_GBT> quantityOfElectricMachine;
    std::shared_ptr<ElectricMachineDataUnitPacket> electricMachineDataUnitPacketR;
    std::shared_ptr<ElectricMachineDataUnitPacket> electricMachineDataUnitPacketF;
};

class FuelCellDataPacket : public GBTSerializable
{
public:
    FuelCellDataPacket();
    void addChildField();
    std::string toString();

    uint16_t getVoltageOfFuelCell() const;
    void setVoltageOfFuelCell(const uint16_t &value);

    uint16_t getCurrentOfFuelCell() const;
    void setCurrentOfFuelCell(const uint16_t &value);

    uint16_t getFuelConsumption() const;
    void setFuelConsumption(const uint16_t &value);

    uint16_t getTotalNumberOfFuelCellTemperatureProbes() const;
    void setTotalNumberOfFuelCellTemperatureProbes(const uint16_t &value);

    std::shared_ptr<GBTListOfItem<BYTE_GBT>> getProbeTemperatureValue() const;

    uint16_t getMaxTemperatureInHydrogenSystem() const;
    void setMaxTemperatureInHydrogenSystem(const uint16_t &value);

    uint8_t getCodeOfProbeWithMaxTempInHydrogenSystem() const;
    void setCodeOfProbeWithMaxTempInHydrogenSystem(const uint8_t &value);

    uint16_t getMaxConcentrationInHydrogen() const;
    void setMaxConcentrationInHydrogen(const uint16_t &value);

    uint8_t getCodeOfSensorWithMaxConcentrationOfHydrogen() const;
    void setCodeOfSensorWithMaxConcentrationOfHydrogen(const uint8_t &value);

    uint16_t getMaxPressureOfHydrogen() const;
    void setMaxPressureOfHydrogen(const uint16_t &value);

    uint8_t getCodeOfSensorWithTheMaxPressureOfHydrogen() const;
    void setCodeOfSensorWithTheMaxPressureOfHydrogen(const uint8_t &value);

    uint8_t getHighPressureDCDCState() const;
    void setHighPressureDCDCState(const uint8_t &value);

private:
    std::shared_ptr<WORD_GBT> voltageOfFuelCell;
    std::shared_ptr<WORD_GBT> currentOfFuelCell;
    std::shared_ptr<WORD_GBT> fuelConsumption;
    std::shared_ptr<WORD_GBT> totalNumberOfFuelCellTemperatureProbes;
    std::shared_ptr<GBTListOfItem<BYTE_GBT>> probeTemperatureValue;
    std::shared_ptr<WORD_GBT> maxTemperatureInHydrogenSystem;
    std::shared_ptr<BYTE_GBT> codeOfProbeWithMaxTempInHydrogenSystem;
    std::shared_ptr<WORD_GBT> maxConcentrationInHydrogen;
    std::shared_ptr<BYTE_GBT> codeOfSensorWithMaxConcentrationOfHydrogen;
    std::shared_ptr<WORD_GBT> maxPressureOfHydrogen;
    std::shared_ptr<BYTE_GBT> codeOfSensorWithTheMaxPressureOfHydrogen;
    std::shared_ptr<BYTE_GBT> highPressureDCDCState;
};

class DataOfEnginePacket : public GBTSerializable
{
public:
    DataOfEnginePacket();
    void addChildField();
    std::string toString();

    uint8_t getEngineState() const;
    void setEngineState(const uint8_t &value);

    uint16_t getCrankshaftSpeed() const;
    void setCrankshaftSpeed(const uint16_t &value);

    uint16_t getFuelConsumption() const;
    void setFuelConsumption(const uint16_t &value);

private:
    std::shared_ptr<BYTE_GBT> engineState;
    std::shared_ptr<WORD_GBT> crankshaftSpeed;
    std::shared_ptr<WORD_GBT> fuelConsumption;
};

class GPSDataPacket : public GBTSerializable
{
public:
    GPSDataPacket();
    void addChildField();
    std::string toString();

    uint8_t getPositioningState() const;
    void setPositioningState(const uint8_t &value);

    uint32_t getLongitude() const;
    void setLongitude(const uint32_t &value);

    uint32_t getLatitude() const;
    void setLatitude(const uint32_t &value);

private:
    std::shared_ptr<BYTE_GBT> positioningState;
    std::shared_ptr<DWORD_GBT> longitude;
    std::shared_ptr<DWORD_GBT> latitude;
};

class LimitValueDataPacket : public GBTSerializable
{
public:
    LimitValueDataPacket();
    void addChildField();
    std::string toString();

    uint8_t getIdNoOfBatterySubsystemWithMaxVoltage() const;
    void setIdNoOfBatterySubsystemWithMaxVoltage(const uint8_t &value);

    uint8_t getIdNoOfCellWithMaxVoltage() const;
    void setIdNoOfCellWithMaxVoltage(const uint8_t &value);

    uint16_t getMaxCellVoltage() const;
    void setMaxCellVoltage(const uint16_t &value);

    uint8_t getIdNoOfBatterySubsystemWithMinVoltage() const;
    void setIdNoOfBatterySubsystemWithMinVoltage(const uint8_t &value);

    uint8_t getIdNoOfCellWithMinVoltage() const;
    void setIdNoOfCellWithMinVoltage(const uint8_t &value);

    uint16_t getMinCellVoltage() const;
    void setMinCellVoltage(const uint16_t &value);

    uint8_t getIdNoOfSubsystemWithMaxTemperature() const;
    void setIdNoOfSubsystemWithMaxTemperature(const uint8_t &value);

    uint8_t getCodeOfSingleProbeWithMaxTemperature() const;
    void setCodeOfSingleProbeWithMaxTemperature(const uint8_t &value);

    uint8_t getMaxTemperatureValue() const;
    void setMaxTemperatureValue(const uint8_t &value);

    uint8_t getIdNoOfSubsystemWithMinTemperature() const;
    void setIdNoOfSubsystemWithMinTemperature(const uint8_t &value);

    uint8_t getCodeOfProbeSubsystemWithMinTemperature() const;
    void setCodeOfProbeSubsystemWithMinTemperature(const uint8_t &value);

    uint8_t getMinTemperatureValue() const;
    void setMinTemperatureValue(const uint8_t &value);

private:
    std::shared_ptr<BYTE_GBT> idNoOfBatterySubsystemWithMaxVoltage;
    std::shared_ptr<BYTE_GBT> idNoOfCellWithMaxVoltage;
    std::shared_ptr<WORD_GBT> maxCellVoltage;
    std::shared_ptr<BYTE_GBT> idNoOfBatterySubsystemWithMinVoltage;
    std::shared_ptr<BYTE_GBT> idNoOfCellWithMinVoltage;
    std::shared_ptr<WORD_GBT> minCellVoltage;
    std::shared_ptr<BYTE_GBT> idNoOfSubsystemWithMaxTemperature;
    std::shared_ptr<BYTE_GBT> codeOfSingleProbeWithMaxTemperature;
    std::shared_ptr<BYTE_GBT> maxTemperatureValue;
    std::shared_ptr<BYTE_GBT> idNoOfSubsystemWithMinTemperature;
    std::shared_ptr<BYTE_GBT> codeOfProbeSubsystemWithMinTemperature;
    std::shared_ptr<BYTE_GBT> minTemperatureValue;
};

class ListOfWarningFaultData : public GBTSerializable
{
public:
    ListOfWarningFaultData();
    void addChildField();
    std::string toString();
    bool deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos);

    uint8_t getNumberOfFaults() const;
    void setNumberOfFaults(const uint8_t &value);

    std::shared_ptr<ListOfFaultData> getListOfFaults() const;

private:
    std::shared_ptr<BYTE_GBT> numberOfFaults;
    std::shared_ptr<ListOfFaultData> listOfFaults;
};

class WarningDataPacket : public GBTSerializable
{
public:
    WarningDataPacket();
    void addChildField();
    std::string toString();

    uint8_t getHighestWarningLevel() const;
    void setHighestWarningLevel(const uint8_t &value);

    uint32_t getGeneralWarningMark() const;
    void setGeneralWarningMark(const uint32_t &value);

    std::shared_ptr<ListOfWarningFaultData> getListOfCodesOfChargeableEnergyStorageDeviceFaults() const;

    std::shared_ptr<ListOfWarningFaultData> getListOfCodesOfElectricalMachineFaults() const;

    std::shared_ptr<ListOfWarningFaultData> getListOfEngineFaults() const;

    std::shared_ptr<ListOfWarningFaultData> getListOfCodesOfOtherFaults() const;

private:
    std::shared_ptr<BYTE_GBT> highestWarningLevel;
    std::shared_ptr<DWORD_GBT> generalWarningMark;
    std::shared_ptr<ListOfWarningFaultData> listOfCodesOfChargeableEnergyStorageDeviceFaults;
    std::shared_ptr<ListOfWarningFaultData> listOfCodesOfElectricalMachineFaults;
    std::shared_ptr<ListOfWarningFaultData> listOfEngineFaults;
    std::shared_ptr<ListOfWarningFaultData> listOfCodesOfOtherFaults;
};

class VoltageInformationOfChargeableEnergyStoreSubsystem : public GBTSerializable
{
public:
    VoltageInformationOfChargeableEnergyStoreSubsystem();
    void addChildField();
    std::string toString();
    bool deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos);

    uint8_t getCodeOfChargeableEnergyStoreSubsystem() const;
    void setCodeOfChargeableEnergyStoreSubsystem(const uint8_t &value);

    uint16_t getVoltageOfChargeableEnergyStorageDevice() const;
    void setVoltageOfChargeableEnergyStorageDevice(const uint16_t &value);

    uint16_t getCurrentOfChargeableEnergyStorageDevice() const;
    void setCurrentOfChargeableEnergyStorageDevice(const uint16_t &value);

    uint16_t getTotalNumberOfCell() const;
    void setTotalNumberOfCell(const uint16_t &value);

    uint16_t getSnOfStartingBatteryOfThisFrame() const;
    void setSnOfStartingBatteryOfThisFrame(const uint16_t &value);

    uint8_t getTotalCellNumberOfThisFrame() const;
    void setTotalCellNumberOfThisFrame(const uint8_t &value);

    std::shared_ptr<VoltageOfCellList> getVoltageOfCell() const;

private:
    std::shared_ptr<BYTE_GBT> codeOfChargeableEnergyStoreSubsystem;
    std::shared_ptr<WORD_GBT> voltageOfChargeableEnergyStorageDevice;
    std::shared_ptr<WORD_GBT> currentOfChargeableEnergyStorageDevice;
    std::shared_ptr<WORD_GBT> totalNumberOfCell;
    std::shared_ptr<WORD_GBT> snOfStartingBatteryOfThisFrame;
    std::shared_ptr<BYTE_GBT> totalCellNumberOfThisFrame;
    std::shared_ptr<VoltageOfCellList> voltageOfCell;
};

class VoltageDataOfChargeableEnergyStoreSubsystem : public GBTSerializable
{
public:
    VoltageDataOfChargeableEnergyStoreSubsystem();
    void addChildField();
    std::string toString();
    bool deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos);

    uint8_t getQuantityOfChargeableEnergyStoreSubsystem() const;
    void setQuantityOfChargeableEnergyStoreSubsystem(const uint8_t &value);

    std::shared_ptr<ListOfVoltageInformationOfChargeableEnergyStoreSubsystem> getListOfVoltageInformationOfChargeableEnergyStoreSubsystem() const;

    void setListOfVoltageInformationOfChargeableEnergyStoreSubsystem(const std::shared_ptr<GBTListOfItem<VoltageInformationOfChargeableEnergyStoreSubsystem>> &value);

private:
    std::shared_ptr<BYTE_GBT> quantityOfChargeableEnergyStoreSubsystem;
    std::shared_ptr<ListOfVoltageInformationOfChargeableEnergyStoreSubsystem> listOfVoltageInformationOfChargeableEnergyStoreSubsystem;
};

class TemperatureInformationOfChargeableEnergyStoreSubsystem : public GBTSerializable
{
public:
    TemperatureInformationOfChargeableEnergyStoreSubsystem();
    void addChildField();
    std::string toString();
    bool deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos);

    uint8_t getCodeOfChargeableEnergyStoreSubsystem() const;
    void setCodeOfChargeableEnergyStoreSubsystem(const uint8_t &value);

    uint16_t getQuantityOfChargeableEnergyStoreSubsystem() const;
    void setQuantityOfChargeableEnergyStoreSubsystem(const uint16_t &value);

    std::shared_ptr<TemperatureValueList> getTemperatureValueOfEachChargeableEnergyStoreSubsystem() const;

    void setTemperatureValueOfEachChargeableEnergyStoreSubsystem(const std::shared_ptr<TemperatureValueList> &value);

private:
    std::shared_ptr<BYTE_GBT> codeOfChargeableEnergyStoreSubsystem;
    std::shared_ptr<WORD_GBT> quantityOfChargeableEnergyStoreSubsystem;
    std::shared_ptr<TemperatureValueList> temperatureValueOfEachChargeableEnergyStoreSubsystem;
};

class TemperatureDataOfChargeableEnergyStoreSubsystem : public GBTSerializable
{
public:
    TemperatureDataOfChargeableEnergyStoreSubsystem();
    void addChildField();
    std::string toString();
    bool deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos);

    uint8_t getQuantityOfChargeableEnergyStoreSubsystem() const;
    void setQuantityOfChargeableEnergyStoreSubsystem(const uint8_t &value);

    std::shared_ptr<ListOfTemperatureInformationOfChargeableEnergyStoreSubsystem> getListOfTemperatureInformationOfChargeableEnergyStoreSubsystem() const;

    void setListOfTemperatureInformationOfChargeableEnergyStoreSubsystem(const std::shared_ptr<ListOfTemperatureInformationOfChargeableEnergyStoreSubsystem> &value);

private:
    std::shared_ptr<BYTE_GBT> quantityOfChargeableEnergyStoreSubsystem;
    std::shared_ptr<ListOfTemperatureInformationOfChargeableEnergyStoreSubsystem> listOfTemperatureInformationOfChargeableEnergyStoreSubsystem;
};

class RealTimeReportingPacket : public GBTSerializable
{
public:
    RealTimeReportingPacket();
    void addChildField();
    std::string toString();

    std::shared_ptr<ChinaTimePacket> getDataAcquisitionTime() const;

    uint8_t getCompleteVehicleDataTypeMark() const;
    void setCompleteVehicleDataTypeMark(const uint8_t &value);

    std::shared_ptr<CompleteVehicleDataPacket> getCompleteVehicleDataPacket() const;

    uint8_t getElectricMachineDataTypeMark() const;
    void setElectricMachineDataTypeMark(const uint8_t &value);

    std::shared_ptr<ElectricMachineDataPacket> getElectricMachineDataPacket() const;

    uint8_t getFuelCellDataTypeMark() const;
    void setFuelCellDataTypeMark(const uint8_t &value);

    std::shared_ptr<FuelCellDataPacket> getFuelCellDataPacket() const;

    uint8_t getDataOfEngineTypeMark() const;
    void setDataOfEngineTypeMark(const uint8_t &value);

    std::shared_ptr<DataOfEnginePacket> getDataOfEnginePacket() const;

    uint8_t getGPSDataTypeMark() const;
    void setGPSDataTypeMark(const uint8_t &value);

    std::shared_ptr<GPSDataPacket> getGpsDataPacket() const;

    uint8_t getLimitValueDataTypeMark() const;
    void setLimitValueDataTypeMark(const uint8_t &value);

    std::shared_ptr<LimitValueDataPacket> getLimitValueDataPacket() const;

    uint8_t getWarningDataTypeMark() const;
    void setWarningDataTypeMark(const uint8_t &value);

    std::shared_ptr<WarningDataPacket> getWarningDataPacket() const;

    std::shared_ptr<VoltageDataOfChargeableEnergyStoreSubsystem> getVoltageDataOfChargeableEnergyStoreSubsystem() const;

    uint8_t getVoltageDataOfChargeableEnergyStoreSubsystemTypeMark() const;
    void setVoltageDataOfChargeableEnergyStoreSubsystemTypeMark(const uint8_t &value);

    uint8_t getTemperatureDataOfChargeableEnergyStoreSubsystemTypeMark() const;
    void setTemperatureDataOfChargeableEnergyStoreSubsystemTypeMark(const uint8_t &value);

    std::shared_ptr<TemperatureDataOfChargeableEnergyStoreSubsystem> getTemperatureDataOfChargeableEnergyStoreSubsystem() const;

    void setCompleteVehicleDataPacket(const std::shared_ptr<CompleteVehicleDataPacket> &value);

    void setElectricMachineDataPacket(const std::shared_ptr<ElectricMachineDataPacket> &value);

    void setFuelCellDataPacket(const std::shared_ptr<FuelCellDataPacket> &value);

    void setDataOfEnginePacket(const std::shared_ptr<DataOfEnginePacket> &value);

    void setGpsDataPacket(const std::shared_ptr<GPSDataPacket> &value);

    void setLimitValueDataPacket(const std::shared_ptr<LimitValueDataPacket> &value);

    void setWarningDataPacket(const std::shared_ptr<WarningDataPacket> &value);

    void setVoltageDataOfChargeableEnergyStoreSubsystem(const std::shared_ptr<VoltageDataOfChargeableEnergyStoreSubsystem> &value);

    void setTemperatureDataOfChargeableEnergyStoreSubsystem(const std::shared_ptr<TemperatureDataOfChargeableEnergyStoreSubsystem> &value);

    void setDataAcquisitionTime(const std::shared_ptr<ChinaTimePacket> &value);

private:
    std::shared_ptr<ChinaTimePacket> dataAcquisitionTime;
    std::shared_ptr<BYTE_GBT> completeVehicleDataTypeMark;
    std::shared_ptr<CompleteVehicleDataPacket> completeVehicleDataPacket;
    std::shared_ptr<BYTE_GBT> electricMachineDataTypeMark;
    std::shared_ptr<ElectricMachineDataPacket> electricMachineDataPacket;
    std::shared_ptr<BYTE_GBT> fuelCellDataTypeMark;
    std::shared_ptr<FuelCellDataPacket> fuelCellDataPacket;
    std::shared_ptr<BYTE_GBT> dataOfEngineTypeMark;
    std::shared_ptr<DataOfEnginePacket> dataOfEnginePacket;
    std::shared_ptr<BYTE_GBT> gpsDataTypeMark;
    std::shared_ptr<GPSDataPacket> gpsDataPacket;
    std::shared_ptr<BYTE_GBT> limitValueDataTypeMark;
    std::shared_ptr<LimitValueDataPacket> limitValueDataPacket;
    std::shared_ptr<BYTE_GBT> warningDataTypeMark;
    std::shared_ptr<WarningDataPacket> warningDataPacket;
    std::shared_ptr<BYTE_GBT> voltageDataOfChargeableEnergyStoreSubsystemTypeMark;
    std::shared_ptr<VoltageDataOfChargeableEnergyStoreSubsystem> voltageDataOfChargeableEnergyStoreSubsystem;
    std::shared_ptr<BYTE_GBT> temperatureDataOfChargeableEnergyStoreSubsystemTypeMark;
    std::shared_ptr<TemperatureDataOfChargeableEnergyStoreSubsystem> temperatureDataOfChargeableEnergyStoreSubsystem;
};

class VehicleRealtimeDataPackage : public GBTSerializable
{
public:
    VehicleRealtimeDataPackage();
    void addChildField();
    std::string toString();

    std::shared_ptr<DataHeaderPacket> getHeader() const;

    uint16_t getDataUnitLength() const;
    void setDataUnitLength(const uint16_t &value);

    std::shared_ptr<RealTimeReportingPacket> getRealtimeData() const;

    uint8_t getCheckCode() const;
    void setCheckCode(const uint8_t &value);

    void setRealtimeData(const std::shared_ptr<RealTimeReportingPacket> &value);

private:
    std::shared_ptr<DataHeaderPacket> header;
    std::shared_ptr<WORD_GBT> dataUnitLength;
    std::shared_ptr<RealTimeReportingPacket> realtimeData;
    std::shared_ptr<BYTE_GBT> checkCode;
};

class VehicleLogoutPacket : public GBTSerializable
{
public:
    VehicleLogoutPacket();
    void addChildField();
    std::string toString();

    std::shared_ptr<ChinaTimePacket> getLogoutTime() const;

    uint16_t getLogoutSN() const;
    void setLogoutSN(const uint16_t &value);

private:
    std::shared_ptr<ChinaTimePacket> logoutTime;
    std::shared_ptr<WORD_GBT> logoutSN;
};

class VehicleLogoutDataPackage : public GBTSerializable
{
public:
    VehicleLogoutDataPackage();
    void addChildField();
    std::string toString();

    std::shared_ptr<DataHeaderPacket> getHeader() const;

    uint16_t getDataUnitLength() const;
    void setDataUnitLength(const uint16_t &value);

    std::shared_ptr<VehicleLogoutPacket> getLogoutData() const;

    uint8_t getCheckCode() const;
    void setCheckCode(const uint8_t &value);

private:
    std::shared_ptr<DataHeaderPacket> header;
    std::shared_ptr<WORD_GBT> dataUnitLength;
    std::shared_ptr<VehicleLogoutPacket> logoutData;
    std::shared_ptr<BYTE_GBT> checkCode;
};

class VehicleTimingPacket : public GBTSerializable
{
public:
    VehicleTimingPacket();
    void addChildField();
    std::string toString();

    std::shared_ptr<ChinaTimePacket> getGBTTime() const;

private:
    std::shared_ptr<ChinaTimePacket> gbtTime;
};

class VehicleTimingDataPackage : public GBTSerializable
{
public:
    VehicleTimingDataPackage();
    void addChildField();
    std::string toString();

    std::shared_ptr<DataHeaderPacket> getHeader() const;

    uint16_t getDataUnitLength() const;
    void setDataUnitLength(const uint16_t &value);

    std::shared_ptr<VehicleTimingPacket> getTimingData() const;

    uint8_t getCheckCode() const;
    void setCheckCode(const uint8_t &value);

private:
    std::shared_ptr<DataHeaderPacket> header;
    std::shared_ptr<WORD_GBT> dataUnitLength;
    std::shared_ptr<VehicleTimingPacket> timingData;
    std::shared_ptr<BYTE_GBT> checkCode;
};

class ParameterItem : public GBTSerializable
{
public:
    ParameterItem();
    void addChildField();
    std::string toString();

    bool deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos);

    uint8_t getParameterID() const;
    void setParameterID(const uint8_t &value);

    uint8_t getByteTypeField() const;
    void setByteTypeField(const uint8_t &value);

    uint16_t getWordTypeField() const;
    void setWordTypeField(const uint16_t &value);

    std::string getByteArrayField() const;
    void setByteArrayField(const std::string &value);

private:
    std::shared_ptr<BYTE_GBT> parameterID;
    std::shared_ptr<BYTE_GBT> byteTypeField;
    std::shared_ptr<WORD_GBT> wordTypeField;
    std::shared_ptr<GBTListOfItem<BYTE_GBT>> byteArrayField;
};

class ParameterQueryDownlinkPackage : public GBTSerializable
{
public:
    ParameterQueryDownlinkPackage();
    void addChildField();
    std::string toString();

    bool deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos);

    std::shared_ptr<ChinaTimePacket> getTimeOfParameterQuery() const;

    uint8_t getTotalNumberOfParameter() const;
    void setTotalNumberOfParameter(const uint8_t &value);

    std::shared_ptr<GBTListOfItem<BYTE_GBT>> getParameterID() const;

private:
    std::shared_ptr<ChinaTimePacket> timeOfParameterQuery;
    std::shared_ptr<BYTE_GBT> totalNumberOfParameter;
    std::shared_ptr<GBTListOfItem<BYTE_GBT>> parameterId;
};

class ParameterQueryDownlinkDataPackage : public GBTSerializable
{
public:
    ParameterQueryDownlinkDataPackage();
    void addChildField();
    std::string toString();

    std::shared_ptr<DataHeaderPacket> getHeader() const;

    uint16_t getDataUnitLength() const;
    void setDataUnitLength(const uint16_t &value);

    std::shared_ptr<ParameterQueryDownlinkPackage> getParameterQueryData() const;

    uint8_t getCheckCode() const;
    void setCheckCode(const uint8_t &value);

private:
    std::shared_ptr<DataHeaderPacket> header;
    std::shared_ptr<WORD_GBT> dataUnitLength;
    std::shared_ptr<ParameterQueryDownlinkPackage> parameterQueryData;
    std::shared_ptr<BYTE_GBT> checkCode;
};

class ParameterQueryUplinkPackage : public GBTSerializable
{
public:
    ParameterQueryUplinkPackage();
    void addChildField();
    std::string toString();

    bool deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos);

    std::shared_ptr<ChinaTimePacket> getReturnTimeOfParameterQuery() const;

    uint8_t getTotalNumberOfReturnParameter() const;
    void setTotalNumberOfReturnParameter(const uint8_t &value);

    std::shared_ptr<ListOfParameterItem> getListOfParameterItem() const;

private:
    std::shared_ptr<ChinaTimePacket> returnTimeOfParameterQuery;
    std::shared_ptr<BYTE_GBT> totalNumberOfReturnParameter;
    std::shared_ptr<ListOfParameterItem> listOfParameterItem;
};

class ParameterQueryUplinkDataPackage : public GBTSerializable
{
public:
    ParameterQueryUplinkDataPackage();
    void addChildField();
    std::string toString();

    std::shared_ptr<DataHeaderPacket> getHeader() const;
    void setHeader(std::shared_ptr<DataHeaderPacket> value);

    uint16_t getDataUnitLength() const;
    void setDataUnitLength(const uint16_t &value);

    std::shared_ptr<ParameterQueryUplinkPackage> getParameterQueryData() const;

    uint8_t getCheckCode() const;
    void setCheckCode(const uint8_t &value);

private:
    std::shared_ptr<DataHeaderPacket> header;
    std::shared_ptr<WORD_GBT> dataUnitLength;
    std::shared_ptr<ParameterQueryUplinkPackage> parameterQueryData;
    std::shared_ptr<BYTE_GBT> checkCode;
};

class ParameterSettingItem : public GBTSerializable
{
public:
    ParameterSettingItem();
    void addChildField();
    std::string toString();

    bool deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos);

    uint8_t getTotalNumberOfParameter() const;
    void setTotalNumberOfParameter(const uint8_t &value);

    std::shared_ptr<ListOfParameterItem> getListOfParameterItem() const;
    void setListOfParameterItem(const std::shared_ptr<ListOfParameterItem> &listInputItem);

private:
    std::shared_ptr<BYTE_GBT> totalNumberOfParameter;
    std::shared_ptr<ListOfParameterItem> listOfParameterItem;
};

class ParameterSettingPackage : public GBTSerializable
{
public:
    ParameterSettingPackage();
    void addChildField();
    std::string toString();

    std::shared_ptr<ChinaTimePacket> getTimeOfParameterSetting() const;

    std::shared_ptr<ParameterSettingItem> getListOfParameterItem() const;
    void setListOfParameterItem(const std::shared_ptr<ParameterSettingItem> &value);

private:
    std::shared_ptr<ChinaTimePacket> timeOfParameterSetting;
    std::shared_ptr<ParameterSettingItem> listOfParameterItem;
};

class ParameterSettingDataPackage : public GBTSerializable
{
public:
    ParameterSettingDataPackage();
    void addChildField();
    std::string toString();

    std::shared_ptr<DataHeaderPacket> getHeader() const;

    uint16_t getDataUnitLength() const;
    void setDataUnitLength(const uint16_t &value);

    std::shared_ptr<ParameterSettingPackage> getParameterSettingPackage() const;

    uint8_t getCheckCode() const;
    void setCheckCode(const uint8_t &value);

private:
    std::shared_ptr<DataHeaderPacket> header;
    std::shared_ptr<WORD_GBT> dataUnitLength;
    std::shared_ptr<ParameterSettingPackage> parameterSettingPackage;
    std::shared_ptr<BYTE_GBT> checkCode;
};

class TerminalControlItem : public GBTSerializable
{
public:
    TerminalControlItem();
    void addChildField();
    std::string toString();

    bool deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos);

    uint8_t getCommandId() const;
    void setCommandId(const uint8_t &value);

    std::shared_ptr<GBTListOfItem<BYTE_GBT>> getRemoteUpgradingUrl() const;
    void setRemoteUpgradingUrl(const std::shared_ptr<GBTListOfItem<BYTE_GBT>> &value);

    uint8_t getWarningLevel() const;
    void setWarningLevel(const uint8_t &value);

private:
    std::shared_ptr<BYTE_GBT> commandId;
    std::shared_ptr<GBTListOfItem<BYTE_GBT>> remoteUpgradingUrl;
    std::shared_ptr<BYTE_GBT> warningLevel;
};

class VehicleTerminalControl : public GBTSerializable
{
public:
    VehicleTerminalControl();
    void addChildField();
    std::string toString();

    std::shared_ptr<ChinaTimePacket> getTime() const;

    std::shared_ptr<TerminalControlItem> getTerminalItem();
    void setTerminalItem(const std::shared_ptr<TerminalControlItem> &value);

private:
    std::shared_ptr<ChinaTimePacket> time;
    std::shared_ptr<TerminalControlItem> terminalItem;
};

class VehicleTerminalControlDataPackage : public GBTSerializable
{
public:
    VehicleTerminalControlDataPackage();
    void addChildField();
    std::string toString();

    std::shared_ptr<DataHeaderPacket> getHeader() const;

    uint16_t getDataUnitLength() const;
    void setDataUnitLength(const uint16_t &value);

    std::shared_ptr<VehicleTerminalControl> getVehicleTerminalControl() const;

    uint8_t getCheckCode() const;
    void setCheckCode(const uint8_t &value);

private:
    std::shared_ptr<DataHeaderPacket> header;
    std::shared_ptr<WORD_GBT> dataUnitLength;
    std::shared_ptr<VehicleTerminalControl> vehicleTerminalControl;
    std::shared_ptr<BYTE_GBT> checkCode;
};

class HeartbeatDataPackage : public GBTSerializable
{
public:
    HeartbeatDataPackage();
    void addChildField();
    std::string toString();

    std::shared_ptr<DataHeaderPacket> getHeader() const;

    uint16_t getDataUnitLength() const;
    void setDataUnitLength(const uint16_t &value);

    uint8_t getCheckCode() const;
    void setCheckCode(const uint8_t &value);

private:
    std::shared_ptr<DataHeaderPacket> header;
    std::shared_ptr<WORD_GBT> dataUnitLength;
    std::shared_ptr<BYTE_GBT> checkCode;
};

class TerminalTimingDownlinkDataPackage : public GBTSerializable
{
public:
    TerminalTimingDownlinkDataPackage();
    void addChildField();
    std::string toString();

    std::shared_ptr<DataHeaderPacket> getHeader() const;

    uint16_t getDataUnitLength() const;
    void setDataUnitLength(const uint16_t &value);

    uint8_t getCheckCode() const;
    void setCheckCode(const uint8_t &value);

    std::shared_ptr<ChinaTimePacket> getTime() const;

private:
    std::shared_ptr<DataHeaderPacket> header;
    std::shared_ptr<WORD_GBT> dataUnitLength;
    std::shared_ptr<ChinaTimePacket> time;
    std::shared_ptr<BYTE_GBT> checkCode;
};

class AcknowledgeDataPackage : public GBTSerializable
{
public:
    AcknowledgeDataPackage();
    void addChildField();
    std::string toString();

    bool deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos);

    std::shared_ptr<DataHeaderPacket> getHeader() const;

    uint16_t getDataUnitLength() const;
    void setDataUnitLength(const uint16_t &value);

    uint8_t getCheckCode() const;
    void setCheckCode(const uint8_t &value);

    std::shared_ptr<GBTListOfItem<BYTE_GBT>> getDataUnit() const;

private:
    std::shared_ptr<DataHeaderPacket> header;
    std::shared_ptr<WORD_GBT> dataUnitLength;
    std::shared_ptr<GBTListOfItem<BYTE_GBT>> dataUnit;
    std::shared_ptr<BYTE_GBT> checkCode;
};

#endif // GBTTRANSPORTDATA_H
