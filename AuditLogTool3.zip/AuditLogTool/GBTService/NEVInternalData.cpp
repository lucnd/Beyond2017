#include <cmath>
#include "NEVInternalData.h"

NEVInternalData::NEVInternalData()
{
    cnevDnsLength = 0;
    bitDnsLength = 0;
}

int NEVInternalData::getCnevDnsLength() const
{
    return cnevDnsLength;
}

void NEVInternalData::setCnevDnsLength(int value)
{
    cnevDnsLength = value;
}

int NEVInternalData::getBitDnsLength() const
{
    return bitDnsLength;
}

void NEVInternalData::setBitDnsLength(int value)
{
    bitDnsLength = value;
}

