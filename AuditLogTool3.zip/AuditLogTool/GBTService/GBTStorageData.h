#ifndef GBTSTORAGEDATA_H
#define GBTSTORAGEDATA_H
#include "GBTTransportData.h"

class CellVoltageStorageData : public GBTSerializable
{
public:
    CellVoltageStorageData();
    void addChildField();
    std::string toString();
    bool deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos);

    uint16_t getTotalNumberOfCell() const;
    void setTotalNumberOfCell(const uint16_t &value);

    std::shared_ptr<VoltageOfCellList> getVoltageOfCellList() const;

    void setVoltageOfCellList(const std::shared_ptr<VoltageOfCellList> &value);

    uint16_t getTotalVoltage() const;
    void setTotalVoltage(const uint16_t &value);

    uint16_t getTotalCurrent() const;
    void setTotalCurrent(const uint16_t &value);

    uint8_t getParallelCellsNum() const;
    void setParallelCellsNum(const uint8_t &value);

private:
    std::shared_ptr<WORD_GBT> totalVoltage;
    std::shared_ptr<WORD_GBT> totalCurrent;
    std::shared_ptr<WORD_GBT> totalNumberOfCell;
    std::shared_ptr<BYTE_GBT> parallelCellsNum;
    std::shared_ptr<VoltageOfCellList> voltageOfCellList;
};

class TemperatureStorageData : public GBTSerializable
{
public:
    TemperatureStorageData();
    void addChildField();
    std::string toString();
    bool deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos);

    uint16_t getTempProbeCount() const;
    void setTempProbeCount(const uint16_t &value);

    std::shared_ptr<TemperatureValueList> getTemperatureValueList() const;

    void setTemperatureValueList(const std::shared_ptr<TemperatureValueList> &value);

private:
    std::shared_ptr<WORD_GBT> tempProbeCount;
    std::shared_ptr<TemperatureValueList> temperatureValueList;
};

class GBTStorageData : public GBTSerializable
{
public:
    GBTStorageData();
    void addChildField();
    std::string toString();

    std::shared_ptr<ChinaTimePacket> getDataAcquisitionTime() const;

    std::shared_ptr<CompleteVehicleDataPacket> getCompleteVehicleData() const;

    std::shared_ptr<ElectricMachineDataPacket> getElectricMachineData() const;

    std::shared_ptr<DataOfEnginePacket> getDataOfEngine() const;

    std::shared_ptr<GPSDataPacket> getGpsData() const;

    std::shared_ptr<LimitValueDataPacket> getLimitValueData() const;

    std::shared_ptr<WarningDataPacket> getWarningData() const;

    std::shared_ptr<CellVoltageStorageData> getCellVoltageData() const;

    std::shared_ptr<TemperatureStorageData> getTemperatureData() const;

    void setDataAcquisitionTime(const std::shared_ptr<ChinaTimePacket> &value);

    void setCompleteVehicleData(const std::shared_ptr<CompleteVehicleDataPacket> &value);

    void setElectricMachineData(const std::shared_ptr<ElectricMachineDataPacket> &value);

    void setDataOfEngine(const std::shared_ptr<DataOfEnginePacket> &value);

    void setGpsData(const std::shared_ptr<GPSDataPacket> &value);

    void setLimitValueData(const std::shared_ptr<LimitValueDataPacket> &value);

    void setWarningData(const std::shared_ptr<WarningDataPacket> &value);

    void setCellVoltageData(const std::shared_ptr<CellVoltageStorageData> &value);

    void setTemperatureData(const std::shared_ptr<TemperatureStorageData> &value);

private:
    std::shared_ptr<ChinaTimePacket> dataAcquisitionTime;
    std::shared_ptr<CompleteVehicleDataPacket> completeVehicleData;
    std::shared_ptr<ElectricMachineDataPacket> electricMachineData;
    std::shared_ptr<DataOfEnginePacket> dataOfEngine;
    std::shared_ptr<GPSDataPacket> gpsData;
    std::shared_ptr<LimitValueDataPacket> limitValueData;
    std::shared_ptr<WarningDataPacket> warningData;
    std::shared_ptr<CellVoltageStorageData> cellVoltageData;
    std::shared_ptr<TemperatureStorageData> temperatureData;
};

#endif // GBTSTORAGEDATA_H
