#include "MainWindow.h"
#include "ui_MainWindow.h"
#include "GBTService/GBTTransportData.h"
#include "Utils/GBTUtil.h"
#include "FileStore/FileStore.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_btnDecode_clicked()
{
    std::string dataStr = ui->txtHexInput->toPlainText ().toStdString();
    uint8_t data[2000];
    GBTUtil::hex2Bin(dataStr.c_str(), data);
    int dataLength = dataStr.length()/2;
    std::vector<uint8_t> buf(data, data + dataLength);

    if(!isRawMsgValid(buf))
    {
        ui->txtDecodeMsg->setPlainText("BCC of hex message is invalid!");
        return;
    }

    std::string decodeStr = toDecodeString(buf);
    std::string formatStr = GBTUtil::toFormatString(decodeStr);
    ui->txtDecodeMsg->setPlainText(QString::fromStdString(formatStr));
}

bool MainWindow::isRawMsgValid(std::vector<uint8_t> buf)
{
    uint8_t bcc = GBTUtil::calculateBCC(&buf[0] + 2, buf.size () - 3);
    if (buf[buf.size () - 1] != bcc)
    {
        return false;
    }
    return true;
}

std::string MainWindow::toDecodeString(std::vector<uint8_t> buf)
{
    int commandUnit = buf[2];
    std::string decodeStr = "";
    switch (commandUnit)
    {
    case LOGIN_MESSAGE:
    {
        decodeStr = toLoginStr (buf);
        break;
    }
    case REALTIME_REPORT_MESSAGE:
    {
        decodeStr = toRealtimeReportStr (buf);
        break;
    }
    case SUPLEMENTARY_MESSAGE:
    {
        decodeStr = toSupplementStr (buf);
        break;
    }
    case LOGOUT_MESSAGE:
    {
        decodeStr = toLogoutStr (buf);
        break;
    }
    case HEARTBEAT_MESSAGE:
    {
        decodeStr = toHeatbeatStr (buf);
        break;
    }
    case TERMINAL_TIMING:
    {
        decodeStr = toTerminalTimingStr (buf);
        break;
    }
    case QUERY_MESSAGE:
    {
        decodeStr = toQueryDataStr (buf);
        break;
    }
    case SETTING_MESSAGE:
    {
        decodeStr = toSettingDataStr (buf);
        break;
    }
    case TERMINAL_CONTROL:
    {
        decodeStr = toTerminalControlStr(buf);
        break;
    }
    default:
        break;
    }

    return decodeStr;
}

std::string MainWindow::toLoginStr(std::vector<uint8_t> buf)
{
    std::string dataStr = "login data decode error.";
    std::shared_ptr<VehicleLoginDataPackage> loginData = std::make_shared<VehicleLoginDataPackage>();
    loginData->makeSerializeStruct();
    //printf("size: %d", loginData->getCurSize());
    bool ret = loginData->deserialize(buf, 0);
    if (ret)
    {
        dataStr = loginData->toString();
    }
    return dataStr;
}

std::string MainWindow::toRealtimeReportStr(std::vector<uint8_t> buf)
{
    std::string dataStr = "realtime data decode error.";
    std::shared_ptr<VehicleRealtimeDataPackage> realtimeData = std::make_shared<VehicleRealtimeDataPackage>();
    realtimeData->makeSerializeStruct();
    //printf("size: %d", realtimeData->getCurSize());
    bool ret = realtimeData->deserialize(buf, 0);
    if (ret)
    {
        dataStr = realtimeData->toString();
    }
    return dataStr;
}

std::string MainWindow::toSupplementStr(std::vector<uint8_t> buf)
{
    std::string dataStr = "realtime data decode error.";
    std::shared_ptr<VehicleRealtimeDataPackage> realtimeData = std::make_shared<VehicleRealtimeDataPackage>();
    realtimeData->getHeader ()->setCommandIdentification (0x03);
    realtimeData->makeSerializeStruct();
    //printf("size: %d", realtimeData->getCurSize());
    bool ret = realtimeData->deserialize(buf, 0);
    if (ret)
    {
        dataStr = realtimeData->toString();
    }
    return dataStr;
}

std::string MainWindow::toLogoutStr(std::vector<uint8_t> buf)
{
    std::string dataStr = "logout data decode error.";
    std::shared_ptr<VehicleLogoutDataPackage> logoutData = std::make_shared<VehicleLogoutDataPackage>();
    logoutData->makeSerializeStruct();
    //printf("size: %d", logoutData->getCurSize());
    bool ret = logoutData->deserialize(buf, 0);
    if (ret)
    {
        dataStr = logoutData->toString();
    }
    return dataStr;
}

std::string MainWindow::toHeatbeatStr(std::vector<uint8_t> buf)
{
    std::string dataStr = "heartbeat data decode error.";
    std::shared_ptr<HeartbeatDataPackage> heartbeatData = std::make_shared<HeartbeatDataPackage>();
    heartbeatData->makeSerializeStruct();
    //printf("size: %d", heartbeatData->getCurSize());
    bool ret = heartbeatData->deserialize(buf, 0);
    if (ret)
    {
        dataStr = heartbeatData->toString();
    }
    return dataStr;
}

std::string MainWindow::toTerminalTimingStr(std::vector<uint8_t> buf)
{
    std::string dataStr = "timing data decode error.";
    std::shared_ptr<VehicleTimingDataPackage> timingData = std::make_shared<VehicleTimingDataPackage>();
    timingData->makeSerializeStruct();
    //printf("size: %d", timingData->getCurSize());
    bool ret = timingData->deserialize(buf, 0);
    if (ret)
    {
        dataStr = timingData->toString();
    }
    return dataStr;
}

std::string MainWindow::toQueryDataStr(std::vector<uint8_t> buf)
{
    std::string dataStr = "query data decode error.";
    if (buf[3] == 0xfe)
    {
        std::shared_ptr<ParameterQueryDownlinkDataPackage> queryDownlink = std::make_shared<ParameterQueryDownlinkDataPackage>();
        queryDownlink->makeSerializeStruct();
        //printf("size: %d", queryDownlink->getCurSize());
        bool ret = queryDownlink->deserialize(buf, 0);
        if (ret)
        {
            dataStr = queryDownlink->toString();
        }
        return dataStr;
    }
    else
    {
        std::shared_ptr<ParameterQueryUplinkDataPackage> queryUplink = std::make_shared<ParameterQueryUplinkDataPackage>();
        queryUplink->makeSerializeStruct();
        //printf("size: %d", queryUplink->getCurSize());
        bool ret = queryUplink->deserialize(buf, 0);
        if (ret)
        {
            dataStr = queryUplink->toString();
        }
        return dataStr;
    }
}

std::string MainWindow::toSettingDataStr(std::vector<uint8_t> buf)
{
    std::string dataStr = "setting data decode error.";
    std::shared_ptr<ParameterSettingDataPackage> settingDownlink = std::make_shared<ParameterSettingDataPackage>();
    settingDownlink->makeSerializeStruct();
    //printf("size: %d", settingDownlink->getCurSize());
    bool ret = settingDownlink->deserialize(buf, 0);
    if (ret)
    {
        dataStr = settingDownlink->toString();
    }
    return dataStr;
}

std::string MainWindow::toTerminalControlStr(std::vector<uint8_t> buf)
{
    std::string dataStr = "terminal control data decode error.";
    std::shared_ptr<VehicleTerminalControlDataPackage> terminalDownlink = std::make_shared<VehicleTerminalControlDataPackage>();
    terminalDownlink->makeSerializeStruct();
    //printf("size: %d", terminalDownlink->getCurSize());
    bool ret = terminalDownlink->deserialize(buf, 0);
    if (ret)
    {
        dataStr = terminalDownlink->toString();
    }
    return dataStr;
}

void MainWindow::on_pushButton_clicked()
{
    std::string currentDir = GBTUtil::getCurrentDir();
    std::string dataPath = currentDir + "/data/";
    if(!GBTUtil::isDirExist (dataPath))
    {
        GBTUtil::makeDir (dataPath);
    }
//    FileStore fileStore;
//    std::vector<std::string> fileList = fileStore.getListLogFiles ();
//    std::string str = "";
//    for (int i = 0; i < fileList.size (); i++)
//    {
//        str += fileList[i] + "\n";
//    }

    std::string dataStr = "";
    std::string output = "";
    std::string filePath = "C:\\Users\\aluc\\Downloads\\191105.log";
//    std::shared_ptr<FileStore> fileStore = std::make_shared<FileStore>(currentDir + "/data/190902.log");
    std::shared_ptr<FileStore> fileStore = std::make_shared<FileStore>(filePath);
    fileStore->getAllDataFromFile ();

    for (int i = 0; i < fileStore->getTotalMessageCount (); i++)
    {
        gbt_time_t time = fileStore->getTimeByIndex (i);
        std::string timeStr = "20"+ std::to_string (time.year)
                + "-" + std::to_string (time.month)
                +"-" + std::to_string (time.day)
                +" "+std::to_string (time.hour)
                +":"+std::to_string (time.minute)
                +":"+std::to_string (time.second);
        output += timeStr + "=============================================================================================\n\n";

        std::vector<uint8_t> buf = fileStore->getMessageByIndex (i);
        dataStr = GBTUtil::toHexString (&buf[0], buf.size ());
        output += dataStr + " \n\n\n";

    }

    ui->txtDecodeMsg->setPlainText(QString::fromStdString(output));
}
