#ifndef IBITFIELD_H
#define IBITFIELD_H
#include <stdint.h>
#include <string>

class IBitField
{
public:
    virtual void extractValue(uint64_t data, int bitOffset) {}
    virtual int getBitSize() { return 0; }
    virtual uint32_t getValue() { return 0; }
    virtual uint32_t getBitStructValue() { return 0; }
    virtual std::string toString() { return ""; }
};

#endif // IBITFIELD_H
