#ifndef ISERIALIZABLE_H
#define ISERIALIZABLE_H
#include <string>

class ISerializable
{
public:
    virtual bool serialize(std::vector<uint8_t> &buf, uint32_t offsetPos) { return true; }
    virtual bool deserialize(std::vector<uint8_t> &buf, uint32_t offsetPos) { return true; }
    virtual void makeSerializeStruct() {}
    virtual std::string toString() { return ""; }
    virtual uint32_t getCurSize() { return 0; }
};

#endif // ISERIALIZABLE_H
