#ifndef FILESTORE_H
#define FILESTORE_H
#include <vector>
#include <string>
#include <stdio.h>
#include <dirent.h>
#include <sys/types.h>
#include "../Utils/GBTUtil.h"

class FileStore
{
public:
    FileStore(std::string fileName);
    void getAllDataFromFile();
    int getFileSize(std::string fileName);
    int getTotalMessageCount();
    void eraseDataList();
    gbt_time_t getTimeFromRealtimeMessage(const std::vector<uint8_t> &buf);
    int getMessageIndexByTime(gbt_time_t gbtTime);
    std::vector<uint8_t> getMessageByIndex(int idx);
    gbt_time_t getTimeByIndex(int idx);

private:
    std::string fileName;
    std::vector<std::vector<uint8_t>> dataList;
    std::vector<gbt_time_t> timeList;
};

#endif // FILESTORE_H
