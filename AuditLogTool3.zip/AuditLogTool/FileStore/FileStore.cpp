#include "FileStore.h"
#include "NEVConstantData.h"
#include <fstream>


FileStore::FileStore(std::string fileName)
{
    this->fileName = fileName;
}

void FileStore::getAllDataFromFile()
{
    eraseDataList();
    printf ("%s()\n", __func__);
    std::ifstream is(fileName.c_str(), std::ifstream::binary);
    if (is)
    {
        uint32_t readIdx = 0;
        uint32_t fileSize = getFileSize(fileName.c_str());
        uint8_t lenBuf[2];
        while (readIdx < fileSize)
        {
            is.seekg(readIdx);
            is.read((char*)lenBuf, 2);
            int size = (int16_t)(lenBuf[0] | ((int16_t)lenBuf[1] << 8));

            std::vector<uint8_t> buf(size);
            is.read((char *)&buf[0], size);
            dataList.push_back (buf);
            timeList.push_back (getTimeFromRealtimeMessage (buf));

            readIdx += size + 2;
            printf ("readIdx: %d\n", readIdx);
        }

        is.close();
    }
}

int FileStore::getFileSize(std::string fileName)
{
    std::ifstream ifile(fileName.c_str (), std::ifstream::binary);
    ifile.seekg(0, ifile.end);
    int fileSize = ifile.tellg();
    ifile.seekg(0, ifile.beg);
    printf ("fileSize:%d\n", fileSize);
    return fileSize;
}

int FileStore::getTotalMessageCount()
{
    return dataList.size ();
}

void FileStore::eraseDataList()
{
    for (int i = dataList.size() - 1; i >= 0; i--)
    {
        for(int j = dataList[i].size () - 1; j >= 0; j--)
        {
            dataList[i].erase (dataList[i].begin () + j);
        }
        dataList.erase(dataList.begin() + i);
    }
}

gbt_time_t FileStore::getTimeFromRealtimeMessage(const std::vector<uint8_t> &buf)
{
    printf("%d-%d-%d %d:%d:%d\n", buf[24], buf[25], buf[26], buf[27], buf[28], buf[29]);
    gbt_time_t gbtTime;
    gbtTime.year = buf[24];
    gbtTime.month = buf[25];
    gbtTime.day = buf[26];
    gbtTime.hour = buf[27];
    gbtTime.minute = buf[28];
    gbtTime.second = buf[29];

    return gbtTime;
}

int FileStore::getMessageIndexByTime(gbt_time_t gbtTime)
{
    int timeValue = gbtTime.hour * 3600 + gbtTime.minute * 60 + gbtTime.second;
    int idx = 0;
    for(int i = 0; i < dataList.size (); i++)
    {
        int timeLog = timeList[i].hour * 3600 + timeList[i].minute * 60 + timeList[i].second;
        if(timeValue > timeLog)
        {
            idx ++;
        }
        else
        {
            break;
        }
    }
    return idx;
}

std::vector<uint8_t> FileStore::getMessageByIndex(int idx)
{
    return dataList[idx];
}

gbt_time_t FileStore::getTimeByIndex(int idx)
{
    return timeList[idx];
}
