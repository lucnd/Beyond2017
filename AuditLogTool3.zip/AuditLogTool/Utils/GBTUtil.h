#ifndef _GBT_UTIL_H_
#define _GBT_UTIL_H_
#include <iostream>
#include <string>
#include <sys/time.h>
#include <vector>
#include <cstdint>

#define MST (-7)
#define UTC (0)
#define CHN (8)

#define GALLON 4.54609188f
#define MILE 1.609344f

#define MAX_PRINT_LEN 500

struct gbt_time_t
{
    uint8_t year;
    uint8_t month;
    uint8_t day;
    uint8_t hour;
    uint8_t minute;
    uint8_t second;
};

enum Time_Provider
{
    GBT_PLATFORM = 0,
    GNSS,
    NITZ,
    VDC_LOCAL
};

class GBTUtil
{
public:
    GBTUtil();

    static void printHexMessage(char *buff, int length);
    static int readFile(char *fileName, char *buff, int targetsize);
    static int readFileConfig(char *fileName, std::string &ipAddress, int &port);
    static uint8_t calculateBCC(uint8_t *buf, int len);
    static void printTimestamp();
    static void fillTimestamp(char *buff, int length);
    static std::string toHexString(uint8_t val);
    static std::string toHexString(uint8_t *encodedBuf, int len);
    static std::string toCharString(uint8_t *encodedBuf, int len);
    static std::string toFormatString(std::string &msg);
    static void printBufferData(uint8_t *buf, int len);
    static void onInitUpdateLoginSerialNumber();
    static void onAckUpdateLoginSerialNumber();
    static int32_t getLoginSerialNumber();
    static void setLoginSerialNumber(int loginSN);
    static void increaseLoginSerialNumber();
    static void decreaseLoginSerialNumber();
    static time_t daySeconds();
    static int32_t getTimeStamp();
    static time_t getBeijingTime();
    static void updateDeltaTime(int sourceTime);

    static float convertMilePerGallonToLitrePer100Km(float value);
    static float convertMilePerLitreToLitrePer100Km(float value);
    static float convertKmPerLitreToLitrePer100Km(float value);

    static int hex2Int(char input);
    static void hex2Bin(const char *src, uint8_t *target);

    static uint8_t reverse_byte(uint8_t x);

    static void write_archive(const char *outname, const char *filename);

    static gbt_time_t getVDCDateTime();
    static gbt_time_t getGNSSDateTime(uint64_t gnssTimeData);
    static gbt_time_t getNITZDateTime(const std::string &nitz, int64_t nitzReceiveTime);
    static std::vector<std::string> split(const std::string &str, char seperator);
    static std::vector<std::string> split(const std::string &str, const std::string &separators);
    static bool is_number(const std::string &s);
    static uint64_t stoul(const std::string &s);
    static bool startsWith(const char *str, const char *prefix);

    static std::string getCurrentDir();
    static bool makeDir(std::string path);
    static bool isDirExist(std::string path);
};

#endif // _GBT_UTIL_H_
