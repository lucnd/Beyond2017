#define LOG_TAG "[NEV]GBTUtil"
//#include <Log.h>
#include <QCoreApplication>
#include <QDir>

#include <sstream>
#include <fstream>
#include <algorithm>
#include <cstring>
#include "GBTUtil.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <cstdlib>
#include <cstring>
#include <stdlib.h>     /* atoi */
#include <vector>

using namespace std;

int deltaTime = 28800; // default value delta time: 8 hours

GBTUtil::GBTUtil()
{
}

std::string GBTUtil::toHexString(uint8_t *encodedBuf, int len)
{
    ////printf("%s()", __func__);
    std::string str("");
    char tmpBuf[3];
    for (int i = 0; i < len; i++)
    {
        sprintf((char *)tmpBuf, "%02x", encodedBuf[i]);
        str.append(tmpBuf, 2);
    }
    return str;
}

std::string GBTUtil::toCharString(uint8_t *encodedBuf, int len)
{
    ////printf("%s()", __func__);
    std::string str("");
    char tmpBuf[3];
    for (int i = 0; i < len; i++)
    {
        sprintf((char *)tmpBuf, "%c", encodedBuf[i]);
        str.append(tmpBuf, 2);
    }
    return str;
}

std::string GBTUtil::toFormatString(std::string &msg)
{
    //printf("%s()", __func__);
    std::stringstream iss(msg);
    int spaceNum = 0;
    std::string formatStr = "";
    while (iss.good())
    {
        std::string singleLine;
        getline(iss, singleLine, '\n');
        // Process SingleLine here
        if (singleLine == "}")
        {
            spaceNum -= 1;
        }

        std::string spaceLine("");
        for (int i = 0; i < spaceNum; i++)
        {
            spaceLine += "  ";
        }
        spaceLine += singleLine + "\n";
        formatStr += spaceLine;
        ////printf("%s", spaceLine.c_str());
        if (singleLine == "{")
        {
            spaceNum += 1;
        }
    }
    return formatStr;
}

void GBTUtil::printBufferData(uint8_t *buf, int len)
{
    //printf("Buffer length: %d", len);
    int chunkNum = (len - 1) / MAX_PRINT_LEN + 1;
    int fromIdx = 0;
    int toIdx = MAX_PRINT_LEN - 1;
    int remainLen = len;
    uint8_t *bufPtr = buf;
    int bufPrintLen = 0;
    for (int i = 0; i < chunkNum; i++)
    {
        if (remainLen > MAX_PRINT_LEN)
        {
            remainLen -= MAX_PRINT_LEN;
            bufPrintLen = MAX_PRINT_LEN;
        }
        else
        {
            toIdx = len;
            bufPrintLen = remainLen;
        }
        std::string chunkStr = toHexString(bufPtr, bufPrintLen);
        //printf("[chunk][%d-%d]: %s", fromIdx, toIdx, chunkStr.c_str());
        fromIdx += bufPrintLen;
        toIdx += bufPrintLen;
        bufPtr += bufPrintLen;
    }
}

void GBTUtil::printHexMessage(char *buff, int length)
{
    //printf("%s()", __func__);
    std::string str = toHexString((uint8_t*)buff, length);
    //printf("%s", str.c_str());
}

int GBTUtil::readFile(char *fileName, char *buff, int targetsize)
{
    //printf("%s()", __func__);
    FILE *pFile = NULL;
    uint32_t rdLen = 0;

    pFile = fopen(fileName, "r");

    if (pFile != NULL)
    {
        int fs = fseek(pFile, 0L, SEEK_END);
        if (fs != 0)
        {
            //printf("File Seek to end Failed");
            fclose(pFile);
            return -1;
        }

        targetsize = ftell(pFile);
        if (targetsize < 0)
        {
            //printf("targetsize < 0");
            fclose(pFile);
            return -1;
        }

        //printf(" Message target file = [%d]\n", targetsize);

        //set to head
        fs = fseek(pFile, 0L, SEEK_SET);
        if (fs != 0)
        {
            //printf("File Seek to head Failed");
            fclose(pFile);
            return -1;
        }

        //rdLen = fread(packet, sizeof(packet) + 1, 1, pFile);
        rdLen = fread(buff, targetsize, 1, pFile);
        if (rdLen == 0)
        {
            //printf("Package Message() Error File Read\n");
        }
        else
        {
            //printf("#Package Message() status=[%d]\n", rdLen);
        }
        fclose(pFile);
    }
    else
    {
        //printf("ERROR to open read file\n");
    }
    return targetsize;
}

int GBTUtil::readFileConfig(char *fileName, std::string &ipAddress, int &port)
{

    char buff[1024];
    std::string bufStr;
    int targetsize;
    FILE *pFile = NULL;
    uint32_t rdLen = 0;

    pFile = fopen(fileName, "r");

    if (pFile != NULL)
    {
        int fs = fseek(pFile, 0L, SEEK_END);
        if (fs != 0)
        {
            //printf("File Seek to end Failed");
            fclose(pFile);
            return -1;
        }

        targetsize = ftell(pFile);
        if (targetsize < 0)
        {
            //printf("targetsize < 0");
            fclose(pFile);
            return -1;
        }

        //printf("Message target file = [%d]\n", targetsize);

        //set to head
        fs = fseek(pFile, 0L, SEEK_SET);
        if (fs != 0)
        {
            //printf("File Seek to head Failed");
            fclose(pFile);
            return -1;
        }

        //rdLen = fread(packet, sizeof(packet) + 1, 1, pFile);
        if (targetsize > 1024)
        {
            //printf("Buffer is not correct");
            fclose(pFile);
            return -1;
        }

        rdLen = fread(buff, targetsize, 1, pFile);
        if (rdLen == 0)
        {
            //printf("Config Error File Read");
            fclose(pFile);
            return -1;
        }
        else
        {
            //printf("Config Ok with length=[%d]\n", rdLen);
            std::istringstream is_file(bufStr);

            std::string line;
            while (std::getline(is_file, line))
            {
                std::istringstream is_line(line);
                std::string key;
                if (std::getline(is_line, key, '='))
                {
                    if (key == "port")
                    {

                        std::string value;
                        if (std::getline(is_line, value))
                        {
                            //store_line(key, value);
                            int configPort = atoi(value.c_str());
                            //printf("port: port=%d", port);
                            port = configPort;
                        }
                    }
                    if (key == "ip")
                    {

                        std::string value;
                        if (std::getline(is_line, value))
                        {
                            //store_line(key, value);

                            //printf("IpAddress = %s", value.c_str());
                            value.erase(std::remove(value.begin(), value.end(), '\n'), value.end());
                            ipAddress = value;
                        }
                    }
                }
            }
        }
        fclose(pFile);
    }
    return 0;
}

void GBTUtil::fillTimestamp(char *buff, int length)
{
    //printf("%s()", __func__);
    // get time
    time_t timer;
    struct gbt_time_t mytime;

    time(&timer);                              /* get current time */
    timer += 28800;                            // add 8 hours (GMT+8) for Beijing time
    const struct tm *norm = localtime(&timer); // Convert timer

    mytime.year = norm->tm_year - 100;
    mytime.month = norm->tm_mon + 1;

    mytime.day = norm->tm_mday;
    mytime.hour = norm->tm_hour;

    mytime.minute = norm->tm_min;
    mytime.second = norm->tm_sec;

    memcpy(&buff[24], &mytime, sizeof(mytime));

    // debug   //printf ("\n//printfn message with  timestamp  YY/MM/DD HH:MM:SS  %d/%d/%d %02d:%02d:%02d \n", buff[24], buff[25], buff[26], buff[27], buff[28], buff[29]);

    uint8_t bcc = calculateBCC((uint8_t *)buff + 2, length - 1);

    buff[length - 1] = bcc;

    //printf("//printfn message with BCC = [%X]", buff[length - 1] & 0xff);
}

std::string GBTUtil::toHexString(uint8_t val)
{
    std::string str("");
    char tmpBuf[3];
    sprintf((char *)tmpBuf, "%02x", val);
    str.append(tmpBuf, 2);
    return str;
}

void GBTUtil::printTimestamp()
{
    //printf("%s()", __func__);
    // get time
    time_t timer;
    struct gbt_time_t mytime;

    time(&timer);                              /* get current time */
    timer += 28800;                            // add 8 hours (GMT+8) for Beijing time
    const struct tm *norm = localtime(&timer); // Convert timer

    mytime.year = norm->tm_year - 100;
    mytime.month = norm->tm_mon + 1;

    mytime.day = norm->tm_mday;
    mytime.hour = norm->tm_hour;

    mytime.minute = norm->tm_min;
    mytime.second = norm->tm_sec;

    //printf("GBT message with  timestamp  YY/MM/DD HH:MM:SS  %d/%d/%d %02d:%02d:%02d \n", mytime.year, mytime.month, mytime.day, mytime.hour, mytime.minute, mytime.second);
}

uint8_t GBTUtil::calculateBCC(uint8_t *buf, int len)
{
    ////printf("%s()", __func__);
    uint8_t bcc = 0;
    for (int i = 0; i < len; i++)
    {
        bcc ^= buf[i];
    }
    return bcc;
}

time_t GBTUtil::daySeconds()
{
    time_t t1, t2;
    struct tm tms;
    time(&t1);
    localtime_r(&t1, &tms);
    tms.tm_hour = 0;
    tms.tm_min = 0;
    tms.tm_sec = 0;
    t2 = mktime(&tms);
    return t1 - t2;
}

int32_t GBTUtil::getTimeStamp()
{
    time_t timer;
    struct tm y2k = {0};
    int32_t seconds;
    y2k.tm_hour = 0;
    y2k.tm_min = 0;
    y2k.tm_sec = 0;
    y2k.tm_year = 100;
    y2k.tm_mon = 0;
    y2k.tm_mday = 1;

    time(&timer); //get current time; same as: timer = time(NULL)
    seconds = static_cast<int32_t>(difftime(timer, mktime(&y2k)));
    if (seconds < 0)
    {
        //printf("Wrong UTC time please reset UTC date time.");
        seconds = 0;
    }
    return seconds;
}

time_t GBTUtil::getBeijingTime()
{
    time_t timer;
    time(&timer);       /* get current time */
    timer += deltaTime; // add deltaTIme for Beijing time
    return timer;
}

void GBTUtil::updateDeltaTime(int sourceTime)
{
    //printf("%s() START deltaTime = %d, sourceTime=%d", __func__, deltaTime, sourceTime);
    time_t t1;
    //, t2;
    // struct tm tms;
    time(&t1);
    // localtime_r(&t1, &tms);
    // tms.tm_hour = 0;
    // tms.tm_min = 0;
    // tms.tm_sec = 0;
    //    t2 = mktime(&tms);
    //printf("%s() systemTime = %ld", __func__, (long)t1);
    deltaTime = t1 - sourceTime;

    //printf("%s() EXIT deltaTime = %d", __func__, deltaTime);
}

float GBTUtil::convertMilePerGallonToLitrePer100Km(float value)
{
    return (100.0 * GALLON / MILE / value);
}

float GBTUtil::convertMilePerLitreToLitrePer100Km(float value)
{
    return (100.0 / MILE / value);
}

float GBTUtil::convertKmPerLitreToLitrePer100Km(float value)
{
    return (100.0 / value);
}

int GBTUtil::hex2Int(char input)
{
    if (input >= '0' && input <= '9')
        return input - '0';
    if (input >= 'A' && input <= 'F')
        return input - 'A' + 10;
    if (input >= 'a' && input <= 'f')
        return input - 'a' + 10;
    return 0;
}

// This function assumes src to be a zero terminated sanitized string with
// an even number of [0-9a-f] characters, and target to be sufficiently large
void GBTUtil::hex2Bin(const char *src, uint8_t *target)
{
    while (*src && src[1])
    {
        *(target++) = hex2Int(*src) * 16 + hex2Int(src[1]);
        src += 2;
    }
}

uint8_t GBTUtil::reverse_byte(uint8_t x)
{
    const unsigned char table[] = {
        0x00,
        0x80,
        0x40,
        0xc0,
        0x20,
        0xa0,
        0x60,
        0xe0,
        0x10,
        0x90,
        0x50,
        0xd0,
        0x30,
        0xb0,
        0x70,
        0xf0,
        0x08,
        0x88,
        0x48,
        0xc8,
        0x28,
        0xa8,
        0x68,
        0xe8,
        0x18,
        0x98,
        0x58,
        0xd8,
        0x38,
        0xb8,
        0x78,
        0xf8,
        0x04,
        0x84,
        0x44,
        0xc4,
        0x24,
        0xa4,
        0x64,
        0xe4,
        0x14,
        0x94,
        0x54,
        0xd4,
        0x34,
        0xb4,
        0x74,
        0xf4,
        0x0c,
        0x8c,
        0x4c,
        0xcc,
        0x2c,
        0xac,
        0x6c,
        0xec,
        0x1c,
        0x9c,
        0x5c,
        0xdc,
        0x3c,
        0xbc,
        0x7c,
        0xfc,
        0x02,
        0x82,
        0x42,
        0xc2,
        0x22,
        0xa2,
        0x62,
        0xe2,
        0x12,
        0x92,
        0x52,
        0xd2,
        0x32,
        0xb2,
        0x72,
        0xf2,
        0x0a,
        0x8a,
        0x4a,
        0xca,
        0x2a,
        0xaa,
        0x6a,
        0xea,
        0x1a,
        0x9a,
        0x5a,
        0xda,
        0x3a,
        0xba,
        0x7a,
        0xfa,
        0x06,
        0x86,
        0x46,
        0xc6,
        0x26,
        0xa6,
        0x66,
        0xe6,
        0x16,
        0x96,
        0x56,
        0xd6,
        0x36,
        0xb6,
        0x76,
        0xf6,
        0x0e,
        0x8e,
        0x4e,
        0xce,
        0x2e,
        0xae,
        0x6e,
        0xee,
        0x1e,
        0x9e,
        0x5e,
        0xde,
        0x3e,
        0xbe,
        0x7e,
        0xfe,
        0x01,
        0x81,
        0x41,
        0xc1,
        0x21,
        0xa1,
        0x61,
        0xe1,
        0x11,
        0x91,
        0x51,
        0xd1,
        0x31,
        0xb1,
        0x71,
        0xf1,
        0x09,
        0x89,
        0x49,
        0xc9,
        0x29,
        0xa9,
        0x69,
        0xe9,
        0x19,
        0x99,
        0x59,
        0xd9,
        0x39,
        0xb9,
        0x79,
        0xf9,
        0x05,
        0x85,
        0x45,
        0xc5,
        0x25,
        0xa5,
        0x65,
        0xe5,
        0x15,
        0x95,
        0x55,
        0xd5,
        0x35,
        0xb5,
        0x75,
        0xf5,
        0x0d,
        0x8d,
        0x4d,
        0xcd,
        0x2d,
        0xad,
        0x6d,
        0xed,
        0x1d,
        0x9d,
        0x5d,
        0xdd,
        0x3d,
        0xbd,
        0x7d,
        0xfd,
        0x03,
        0x83,
        0x43,
        0xc3,
        0x23,
        0xa3,
        0x63,
        0xe3,
        0x13,
        0x93,
        0x53,
        0xd3,
        0x33,
        0xb3,
        0x73,
        0xf3,
        0x0b,
        0x8b,
        0x4b,
        0xcb,
        0x2b,
        0xab,
        0x6b,
        0xeb,
        0x1b,
        0x9b,
        0x5b,
        0xdb,
        0x3b,
        0xbb,
        0x7b,
        0xfb,
        0x07,
        0x87,
        0x47,
        0xc7,
        0x27,
        0xa7,
        0x67,
        0xe7,
        0x17,
        0x97,
        0x57,
        0xd7,
        0x37,
        0xb7,
        0x77,
        0xf7,
        0x0f,
        0x8f,
        0x4f,
        0xcf,
        0x2f,
        0xaf,
        0x6f,
        0xef,
        0x1f,
        0x9f,
        0x5f,
        0xdf,
        0x3f,
        0xbf,
        0x7f,
        0xff,
    };
    return table[x];
}

void GBTUtil::write_archive(const char *outname, const char *filename)
{
    //    struct archive *a;
    //    struct archive_entry *entry;
    //    struct stat st;
    //    char buff[8192];
    //    int len;
    //    int fd;

    //    a = archive_write_new();
    //    archive_write_add_filter_gzip(a);
    //    archive_write_set_format_pax_restricted(a); // Note 1
    //    archive_write_open_filename(a, outname);
    //    stat(filename, &st);
    //    entry = archive_entry_new(); // Note 2
    //    archive_entry_set_pathname(entry, filename);
    //    archive_entry_set_size(entry, st.st_size); // Note 3
    //    archive_entry_set_filetype(entry, AE_IFREG);
    //    archive_entry_set_perm(entry, 0644);
    //    archive_write_header(a, entry);
    //    fd = open(filename, O_RDONLY);
    //    archive_write_data(a, "\n", 1);
    //    len = read(fd, buff, sizeof(buff));
    //    while ( len > 0 ) {
    //        archive_write_data(a, buff, len);
    //        len = read(fd, buff, sizeof(buff));
    //    }
    //    close(fd);
    //    archive_entry_free(entry);

    //    archive_write_close(a); // Note 4
    //    archive_write_free(a); // Note 5
}

// dont using this still Telematics local timing working fine
gbt_time_t GBTUtil::getVDCDateTime()
{
    time_t timer;
    struct tm *dateTime = localtime(&timer);
    struct gbt_time_t localDateTime;

    localDateTime.year = dateTime->tm_year;
    localDateTime.month = dateTime->tm_mon;
    localDateTime.day = dateTime->tm_mday;
    localDateTime.hour = dateTime->tm_hour;
    localDateTime.minute = dateTime->tm_min;
    localDateTime.second = dateTime->tm_sec;

    return localDateTime;
}

vector<string> GBTUtil::split(const string &str, char separator)
{
    vector<string> parts;
    int32_t curIndex = 0;
    int32_t prevCurIndex = 0;

    while (curIndex >= 0 && curIndex < (int32_t)str.size())
    {
        prevCurIndex = curIndex;
        int32_t idx = str.find(separator, curIndex);
        curIndex = idx;

        if (curIndex >= 0)
        {
            parts.push_back(str.substr(prevCurIndex, curIndex - prevCurIndex));
            curIndex++;
        }
        else
        {
            parts.push_back(str.substr(prevCurIndex, str.size() - prevCurIndex));
        }
    }
    return parts;
}

vector<string> GBTUtil::split(const string &str, const string &separators)
{
    vector<string> parts;
    int32_t curIndex = 0;
    int32_t prevIndex = 0;

    while (curIndex >= 0 && curIndex < (int32_t)str.size())
    {
        prevIndex = curIndex;
        int32_t candidateIdx = -1;
        for (int32_t i = 0; i < (int32_t)separators.size(); ++i)
        {
            int32_t idx = str.find(separators[i], curIndex);
            //found
            if (idx != (int32_t)string::npos && (idx < candidateIdx || candidateIdx == -1))
            {
                candidateIdx = idx;
            }
        }

        curIndex = candidateIdx;
        if (curIndex >= 0)
        {
            parts.push_back(str.substr(prevIndex, curIndex - prevIndex));
            curIndex++;
        }
        else
        {
            parts.push_back(str.substr(prevIndex, str.size() - prevIndex));
        }
    }
    return parts;
}

bool GBTUtil::is_number(const std::string &s)
{
    return !s.empty() && std::find_if(s.begin(),
                                      s.end(), [](char c) { return !std::isdigit(c); }) == s.end();
}

uint64_t GBTUtil::stoul(const std::string &s)
{
    if (is_number(s))
    {
        return std::stoul(s, nullptr, 0);
    }
    return 0;
}

bool GBTUtil::startsWith(const char *str, const char *prefix)
{
    int strSize = strlen(str);
    int prefixSize = strlen(prefix);
    if (strSize >= prefixSize)
    {
        return strncmp(str, prefix, prefixSize) == 0;
    }
    else
    {
        return false;
    }
}

std::string GBTUtil::getCurrentDir()
{
    return QCoreApplication::applicationDirPath().toStdString();
}

bool GBTUtil::makeDir(string path)
{
    QDir dir(QString::fromStdString(path));
    if (dir.mkdir("."))
    {
        return true;
    }
    return false;
}

bool GBTUtil::isDirExist(string path)
{
    return QDir(QString::fromStdString(path)).exists();
}
