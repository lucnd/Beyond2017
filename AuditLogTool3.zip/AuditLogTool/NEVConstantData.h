#ifndef NEVCONSTANTDATA_H
#define NEVCONSTANTDATA_H

#define LOG_FILE_DIR "/data/"

#endif // NEVCONSTANTDATA_H
