#ifndef DEMOMODEPROCESS_H
#define DEMOMODEPROCESS_H

#include "SpecialModeDataType.h"
#include "SpecialModeBaseProcess.h"
#include "DemoModeTimer.h"

//#include "services/NGTPManagerService/INGTPManagerService.h"
//#include "services/NGTPManagerService/INGTPReceiver.h"
#include <utils/Message.h>
#include <utils/Handler.h>
#include <utils/atoi.h>
#include <time.h>

class DemoModeProcess : public SpecialModeBaseProcess
{
public:
    DemoModeProcess();
    virtual ~DemoModeProcess();

    void do_KeepPower();
    void do_releaseKeepPower();
    virtual void handleEvent(uint32_t ev);
    virtual void handleTimerEvent(int timerId);
    virtual void do_SpecialModeHandler(int32_t what, const sp<sl::Message>& message);
    void DemoModeStart();
    bool TurnOnDemoMode(uint8_t timeUnit, int32_t m_time);
    void DemoModeStop();
    bool TurnOffDemoMode();
    void sendResponse(int32_t what, const sp<sl::Message>& message);

    void activatePSIM();
    void onPSimStateChanged(int32_t simAct, int32_t event, int32_t slot);
    void onActiveSimStateChanged(int32_t activeSim);
    void onPsimLockStateChanged(bool locked);

    int byteToInt1(byte data[], int idx);
    void checkEBcallStatus();

    void registerSVTpostReceiver();
    void demoModeClockReset();
    void setDisableEbcallStatus();
    uint8_t getSVTConfig(const char* name);

private:
    DemoModeTimerSet m_TimerSet;
    // KeepPower* mp_KeepPower;

    // sp<TelephonyManager::PsimLock> m_psimLock;
    bool m_pSimCheck;

    bool mCheckPower;
    int32_t mRunningTime;
    uint8_t mTimeUnit;

    bool bSVTRegOnDemo;
    bool bSVTAlertStatus;

protected:
    virtual void initializeProcess();

    void setDemoStatus(DEMO_MODE_STATUS status);
    DEMO_MODE_STATUS getDemoStatus();
    DEMO_MODE_STATUS mDemoModeStatus;

    void setWifiStatus(WCONNECT_STATUS status);
    WCONNECT_STATUS getWifiStatus();
    WCONNECT_STATUS mWifiStatus;

};

#endif // DEMOMODEPROCESS_H
