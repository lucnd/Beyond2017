#define LOG_TAG "SpecialModeApplication"
#include <Log.h>
#include <stdio.h>
#include "SpecialModeApplication.h"
#include "DemoModeProcess.h"

#include "HMIType.h"

static android::sp<Application> gApp;


SpecialModeApplication::SpecialModeApplication() {
    LOGI(" JLR/TCU4 CREATE  SPECIAL MODE");
}

SpecialModeApplication::~SpecialModeApplication() {

}

void SpecialModeApplication::onCreate() {
    LOGV("onCreate()  #########  what the fuck");
    LOGI("SpecialMode for JLR, and into in inActive State");


   m_Looper = sl::SLLooper::myLooper();

   if(m_Handler == NULL){
        m_Handler = new SpecialModeHandler(m_Looper, *this);
    }

   LOGI("pass create handler");
    // if(m_ServicesMgr == NULL) {
    //     m_ServicesMgr   = new SpecialModeServicesManager();
    // }
    // LOGI("pass create service manager");
    if(mp_ReceiverMgr == NULL){
        mp_ReceiverMgr = new SpecialModeReceiverManager(m_ServicesMgr,m_Handler);
        mp_ReceiverMgr->initializeReceiver();
    }
    LOGI("pass create receiver manager");

     m_AppAlive  = true;
    Initialize_SpecialModeProcess();    // chuan bi khoi tao thang process : ignore provision
}

void SpecialModeApplication::onDestroy() {
    LOGV("onDestroy()");
    //  if(mp_SpecialModeProcess != NULL){
    //     delete mp_SpecialModeProcess;
    //     mp_SpecialModeProcess = NULL;
    // }

    // if(mp_ReceiverMgr != NULL){
    //     mp_ReceiverMgr->releaseReceiver();
    //     delete mp_ReceiverMgr;
    //     mp_ReceiverMgr = NULL;
    // }
    ReadyToDestroy();
}

void SpecialModeApplication::onPostReceived(const sp<Post>& post) {

    LOGI("SpecialModeApplication::onPostReceived : what[0x%x] arg1[%d] arg2[%d]", post->what, post->arg1, post->arg2);
    sp<Buffer> buf_tmp = new Buffer();
    sp<sl::Message> message = m_Handler->obtainMessage(post->what, post->arg1, post->arg2);
    message->sendToTarget();
}

void SpecialModeApplication::do_SpecialModeHandler(uint32_t what, const sp<sl::Message>& message) {
    LOGV("#########do_SpecialModeHandler : what[%d],msgwhat[%d],msgarg1[%d]", what, message->what, message->arg1);
    mp_SpecialModeProcess->do_SpecialModeHandler(what, message);    // when specialmode process ready
}

void SpecialModeApplication::Initialize_SpecialModeProcess(){
    LOGI("initialize_SpceialModeProcess() SpecialMode Type");
    mp_SpecialModeProcess = (SpecialModeBaseProcess*) new DemoModeProcess();
    // if(m_SpecialModeType == IN_CONTROL_LIGHT){
    //     mp_SpecialModeProcess = (SpecialModeBaseProcess*) new InControlLightProcess();
    // }
    // else{
    //     mp_SpecialModeProcess = (SpecialModeBaseProcess*) new DemoModeProcess();
    // }
    // mp_SpecialModeProcess->initialize(m_ServicesMgr, this, m_Handler);
}

void SpecialModeApplication::release_SpecialModeProcess(){
    // if(mp_SpecialModeProcess== NULL) {
    //     return;
    // }
    // LOGI("release_SpecialModeProcess() called.");

    // delete mp_SpecialModeProcess;
    // mp_SpecialModeProcess = NULL;
}

char* SpecialModeApplication::getPropertyWrap(const char* name){
    if(name == NULL) {
        LOGE("%s  name is NULL !", __func__);
        return NULL;
    }
    return getProperty(name);
}

void SpecialModeApplication::setPropertyChar(const char* name, const char* value, bool sync_now){
    if(name != NULL) {
        LOGV("Berfore: %s name[%s], value[%s]", __func__, name, value);
        setProperty(name, value, sync_now);
    }
    LOGV("After: %s", __func__);
}

void SpecialModeApplication::setPropertyInt(const char* name, const int32_t i_value, bool sync_now){
    if(name != NULL) {
        LOGV("Berfore: %s name[%s], i_value[%d]", __func__, name, i_value);
        setProperty(name, i_value, sync_now);
    }
    LOGV("After: %s", __func__);
}

#ifdef __cplusplus
extern "C" class Application* createApplication() {
    printf("create SpecialModeApplication");
    gApp = new SpecialModeApplication;
    return gApp.get();
}

extern "C" void destroyApplication(class Application* application) {
    delete (SpecialModeApplication*)application;
}
#endif
