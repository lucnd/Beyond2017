#include "SpecialModeHandler.h"

SpecialModeHandler::~SpecialModeHandler(){
}

void SpecialModeHandler::handleMessage(const sp<sl::Message>& message){
    const int32_t what = message->what;
//    LOGI("SpecialModeHandler:: handleMessage what:%d msgarg1:%d",what,message->arg1);
    mr_Application.do_SpecialModeHandler(what, message);

}
