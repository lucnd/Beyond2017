#ifndef _SPECIALMODE_APPLICATION_H_
#define _SPECIALMODE_APPLICATION_H_

#include "ISpecialModeApplication.h"
#include "SpecialModeServicesManager.h"
#include "SpecialModeReceiverManager.h"
#include "SpecialModeBaseProcess.h"
#include "SpecialModeHandler.h"



#include <utils/SLLooper.h>
#include <utils/Handler.h>
#include <binder/IServiceManager.h>

#include <corebase/application/Application.h>
#include <services/SystemManagerService/ISystemManagerService.h>
#include <services/ApplicationManagerService/ISystemPostReceiver.h>
#include <services/ApplicationManagerService/IApplicationManagerService.h>

class SpecialModeApplication : public ISpecialModeApplication, public Application {

public:
    SpecialModeApplication();
    virtual ~SpecialModeApplication();

    /**
    * Application has two lifecycle method, onCreate() and onDestroy()
    */
    virtual void onCreate();
    virtual void onDestroy();

    /**
    * Callback method
    */
    virtual void onPostReceived(const sp<Post>& post);
    // virtual void onHMIReceived(const uint32_t type, const uint32_t action);

    /**
    * your own method
    */
    void release_SpecialModeProcess();
    virtual void do_SpecialModeHandler(uint32_t what, const sp<sl::Message>& message);
    char* getPropertyWrap(const char* name);
    void setPropertyChar(const char* name, const char* value, bool sync_now);
    void setPropertyInt(const char* name, const int32_t i_value, bool sync_now);


private:
    sp<SpecialModeHandler> m_Handler;
    sp<sl::SLLooper> m_Looper;
    sp<SpecialModeServicesManager> m_ServicesMgr;
    bool m_AppAlive;
    bool m_ProvisioningFlag;
    SpecialModeReceiverManager* mp_ReceiverMgr;
    SpecialModeBaseProcess* mp_SpecialModeProcess;

    void Initialize_SpecialModeProcess();

};
#endif // _SPECIALMODE_APPLICATION_H_
